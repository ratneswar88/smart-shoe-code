// lib/pages/training_page.dart
//
// Improvements over previous version:
//  1. Incremental CSV write — IOSink opened on Start, one row written per
//     roll BLE event, flushed/closed on Stop.  RAM never holds more than
//     300 samples regardless of session length.
//  2. Multi-label training — "Train & Save" scans ALL saved CSVs, reads
//     the label column, builds a combined feature matrix, shuffles, and
//     trains a softmax across every label present (not just the one
//     selected in the UI).
//  3. Dataset summary card shows window counts per label so the user can
//     see what data they have before pressing Train.

import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:intl/intl.dart';
import 'package:latlong2/latlong.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../ble.dart';

class TrainingPage extends StatefulWidget {
  const TrainingPage({super.key, required this.ble});
  final ShoeBle ble;

  @override
  State<TrainingPage> createState() => _TrainingPageState();
}

class _TrainingPageState extends State<TrainingPage> {
  // ── Labels ─────────────────────────────────────────────────────────────
  static const _labels = [
    'walking', 'running', 'stairs_up', 'stairs_down', 'standing', 'sitting',
  ];
  String _label = 'walking';

  // ── Connection ──────────────────────────────────────────────────────────
  DeviceConnectionState _conn = DeviceConnectionState.disconnected;
  StreamSubscription<DeviceConnectionState>? _connSub;
  bool get _connected => _conn == DeviceConnectionState.connected;

  // ── BLE streams ─────────────────────────────────────────────────────────
  StreamSubscription? _sr, _sp, _sy, _st, _sc, _ss, _sdh;

  // Latest values — roll is the write clock, others are just cached.
  double  _latPitch = 0, _latYaw = 0, _latCadence = 0,
          _latStride = 0, _latDh = 0;
  double? _latTemp;

  // ── Collection state ────────────────────────────────────────────────────
  bool      _collecting  = false;
  DateTime? _tStart;
  double    _tRel        = 0;   // relative time, increments on each roll event
  int       _sampleCount = 0;   // display counter only

  // Incremental write — opened on Start, closed on Stop.
  IOSink? _sink;
  File?   _csvFile;

  // Rolling window for display only; never used for training.
  final List<_RawRow> _liveBuf = [];
  static const _liveBufMax = 300;

  // ── GPS / route ─────────────────────────────────────────────────────────
  final GlobalKey     _mapKey  = GlobalKey();
  final MapController _mapCtrl = MapController();
  List<LatLng>   _track   = [];
  List<DateTime> _trackTs = [];
  StreamSubscription<Position>? _posSub;
  double   _lastDistM = 0;
  Duration _lastDur   = Duration.zero;

  // ── Dataset summary ─────────────────────────────────────────────────────
  Map<String, int> _datasetCounts  = {};  // label -> window count
  bool             _datasetLoading = false;

  // ── Training state ──────────────────────────────────────────────────────
  bool _training = false;
  final _modelNameCtrl = TextEditingController();

  // ── Lifecycle ───────────────────────────────────────────────────────────

  @override
  void initState() {
    super.initState();
    _bindBle();
    _connSub = widget.ble.connection$.listen((c) {
      if (!mounted) return;
      setState(() => _conn = c);
    });
    _refreshDataset();
  }

  @override
  void dispose() {
    for (final s in [_sr, _sp, _sy, _st, _sc, _ss, _sdh]) s?.cancel();
    _connSub?.cancel();
    _posSub?.cancel();
    _sink?.close();
    _modelNameCtrl.dispose();
    super.dispose();
  }

  // ── BLE binding ─────────────────────────────────────────────────────────

  void _bindBle() {
    // Roll fires the write clock.  One CSV row is written per event.
    _sr = widget.ble.roll$.listen((roll) {
      if (!_collecting) return;
      _tRel += 0.1;
      final row = _RawRow(
        t: _tRel, roll: roll, pitch: _latPitch, yaw: _latYaw,
        tempC: _latTemp, cadence: _latCadence, strideM: _latStride,
        dh: _latDh, label: _label,
      );
      _sink?.writeln(row.toCsv());
      _liveBuf.add(row);
      if (_liveBuf.length > _liveBufMax) _liveBuf.removeAt(0);
      if (mounted) setState(() => _sampleCount++);
    });
    // All others just update the cache — no list growth.
    _sp  = widget.ble.pitch$.listen((v)   { _latPitch   = v; });
    _sy  = widget.ble.yaw$.listen((v)     { _latYaw     = v; });
    _st  = widget.ble.temp$.listen((v)    { _latTemp    = v; });
    _sc  = widget.ble.cadence$.listen((v) { _latCadence = v; });
    _ss  = widget.ble.stride$.listen((v)  { _latStride  = v; });
    _sdh = widget.ble.dh$.listen((v)      { _latDh      = v; });
  }

  // ── Collection control ──────────────────────────────────────────────────

  Future<void> _toggleCollect() async {
    if (!_collecting) {
      // START
      if (!_connected) { _snack('Connect to the shoe first.'); return; }
      final dir   = await _ensureDir(await _appDir(), 'sessions');
      final stamp = DateFormat('yyMMdd_HHmmss').format(DateTime.now());
      _csvFile    = File('${dir.path}/${_label}_$stamp.csv');
      _sink       = _csvFile!.openWrite();
      _sink!.writeln(_RawRow.csvHeader);
      setState(() {
        _collecting = true; _sampleCount = 0; _tRel = 0;
        _liveBuf.clear(); _track = []; _trackTs = [];
        _tStart = DateTime.now();
      });
      await _startGps();
    } else {
      // STOP
      await _stopGps();
      if (_sampleCount == 0) {
        await _sink?.close(); _sink = null; _csvFile = null;
        if (mounted) setState(() => _collecting = false);
        _snack('No sensor data received — nothing saved.');
        return;
      }
      await _sink?.flush();
      await _sink?.close();
      _sink = null;
      _lastDistM = _computeDistM();
      _lastDur   = _tStart != null
          ? DateTime.now().difference(_tStart!) : Duration.zero;
      await _fitRoute();
      final csv = _csvFile!; _csvFile = null;
      if (mounted) setState(() => _collecting = false);
      final png = await _captureMapPng();
      final geo = await _saveGeoJson(csv);
      final gpx = await _saveGpx(csv);
      final kml = await _saveKml(csv);
      await _showSummarySheet(csv, png, geo, gpx, kml);
      await _refreshDataset();
    }
  }

  // ── Dataset scan ────────────────────────────────────────────────────────

  Future<void> _refreshDataset() async {
    if (!mounted) return;
    setState(() => _datasetLoading = true);
    try {
      final dir   = await _ensureDir(await _appDir(), 'sessions');
      final files = dir.listSync().whereType<File>()
          .where((f) => f.path.endsWith('.csv')).toList();
      final counts = <String, int>{};
      for (final f in files) {
        try {
          final lines = await f.readAsLines();
          if (lines.length < 2) continue;
          // Count rows per label; estimate windows at 10 Hz BLE rate
          // (3 s window = 30 rows, 1.5 s hop = 15 rows).
          final rowsByLabel = <String, int>{};
          for (final l in lines.skip(1)) {
            if (l.trim().isEmpty) continue;
            final parts = l.split(',');
            if (parts.length < 9) continue;
            final lbl = parts[8].trim();
            if (lbl.isNotEmpty) rowsByLabel[lbl] = (rowsByLabel[lbl] ?? 0) + 1;
          }
          for (final e in rowsByLabel.entries) {
            final wins = math.max(0, (e.value - 30) ~/ 15 + 1);
            counts[e.key] = (counts[e.key] ?? 0) + wins;
          }
        } catch (_) {}
      }
      if (mounted) setState(() => _datasetCounts = counts);
    } finally {
      if (mounted) setState(() => _datasetLoading = false);
    }
  }

  // ── Multi-label training ────────────────────────────────────────────────

  Future<void> _trainAndSave() async {
    if (_training) return;
    setState(() => _training = true);
    try {
      final dir   = await _ensureDir(await _appDir(), 'sessions');
      final files = dir.listSync().whereType<File>()
          .where((f) => f.path.endsWith('.csv')).toList();
      if (files.isEmpty) {
        _snack('No sessions found. Collect at least two labels first.');
        return;
      }

      final X           = <List<double>>[];
      final y           = <int>[];
      final foundLabels = <String>{};

      for (final f in files) {
        try {
          final rows = await _loadCsvRows(f);
          if (rows.length < 30) continue;
          for (final w in _windowRows(rows)) {
            final lbl = w.first.label;
            final idx = _labels.indexOf(lbl);
            if (idx < 0) continue;
            foundLabels.add(lbl);
            X.add(_features(w));
            y.add(idx);
          }
        } catch (_) {}
      }

      if (foundLabels.length < 2) {
        _snack(
          'Need sessions for ≥2 labels. '
          'Found: ${foundLabels.isEmpty ? "none" : foundLabels.join(", ")}.',
        );
        return;
      }

      // Shuffle then 80/20 split.
      final rng     = math.Random(42);
      final indices = List.generate(X.length, (i) => i)..shuffle(rng);
      final Xs      = [for (final i in indices) X[i]];
      final ys      = [for (final i in indices) y[i]];
      final m       = math.max(1, (Xs.length * 0.8).floor());

      final clf = SoftmaxClassifier()
        ..init(numClasses: _labels.length, inDim: Xs.first.length)
        ..fit(Xs.sublist(0, m), ys.sublist(0, m),
              epochs: 100, lr: 0.05, l2: 1e-4, batch: 64);
      final acc = clf.accuracy(Xs.sublist(m), ys.sublist(m));

      final mDir  = await _ensureDir(await _appDir(), 'models');
      final stamp = DateFormat('yyMMdd_HHmmss').format(DateTime.now());
      final base  = _modelNameCtrl.text.trim().isEmpty
          ? (foundLabels.toList()..sort()).join('_')
          : _modelNameCtrl.text.trim();
      await File('${mDir.path}/${base}_$stamp.json').writeAsString(
        const JsonEncoder.withIndent('  ').convert({
          'labels':      _labels,
          'input_dim':   Xs.first.length,
          'num_classes': _labels.length,
          'trained_on':  (foundLabels.toList()..sort()),
          'windows':     Xs.length,
          'accuracy':    acc,
          'W':           clf.W,
          'b':           clf.b,
        }),
      );

      if (mounted) {
        _snack('Saved — ${(acc * 100).toStringAsFixed(1)}% acc · '
               '${Xs.length} windows · ${foundLabels.length} labels');
      }
    } finally {
      if (mounted) setState(() => _training = false);
    }
  }

  // ── CSV / windowing helpers ──────────────────────────────────────────────

  Future<List<_RawRow>> _loadCsvRows(File f) async {
    final lines = await f.readAsLines();
    final out   = <_RawRow>[];
    for (final l in lines.skip(1)) {
      if (l.trim().isEmpty) continue;
      final r = _RawRow.fromCsv(l);
      if (r != null) out.add(r);
    }
    return out;
  }

  List<List<_RawRow>> _windowRows(List<_RawRow> rows,
      {int winN = 30, int hopN = 15}) {
    if (rows.length < winN) return [];
    final out = <List<_RawRow>>[];
    for (int i = 0; i + winN <= rows.length; i += hopN) {
      out.add(rows.sublist(i, i + winN));
    }
    return out;
  }

  List<double> _features(List<_RawRow> win) {
    List<double> col(double? Function(_RawRow) fn) =>
        win.map(fn).whereType<double>().toList();
    List<double> stats(List<double> x) {
      if (x.isEmpty) return [0.0, 0.0, 0.0];
      final n    = x.length;
      final mean = x.reduce((a, b) => a + b) / n;
      final vari = x.map((v) => (v - mean) * (v - mean))
                    .reduce((a, b) => a + b) / n;
      final rms  = math.sqrt(x.map((v) => v * v).reduce((a, b) => a + b) / n);
      return [mean, vari, rms];
    }
    return [
      ...stats(col((r) => r.roll)),
      ...stats(col((r) => r.pitch)),
      ...stats(col((r) => r.yaw)),
      ...stats(col((r) => r.cadence)),
      ...stats(col((r) => r.strideM)),
      ...stats(col((r) => r.tempC)),
    ];
  }

  // ── GPS helpers ─────────────────────────────────────────────────────────

  Future<bool> _ensureLocationPermission() async {
    if (!await Geolocator.isLocationServiceEnabled()) {
      _snack('Enable GPS in system settings'); return false;
    }
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
      _snack('Location permission denied'); return false;
    }
    return true;
  }

  Future<void> _startGps() async {
    if (!await _ensureLocationPermission()) return;
    try {
      final pos = await Geolocator.getCurrentPosition(
          desiredAccuracy: LocationAccuracy.best);
      if (!pos.latitude.isFinite || !pos.longitude.isFinite) return;
      final pt = LatLng(pos.latitude, pos.longitude);
      if (mounted) setState(() { _track = [pt]; _trackTs = [DateTime.now()]; });
      try { _mapCtrl.move(pt, 16); } catch (_) {}
    } catch (_) {}
    await _posSub?.cancel();
    _posSub = Geolocator.getPositionStream(
      locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.best, distanceFilter: 3),
    ).listen((pos) {
      if (!pos.latitude.isFinite || !pos.longitude.isFinite) return;
      final pt = LatLng(pos.latitude, pos.longitude);
      if (_track.isNotEmpty) {
        final d = Geolocator.distanceBetween(_track.last.latitude,
            _track.last.longitude, pt.latitude, pt.longitude);
        if (d > 1000 || (d < 8 && pos.speed.isFinite && pos.speed < 0.5)) return;
      }
      if (mounted) setState(() { _track.add(pt); _trackTs.add(DateTime.now()); });
      try { _mapCtrl.move(pt, _mapCtrl.camera.zoom); } catch (_) {}
    });
  }

  Future<void> _stopGps() async { await _posSub?.cancel(); _posSub = null; }

  double _computeDistM() {
    if (_track.length < 2) return 0;
    double d = 0;
    for (int i = 1; i < _track.length; i++) {
      d += Geolocator.distanceBetween(_track[i-1].latitude,
          _track[i-1].longitude, _track[i].latitude, _track[i].longitude);
    }
    return d;
  }

  Future<void> _fitRoute() async {
    if (_track.length < 2) return;
    await Future.delayed(const Duration(milliseconds: 100));
    double minLat = _track.first.latitude, maxLat = minLat;
    double minLon = _track.first.longitude, maxLon = minLon;
    for (final p in _track) {
      if (p.latitude  < minLat) minLat = p.latitude;
      if (p.latitude  > maxLat) maxLat = p.latitude;
      if (p.longitude < minLon) minLon = p.longitude;
      if (p.longitude > maxLon) maxLon = p.longitude;
    }
    const sp = 0.001;
    if ((maxLat - minLat).abs() < sp) { minLat -= sp/2; maxLat += sp/2; }
    if ((maxLon - minLon).abs() < sp) { minLon -= sp/2; maxLon += sp/2; }
    try {
      _mapCtrl.fitCamera(CameraFit.bounds(
        bounds: LatLngBounds(LatLng(minLat, minLon), LatLng(maxLat, maxLon)),
        padding: const EdgeInsets.all(20)));
    } catch (_) {}
  }

  // ── Export helpers ───────────────────────────────────────────────────────

  Future<Uint8List?> _captureMapPng() async {
    try {
      final ctx = _mapKey.currentContext; if (ctx == null) return null;
      final b   = ctx.findRenderObject() as RenderRepaintBoundary?;
      if (b == null) return null;
      final img = await b.toImage(pixelRatio: 3.0);
      final bd  = await img.toByteData(format: ui.ImageByteFormat.png);
      return bd?.buffer.asUint8List();
    } catch (_) { return null; }
  }

  String _stem(File f) =>
      f.uri.pathSegments.last.replaceAll(RegExp(r'\.csv$'), '');

  Future<File?> _saveGeoJson(File csv) async {
    try {
      if (_track.isEmpty) return null;
      final f = File('${csv.parent.path}/${_stem(csv)}.geojson');
      await f.writeAsString(jsonEncode({
        'type': 'FeatureCollection',
        'features': [{
          'type': 'Feature',
          'properties': {'label': _label, 'distance_m': _lastDistM},
          'geometry': {'type': 'LineString',
            'coordinates': _track.map((p) => [p.longitude, p.latitude]).toList()},
        }],
      }), flush: true);
      return f;
    } catch (_) { return null; }
  }

  Future<File?> _saveGpx(File csv) async {
    try {
      if (_track.isEmpty) return null;
      final sb = StringBuffer()
        ..writeln('<?xml version="1.0" encoding="UTF-8"?>')
        ..writeln('<gpx version="1.1" creator="ShoeML">'
                  '<trk><n>$_label</n><trkseg>');
      for (int i = 0; i < _track.length; i++) {
        final p = _track[i];
        final t = i < _trackTs.length
            ? _trackTs[i].toUtc().toIso8601String()
            : DateTime.now().toUtc().toIso8601String();
        sb.writeln('<trkpt lat="${p.latitude}" lon="${p.longitude}">'
                   '<time>$t</time></trkpt>');
      }
      sb.writeln('</trkseg></trk></gpx>');
      final f = File('${csv.parent.path}/${_stem(csv)}.gpx');
      await f.writeAsString(sb.toString(), flush: true);
      return f;
    } catch (_) { return null; }
  }

  Future<File?> _saveKml(File csv) async {
    try {
      if (_track.isEmpty) return null;
      final safe = _label.replaceAll(RegExp(r'\W+'), '_');
      final sb = StringBuffer()
        ..writeln('<?xml version="1.0"?>')
        ..writeln('<kml xmlns="http://www.opengis.net/kml/2.2">'
                  '<Document><n>$safe</n><Placemark>'
                  '<LineString><coordinates>');
      for (final p in _track) sb.writeln('${p.longitude},${p.latitude},0');
      sb.writeln('</coordinates></LineString></Placemark></Document></kml>');
      final f = File('${csv.parent.path}/${_stem(csv)}.kml');
      await f.writeAsString(sb.toString(), flush: true);
      return f;
    } catch (_) { return null; }
  }

  // ── Utilities ────────────────────────────────────────────────────────────

  Future<Directory> _appDir() async {
    final d   = await getApplicationDocumentsDirectory();
    final dir = Directory('${d.path}/shoeml');
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return dir;
  }

  Future<Directory> _ensureDir(Directory base, String child) async {
    final d = Directory('${base.path}/$child');
    if (!d.existsSync()) d.createSync(recursive: true);
    return d;
  }

  String _dist(double m) => m < 1000
      ? '${m.toStringAsFixed(1)} m' : '${(m/1000).toStringAsFixed(2)} km';
  String _dur(Duration d) => '${d.inMinutes}m ${d.inSeconds % 60}s';

  void _snack(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(msg)));
  }

  Future<void> _showSummarySheet(
      File csv, Uint8List? png, File? geo, File? gpx, File? kml) async {
    if (!mounted) return;
    await showModalBottomSheet<void>(
      context: context,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Session saved',
                style: Theme.of(ctx).textTheme.titleMedium),
            const SizedBox(height: 8),
            Text('$_label  ·  $_sampleCount samples  ·  '
                 '${_dist(_lastDistM)}  ·  ${_dur(_lastDur)}'),
            const SizedBox(height: 8),
            if (png != null)
              SizedBox(
                height: 140,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.memory(png, fit: BoxFit.cover,
                      width: double.infinity),
                ),
              ),
            const SizedBox(height: 8),
            Text(csv.path.split('/').last,
                style: Theme.of(ctx).textTheme.bodySmall),
            if (geo != null) Text('GeoJSON saved',
                style: Theme.of(ctx).textTheme.bodySmall),
            if (gpx != null) Text('GPX saved',
                style: Theme.of(ctx).textTheme.bodySmall),
            if (kml != null) Text('KML saved',
                style: Theme.of(ctx).textTheme.bodySmall),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                icon: const Icon(Icons.share),
                label: const Text('Share CSV'),
                onPressed: () async {
                  Navigator.of(ctx).pop();
                  await Share.shareXFiles([XFile(csv.path)],
                      text: 'ShoeML session');
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.all(12),
      child: ListView(children: [
        _collectCard(cs),
        const SizedBox(height: 12),
        _datasetCard(cs),
        const SizedBox(height: 12),
        _trainCard(cs),
        const SizedBox(height: 12),
        _shareCard(),
        const SizedBox(height: 12),
        _routeCard(cs),
      ]),
    );
  }

  Widget _collectCard(ColorScheme cs) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Collect samples',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            const Text(
              'Pick a label, tap Start. Stop saves the session to a CSV '
              'and adds it to the training pool. Collect at least one '
              'session per label you want to classify.',
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8, runSpacing: 6,
              children: _labels.map((lbl) => ChoiceChip(
                label: Text(lbl.replaceAll('_', ' ')),
                selected: _label == lbl,
                onSelected: _collecting ? null : (on) {
                  if (on) setState(() => _label = lbl);
                },
              )).toList(),
            ),
            const SizedBox(height: 12),
            Row(children: [
              FilledButton.icon(
                onPressed: _collecting
                    ? _toggleCollect
                    : (_connected ? _toggleCollect : null),
                icon: Icon(_collecting
                    ? Icons.stop : Icons.fiber_manual_record),
                label: Text(_collecting
                    ? 'Stop & Save' : 'Start  "$_label"'),
                style: _collecting
                    ? FilledButton.styleFrom(
                        backgroundColor: cs.error,
                        foregroundColor: cs.onError) : null,
              ),
              if (_collecting) ...[
                const SizedBox(width: 12),
                Text('$_sampleCount samples',
                    style: Theme.of(context).textTheme.bodySmall),
              ],
            ]),
            if (!_connected && !_collecting)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text('Connect to the shoe to enable recording.',
                    style: TextStyle(color: cs.error, fontSize: 12)),
              ),
          ],
        ),
      ),
    );
  }

  Widget _datasetCard(ColorScheme cs) {
    final total          = _datasetCounts.values.fold(0, (a, b) => a + b);
    final labelsWithData = _datasetCounts.keys
        .where((l) => (_datasetCounts[l] ?? 0) > 0).length;

    return Card(
      color: cs.surfaceContainerHigh,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [
              Text('Training dataset',
                  style: Theme.of(context).textTheme.titleSmall),
              const Spacer(),
              if (_datasetLoading)
                const SizedBox(width: 14, height: 14,
                    child: CircularProgressIndicator(strokeWidth: 2))
              else
                IconButton(
                  icon: const Icon(Icons.refresh, size: 18),
                  onPressed: _refreshDataset,
                  tooltip: 'Refresh',
                  padding: EdgeInsets.zero,
                  constraints: const BoxConstraints(),
                ),
            ]),
            const SizedBox(height: 8),
            if (total == 0)
              Text('No sessions yet. Record at least one session per label.',
                  style: TextStyle(color: cs.onSurfaceVariant, fontSize: 13))
            else ...[
              Text('$total windows  ·  $labelsWithData label(s)',
                  style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 10),
              ..._labels.map((lbl) {
                final count = _datasetCounts[lbl] ?? 0;
                final frac  = total > 0 ? count / total : 0.0;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Row(children: [
                    SizedBox(
                      width: 108,
                      child: Text(lbl.replaceAll('_', ' '),
                          style: const TextStyle(fontSize: 12)),
                    ),
                    Expanded(
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(4),
                        child: LinearProgressIndicator(
                          value: frac, minHeight: 8,
                          backgroundColor: cs.surfaceContainerHighest,
                          color: count > 0 ? cs.primary : null,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    SizedBox(
                      width: 38,
                      child: Text(count > 0 ? '$count' : '—',
                          textAlign: TextAlign.right,
                          style: TextStyle(
                            fontSize: 12,
                            color: count > 0
                                ? cs.onSurface : cs.onSurfaceVariant,
                          )),
                    ),
                  ]),
                );
              }),
              if (labelsWithData < 2)
                Padding(
                  padding: const EdgeInsets.only(top: 4),
                  child: Text(
                    '⚠  Need data for at least 2 labels before training.',
                    style: TextStyle(color: cs.error, fontSize: 12),
                  ),
                ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _trainCard(ColorScheme cs) {
    final labelsWithData = _datasetCounts.keys
        .where((l) => (_datasetCounts[l] ?? 0) > 0).length;
    final canTrain = labelsWithData >= 2 && !_training && !_collecting;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Train classifier',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            const Text(
              'Reads all saved sessions, extracts 3 s windows (hop 1.5 s), '
              'shuffles, then trains across all labels present. '
              'Split: 80 % train / 20 % test.',
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _modelNameCtrl,
              decoration: const InputDecoration(
                labelText: 'Model name (optional)',
                hintText: 'e.g. outdoor_v2',
                border: OutlineInputBorder(),
                isDense: true,
              ),
            ),
            const SizedBox(height: 12),
            Row(children: [
              FilledButton.icon(
                onPressed: canTrain ? _trainAndSave : null,
                icon: _training
                    ? const SizedBox(width: 16, height: 16,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.auto_awesome),
                label: Text(_training ? 'Training…' : 'Train & Save'),
              ),
              if (!canTrain && !_training)
                Padding(
                  padding: const EdgeInsets.only(left: 10),
                  child: Text(
                    labelsWithData < 2
                        ? 'Collect ≥2 labels first.'
                        : _collecting ? 'Stop recording first.' : '',
                    style: TextStyle(
                        fontSize: 12, color: cs.onSurfaceVariant),
                  ),
                ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _shareCard() {
    return Card(
      child: ListTile(
        title: const Text('Share last CSV'),
        subtitle: const Text('Shares the most recently saved session.'),
        trailing: IconButton(
          icon: const Icon(Icons.share),
          onPressed: () async {
            final dir = await _ensureDir(await _appDir(), 'sessions');
            final files = dir.listSync().whereType<File>()
                .where((f) => f.path.endsWith('.csv')).toList()
              ..sort((a, b) =>
                  b.lastModifiedSync().compareTo(a.lastModifiedSync()));
            if (files.isEmpty) { _snack('No sessions yet.'); return; }
            await Share.shareXFiles([XFile(files.first.path)],
                text: 'ShoeML session');
          },
        ),
      ),
    );
  }

  Widget _routeCard(ColorScheme cs) {
    return Card(
      color: cs.surfaceContainerHigh,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Route preview',
                style: TextStyle(fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            SizedBox(
              height: 220,
              child: RepaintBoundary(
                key: _mapKey,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: _track.isEmpty
                      ? Container(
                          color: cs.surfaceContainerHighest,
                          alignment: Alignment.center,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.location_searching,
                                  size: 42, color: cs.onSurfaceVariant),
                              const SizedBox(height: 8),
                              Text('Start a recording to see GPS route.',
                                  style: TextStyle(
                                      color: cs.onSurfaceVariant,
                                      fontSize: 13)),
                            ],
                          ),
                        )
                      : FlutterMap(
                          mapController: _mapCtrl,
                          options: MapOptions(
                              initialCenter: _track.last,
                              initialZoom: 16),
                          children: [
                            TileLayer(
                              urlTemplate:
                                  'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                              userAgentPackageName: 'com.madeplus.shoeml',
                            ),
                            if (_track.length > 1)
                              PolylineLayer(polylines: [
                                Polyline(
                                  points: _track, strokeWidth: 4,
                                  color: cs.primary,
                                ),
                              ]),
                            MarkerLayer(markers: [
                              Marker(
                                  width: 30, height: 30,
                                  point: _track.first,
                                  child: const Icon(Icons.flag,
                                      color: Colors.green)),
                              Marker(
                                  width: 30, height: 30,
                                  point: _track.last,
                                  child: const Icon(Icons.place,
                                      color: Colors.red)),
                            ]),
                          ],
                        ),
                ),
              ),
            ),
            if (_lastDistM > 0 || _lastDur.inSeconds > 0)
              Padding(
                padding: const EdgeInsets.only(top: 6),
                child: Text(
                  'Last: ${_dist(_lastDistM)} · ${_dur(_lastDur)}',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

// ---------------------------------------------------------------------------
// Data model
// ---------------------------------------------------------------------------

class _RawRow {
  static const csvHeader =
      't,roll,pitch,yaw,tempC,cadence,strideM,deltaH,label';

  const _RawRow({
    required this.t, required this.roll, required this.pitch,
    required this.yaw, required this.tempC, required this.cadence,
    required this.strideM, required this.dh, required this.label,
  });

  final double  t, roll, pitch, yaw;
  final double? tempC, cadence, strideM, dh;
  final String  label;

  String toCsv() =>
      '${t.toStringAsFixed(2)},'
      '${roll.toStringAsFixed(4)},'
      '${pitch.toStringAsFixed(4)},'
      '${yaw.toStringAsFixed(4)},'
      '${tempC?.toStringAsFixed(2) ?? ''},'
      '${cadence?.toStringAsFixed(2) ?? ''},'
      '${strideM?.toStringAsFixed(3) ?? ''},'
      '${dh?.toStringAsFixed(3) ?? ''},'
      '$label';

  static _RawRow? fromCsv(String line) {
    try {
      final p = line.split(',');
      if (p.length < 9) return null;
      return _RawRow(
        t:       double.parse(p[0].trim()),
        roll:    double.tryParse(p[1].trim()) ?? 0.0,
        pitch:   double.tryParse(p[2].trim()) ?? 0.0,
        yaw:     double.tryParse(p[3].trim()) ?? 0.0,
        tempC:   double.tryParse(p[4].trim()),
        cadence: double.tryParse(p[5].trim()),
        strideM: double.tryParse(p[6].trim()),
        dh:      double.tryParse(p[7].trim()),
        label:   p[8].trim(),
      );
    } catch (_) { return null; }
  }
}

// ---------------------------------------------------------------------------
// Softmax classifier
// ---------------------------------------------------------------------------

class SoftmaxClassifier {
  late int C, D;
  late List<List<double>> W;
  late List<double> b;

  void init({required int numClasses, required int inDim}) {
    C = numClasses; D = inDim;
    final rnd = math.Random(42);
    W = List.generate(C, (_) =>
        List.generate(D, (_) => (rnd.nextDouble() - 0.5) * 0.01));
    b = List.filled(C, 0.0);
  }

  List<double> _sm(List<double> z) {
    final m = z.reduce(math.max);
    final e = z.map((v) => math.exp(v - m)).toList();
    final s = e.fold<double>(0, (a, b) => a + b);
    return s == 0 ? e : e.map((v) => v / s).toList();
  }

  List<double> _proba(List<double> x) => _sm(List.generate(C, (k) {
    double s = b[k];
    for (int j = 0; j < D; j++) s += W[k][j] * x[j];
    return s;
  }));

  int predict(List<double> x) {
    final p = _proba(x); int arg = 0;
    for (int i = 1; i < p.length; i++) if (p[i] > p[arg]) arg = i;
    return arg;
  }

  void fit(List<List<double>> X, List<int> y,
      {int epochs = 100, double lr = 0.05, double l2 = 1e-4, int batch = 64}) {
    final n = X.length; if (n == 0) return;
    for (int ep = 0; ep < epochs; ep++) {
      for (int i0 = 0; i0 < n; i0 += batch) {
        final i1 = math.min(n, i0 + batch);
        final m  = i1 - i0; if (m <= 0) continue;
        final dW = List.generate(C, (_) => List.filled(D, 0.0));
        final db = List.filled(C, 0.0);
        for (int i = i0; i < i1; i++) {
          final p = _proba(X[i]);
          for (int k = 0; k < C; k++) {
            final g = p[k] - (k == y[i] ? 1.0 : 0.0); db[k] += g;
            for (int j = 0; j < D; j++) dW[k][j] += g * X[i][j];
          }
        }
        for (int k = 0; k < C; k++) {
          for (int j = 0; j < D; j++)
            W[k][j] -= lr * (dW[k][j] / m + l2 * W[k][j]);
          b[k] -= lr * (db[k] / m);
        }
      }
    }
  }

  double accuracy(List<List<double>> X, List<int> y) {
    if (X.isEmpty) return 0.0;
    int ok = 0;
    for (int i = 0; i < X.length; i++) if (predict(X[i]) == y[i]) ok++;
    return ok / X.length;
  }
}
