#include "UartDriver.hpp"

UartDriver::UartDriver(UART_HandleTypeDef* huart)
    : huart_(huart)
    , initialized_(false)
    , rx_head_(0)
    , rx_tail_(0)
{
    if (huart_ != nullptr) {
        std::memset(rx_buffer_, 0, RX_BUFFER_SIZE);
        startReception();
        initialized_ = true;
    }
}

UartDriver::~UartDriver() {
    if (initialized_ && huart_ != nullptr) {
        HAL_UART_DMAStop(huart_);
    }
}

bool UartDriver::transmit(const uint8_t* data, uint16_t len, uint32_t timeout) {
    if (!initialized_ || data == nullptr || len == 0) {
        return false;
    }
    
    HAL_StatusTypeDef status = HAL_UART_Transmit(huart_, 
                                                  const_cast<uint8_t*>(data), 
                                                  len, 
                                                  timeout);
    return (status == HAL_OK);
}

bool UartDriver::transmitString(const char* str) {
    if (str == nullptr) return false;
    uint16_t len = static_cast<uint16_t>(std::strlen(str));
    return transmit(reinterpret_cast<const uint8_t*>(str), len);
}

bool UartDriver::available() const {
    return (rx_head_ != rx_tail_);
}

uint8_t UartDriver::read() {
    if (!available()) {
        return 0;
    }
    
    uint8_t data = rx_buffer_[rx_tail_];
    rx_tail_ = (rx_tail_ + 1) % RX_BUFFER_SIZE;
    return data;
}

uint16_t UartDriver::readBytes(uint8_t* buffer, uint16_t max_len) {
    uint16_t count = 0;
    while (available() && count < max_len) {
        buffer[count++] = read();
    }
    return count;
}

void UartDriver::flush() {
    rx_head_ = 0;
    rx_tail_ = 0;
}

void UartDriver::rxCallback(uint16_t size) {
    for (uint16_t i = 0; i < size; i++) {
        uint16_t next_head = (rx_head_ + 1) % RX_BUFFER_SIZE;
        if (next_head != rx_tail_) {
            rx_buffer_[rx_head_] = rx_buffer_[i];
            rx_head_ = next_head;
        }
    }
    startReception();
}

void UartDriver::startReception() {
    HAL_UART_Receive_IT(huart_, rx_buffer_, 1);
}
