#ifndef UART_DRIVER_HPP
#define UART_DRIVER_HPP

#include "stm32f4xx_hal.h"
#include <cstdint>
#include <cstring>

/**
 * @brief UART Driver Class with RAII and encapsulation
 * 
 * Features:
 * - Automatic initialization and cleanup
 * - Interrupt-driven reception with circular buffer
 * - Non-copyable (hardware resource)
 * - Type-safe interface
 */
class UartDriver {
public:
    // Constructor - automatically initializes UART
    explicit UartDriver(UART_HandleTypeDef* huart);
    
    // Destructor - automatic cleanup
    ~UartDriver();
    
    // Delete copy operations (singleton hardware resource)
    UartDriver(const UartDriver&) = delete;
    UartDriver& operator=(const UartDriver&) = delete;
    
    // Transmit operations
    bool transmit(const uint8_t* data, uint16_t len, uint32_t timeout = 100);
    bool transmitString(const char* str);
    
    // Receive operations
    bool available() const;
    uint8_t read();
    uint16_t readBytes(uint8_t* buffer, uint16_t max_len);
    
    // Utility
    void flush();
    
    // Interrupt handler - call from HAL callback
    void rxCallback(uint16_t size);
    
private:
    UART_HandleTypeDef* huart_;
    bool initialized_;
    
    static constexpr uint16_t RX_BUFFER_SIZE = 256;
    uint8_t rx_buffer_[RX_BUFFER_SIZE];
    volatile uint16_t rx_head_;
    volatile uint16_t rx_tail_;
    
    void startReception();
};

#endif // UART_DRIVER_HPP
