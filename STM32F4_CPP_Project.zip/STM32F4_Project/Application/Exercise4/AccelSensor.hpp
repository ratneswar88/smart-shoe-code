#ifndef ACCEL_SENSOR_HPP
#define ACCEL_SENSOR_HPP

#include "ISensor.hpp"
#include "stm32f4xx_hal.h"

/**
 * @brief Accelerometer sensor implementation
 * 
 * Example implementation for ICM-42688 6-axis IMU
 * (Can be adapted for other I2C accelerometers)
 * 
 * Demonstrates:
 * - Inheritance from interface
 * - Override keyword
 * - Encapsulation of hardware details
 */
class AccelSensor : public ISensor {
public:
    AccelSensor(I2C_HandleTypeDef* hi2c, uint8_t address = 0x68);
    ~AccelSensor() override = default;
    
    // Implement pure virtual functions from ISensor
    bool init() override;
    bool read(float& x, float& y, float& z) override;
    bool isReady() const override { return initialized_; }
    
    // Override optional functions
    void reset() override;
    
    // Accelerometer-specific methods
    bool setRange(uint8_t range);     // 0=±2g, 1=±4g, 2=±8g, 3=±16g
    bool setDataRate(uint16_t rate);  // Sample rate in Hz
    
    // Calibration
    bool calibrate(uint16_t samples = 100);
    
private:
    I2C_HandleTypeDef* hi2c_;
    uint8_t address_;
    bool initialized_;
    float scale_factor_;
    float bias_x_, bias_y_, bias_z_;
    
    // I2C helper functions
    bool writeRegister(uint8_t reg, uint8_t value);
    bool readRegister(uint8_t reg, uint8_t& value);
    bool readRegisters(uint8_t reg, uint8_t* data, uint8_t len);
};

#endif // ACCEL_SENSOR_HPP
