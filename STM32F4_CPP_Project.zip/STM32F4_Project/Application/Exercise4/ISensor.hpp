#ifndef ISENSOR_HPP
#define ISENSOR_HPP

#include <cstdint>

/**
 * @brief Abstract base class for all sensors
 * 
 * Provides common interface for sensor operations.
 * All sensor classes must implement these methods.
 * 
 * This demonstrates polymorphism and interfaces in C++.
 */
class ISensor {
public:
    virtual ~ISensor() = default;
    
    // Pure virtual functions - must be implemented by derived classes
    virtual bool init() = 0;
    virtual bool read(float& x, float& y, float& z) = 0;
    virtual bool isReady() const = 0;
    
    // Optional virtual functions - can be overridden
    virtual void reset() {}
    virtual void sleep() {}
    virtual void wake() {}
    
    // Non-virtual helper function
    bool readSingleAxis(float& value, uint8_t axis) {
        float x, y, z;
        if (!read(x, y, z)) {
            return false;
        }
        
        switch(axis) {
            case 0: value = x; break;
            case 1: value = y; break;
            case 2: value = z; break;
            default: return false;
        }
        return true;
    }
};

#endif // ISENSOR_HPP
