#include "AccelSensor.hpp"

// ICM-42688 Register addresses
#define REG_WHO_AM_I       0x75
#define REG_PWR_MGMT_1     0x6B
#define REG_ACCEL_CONFIG   0x1C
#define REG_ACCEL_XOUT_H   0x3B
#define DEVICE_ID          0x47

AccelSensor::AccelSensor(I2C_HandleTypeDef* hi2c, uint8_t address)
    : hi2c_(hi2c)
    , address_(address << 1)  // I2C address needs to be shifted
    , initialized_(false)
    , scale_factor_(16384.0f)  // For ±2g range
    , bias_x_(0.0f)
    , bias_y_(0.0f)
    , bias_z_(0.0f)
{
}

bool AccelSensor::init() {
    // Verify device ID
    uint8_t who_am_i;
    if (!readRegister(REG_WHO_AM_I, who_am_i)) {
        return false;
    }
    
    if (who_am_i != DEVICE_ID) {
        return false;  // Wrong device or communication error
    }
    
    // Wake up device (clear sleep bit)
    if (!writeRegister(REG_PWR_MGMT_1, 0x00)) {
        return false;
    }
    
    HAL_Delay(100);  // Wait for device to wake up
    
    // Configure accelerometer range (±2g by default)
    if (!writeRegister(REG_ACCEL_CONFIG, 0x00)) {
        return false;
    }
    
    initialized_ = true;
    return true;
}

bool AccelSensor::read(float& x, float& y, float& z) {
    if (!initialized_) {
        return false;
    }
    
    // Read 6 bytes (2 bytes per axis: X, Y, Z)
    uint8_t data[6];
    if (!readRegisters(REG_ACCEL_XOUT_H, data, 6)) {
        return false;
    }
    
    // Combine high and low bytes
    int16_t raw_x = static_cast<int16_t>((data[0] << 8) | data[1]);
    int16_t raw_y = static_cast<int16_t>((data[2] << 8) | data[3]);
    int16_t raw_z = static_cast<int16_t>((data[4] << 8) | data[5]);
    
    // Convert to g and apply calibration
    x = (static_cast<float>(raw_x) / scale_factor_) - bias_x_;
    y = (static_cast<float>(raw_y) / scale_factor_) - bias_y_;
    z = (static_cast<float>(raw_z) / scale_factor_) - bias_z_;
    
    return true;
}

void AccelSensor::reset() {
    // Set reset bit
    writeRegister(REG_PWR_MGMT_1, 0x80);
    HAL_Delay(100);
    
    // Re-initialize
    init();
}

bool AccelSensor::setRange(uint8_t range) {
    if (range > 3) return false;
    
    // Configure range: 0=±2g, 1=±4g, 2=±8g, 3=±16g
    if (!writeRegister(REG_ACCEL_CONFIG, range << 3)) {
        return false;
    }
    
    // Update scale factor
    scale_factor_ = 16384.0f / (1 << range);
    return true;
}

bool AccelSensor::setDataRate(uint16_t rate) {
    // Implementation depends on specific sensor
    // This is a placeholder
    (void)rate;
    return true;
}

bool AccelSensor::calibrate(uint16_t samples) {
    if (!initialized_) {
        return false;
    }
    
    float sum_x = 0.0f, sum_y = 0.0f, sum_z = 0.0f;
    
    for (uint16_t i = 0; i < samples; i++) {
        float x, y, z;
        if (!read(x, y, z)) {
            return false;
        }
        
        sum_x += x;
        sum_y += y;
        sum_z += z;
        
        HAL_Delay(10);
    }
    
    bias_x_ = sum_x / samples;
    bias_y_ = sum_y / samples;
    bias_z_ = (sum_z / samples) - 1.0f;  // Z should be 1g when stationary
    
    return true;
}

bool AccelSensor::writeRegister(uint8_t reg, uint8_t value) {
    HAL_StatusTypeDef status = HAL_I2C_Mem_Write(
        hi2c_, 
        address_, 
        reg,
        I2C_MEMADD_SIZE_8BIT,
        &value, 
        1, 
        100
    );
    return (status == HAL_OK);
}

bool AccelSensor::readRegister(uint8_t reg, uint8_t& value) {
    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(
        hi2c_, 
        address_, 
        reg,
        I2C_MEMADD_SIZE_8BIT,
        &value, 
        1, 
        100
    );
    return (status == HAL_OK);
}

bool AccelSensor::readRegisters(uint8_t reg, uint8_t* data, uint8_t len) {
    HAL_StatusTypeDef status = HAL_I2C_Mem_Read(
        hi2c_, 
        address_, 
        reg,
        I2C_MEMADD_SIZE_8BIT,
        data, 
        len, 
        100
    );
    return (status == HAL_OK);
}
