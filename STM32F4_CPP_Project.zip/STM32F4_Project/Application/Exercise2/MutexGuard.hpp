#ifndef MUTEX_GUARD_HPP
#define MUTEX_GUARD_HPP

#include "FreeRTOS.h"
#include "semphr.h"

/**
 * @brief RAII wrapper for FreeRTOS mutex
 * 
 * Automatically acquires mutex in constructor and releases in destructor.
 * Prevents forgetting to release mutex, even with early returns.
 * 
 * Usage:
 *   void someFunction() {
 *       MutexGuard lock(myMutex);
 *       // Critical section
 *       // Mutex automatically released when lock goes out of scope
 *   }
 */
class MutexGuard {
public:
    explicit MutexGuard(SemaphoreHandle_t mutex, TickType_t timeout = portMAX_DELAY)
        : mutex_(mutex)
        , locked_(false)
    {
        if (mutex_ != nullptr) {
            locked_ = (xSemaphoreTake(mutex_, timeout) == pdTRUE);
        }
    }
    
    ~MutexGuard() {
        if (locked_ && mutex_ != nullptr) {
            xSemaphoreGive(mutex_);
        }
    }
    
    // Delete copy/move
    MutexGuard(const MutexGuard&) = delete;
    MutexGuard& operator=(const MutexGuard&) = delete;
    MutexGuard(MutexGuard&&) = delete;
    MutexGuard& operator=(MutexGuard&&) = delete;
    
    bool isLocked() const { return locked_; }
    
private:
    SemaphoreHandle_t mutex_;
    bool locked_;
};

#endif // MUTEX_GUARD_HPP
