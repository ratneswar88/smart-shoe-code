#ifndef CRITICAL_SECTION_HPP
#define CRITICAL_SECTION_HPP

#include "FreeRTOS.h"
#include "task.h"

/**
 * @brief RAII wrapper for FreeRTOS critical section
 * 
 * Automatically enters critical section in constructor and exits in destructor.
 * Use for very short atomic operations.
 */
class CriticalSection {
public:
    CriticalSection() {
        taskENTER_CRITICAL();
    }
    
    ~CriticalSection() {
        taskEXIT_CRITICAL();
    }
    
    CriticalSection(const CriticalSection&) = delete;
    CriticalSection& operator=(const CriticalSection&) = delete;
};

/**
 * @brief Critical section for ISR context
 */
class CriticalSectionISR {
public:
    CriticalSectionISR() {
        saved_interrupt_status_ = taskENTER_CRITICAL_FROM_ISR();
    }
    
    ~CriticalSectionISR() {
        taskEXIT_CRITICAL_FROM_ISR(saved_interrupt_status_);
    }
    
    CriticalSectionISR(const CriticalSectionISR&) = delete;
    CriticalSectionISR& operator=(const CriticalSectionISR&) = delete;
    
private:
    UBaseType_t saved_interrupt_status_;
};

#endif // CRITICAL_SECTION_HPP
