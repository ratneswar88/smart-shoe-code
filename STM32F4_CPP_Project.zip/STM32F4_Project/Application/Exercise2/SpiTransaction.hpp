#ifndef SPI_TRANSACTION_HPP
#define SPI_TRANSACTION_HPP

#include "stm32f4xx_hal.h"

/**
 * @brief RAII wrapper for SPI transactions
 * 
 * Automatically asserts CS (chip select) in constructor and de-asserts in destructor.
 * Prevents forgetting to release CS, even with errors.
 * 
 * Usage:
 *   {
 *       SpiTransaction spi(&hspi1, GPIOA, GPIO_PIN_4);
 *       uint8_t data = 0x42;
 *       spi.transmit(&data, 1);
 *       // CS automatically released when spi goes out of scope
 *   }
 */
class SpiTransaction {
public:
    SpiTransaction(SPI_HandleTypeDef* hspi, GPIO_TypeDef* cs_port, uint16_t cs_pin)
        : hspi_(hspi)
        , cs_port_(cs_port)
        , cs_pin_(cs_pin)
    {
        // Assert CS (active low)
        HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_RESET);
    }
    
    ~SpiTransaction() {
        // De-assert CS
        HAL_GPIO_WritePin(cs_port_, cs_pin_, GPIO_PIN_SET);
    }
    
    SpiTransaction(const SpiTransaction&) = delete;
    SpiTransaction& operator=(const SpiTransaction&) = delete;
    
    bool transmit(const uint8_t* data, uint16_t len, uint32_t timeout = 100) {
        return (HAL_SPI_Transmit(hspi_, const_cast<uint8_t*>(data), 
                                len, timeout) == HAL_OK);
    }
    
    bool receive(uint8_t* data, uint16_t len, uint32_t timeout = 100) {
        return (HAL_SPI_Receive(hspi_, data, len, timeout) == HAL_OK);
    }
    
    bool transceive(const uint8_t* tx_data, uint8_t* rx_data, uint16_t len, 
                   uint32_t timeout = 100) {
        return (HAL_SPI_TransmitReceive(hspi_, 
                                       const_cast<uint8_t*>(tx_data), 
                                       rx_data, len, timeout) == HAL_OK);
    }
    
private:
    SPI_HandleTypeDef* hspi_;
    GPIO_TypeDef* cs_port_;
    uint16_t cs_pin_;
};

#endif // SPI_TRANSACTION_HPP
