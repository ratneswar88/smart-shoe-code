#ifndef MOVING_AVERAGE_HPP
#define MOVING_AVERAGE_HPP

#include <cstdint>
#include <cstring>

/**
 * @brief Template-based moving average filter
 * 
 * Features:
 * - Type-safe (works with any numeric type)
 * - Fixed-size window (no dynamic allocation)
 * - O(1) complexity for add and get operations
 * - Zero runtime overhead (templates resolved at compile time)
 * 
 * Usage:
 *   MovingAverage<float, 10> tempFilter;
 *   tempFilter.add(23.5f);
 *   float avg = tempFilter.getAverage();
 */
template<typename T, size_t WINDOW_SIZE>
class MovingAverage {
public:
    MovingAverage() : index_(0), count_(0), sum_(0) {
        std::memset(buffer_, 0, sizeof(buffer_));
    }
    
    void add(T value) {
        // Subtract old value from sum
        sum_ -= buffer_[index_];
        
        // Add new value
        buffer_[index_] = value;
        sum_ += value;
        
        // Update index (circular buffer)
        index_ = (index_ + 1) % WINDOW_SIZE;
        
        // Track how many samples we have
        if (count_ < WINDOW_SIZE) {
            count_++;
        }
    }
    
    T getAverage() const {
        if (count_ == 0) return static_cast<T>(0);
        return sum_ / static_cast<T>(count_);
    }
    
    void reset() {
        std::memset(buffer_, 0, sizeof(buffer_));
        index_ = 0;
        count_ = 0;
        sum_ = static_cast<T>(0);
    }
    
    bool isFull() const { return count_ >= WINDOW_SIZE; }
    size_t getCount() const { return count_; }
    
private:
    T buffer_[WINDOW_SIZE];
    size_t index_;
    size_t count_;
    T sum_;
};

#endif // MOVING_AVERAGE_HPP
