#ifndef FIXED_VECTOR_HPP
#define FIXED_VECTOR_HPP

#include <cstdint>

/**
 * @brief Template-based fixed-size vector (no dynamic allocation)
 * 
 * Similar to std::vector but with fixed capacity.
 * Perfect for embedded systems where heap allocation is avoided.
 * 
 * Usage:
 *   FixedVector<Event, 32> eventQueue;
 *   eventQueue.push_back(myEvent);
 *   for (auto& event : eventQueue) {
 *       processEvent(event);
 *   }
 */
template<typename T, size_t MAX_SIZE>
class FixedVector {
public:
    FixedVector() : size_(0) {}
    
    bool push_back(const T& value) {
        if (size_ >= MAX_SIZE) {
            return false;  // Full
        }
        data_[size_++] = value;
        return true;
    }
    
    bool pop_back() {
        if (size_ == 0) {
            return false;  // Empty
        }
        size_--;
        return true;
    }
    
    // Array access (no bounds checking for performance)
    T& operator[](size_t index) {
        return data_[index];
    }
    
    const T& operator[](size_t index) const {
        return data_[index];
    }
    
    // Safe access with bounds checking
    T& at(size_t index) {
        if (index >= size_) {
            // Can't throw exceptions in embedded
            // Return first element as fallback
            return data_[0];
        }
        return data_[index];
    }
    
    const T& at(size_t index) const {
        if (index >= size_) {
            return data_[0];
        }
        return data_[index];
    }
    
    // Capacity functions
    size_t size() const { return size_; }
    size_t capacity() const { return MAX_SIZE; }
    bool empty() const { return size_ == 0; }
    bool full() const { return size_ >= MAX_SIZE; }
    
    void clear() { size_ = 0; }
    
    // Iterator support (enables range-based for loops)
    T* begin() { return data_; }
    T* end() { return data_ + size_; }
    const T* begin() const { return data_; }
    const T* end() const { return data_ + size_; }
    
private:
    T data_[MAX_SIZE];
    size_t size_;
};

#endif // FIXED_VECTOR_HPP
