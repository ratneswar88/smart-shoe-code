#ifndef MEDIAN_FILTER_HPP
#define MEDIAN_FILTER_HPP

#include <cstdint>
#include <cstring>
#include <algorithm>

/**
 * @brief Template-based median filter
 * 
 * Excellent for removing spikes and outliers from sensor data.
 * Window size must be odd for proper median calculation.
 * 
 * Usage:
 *   MedianFilter<int16_t, 5> accelFilter;
 *   accelFilter.add(raw_value);
 *   int16_t filtered = accelFilter.getMedian();
 */
template<typename T, size_t WINDOW_SIZE>
class MedianFilter {
public:
    static_assert(WINDOW_SIZE % 2 == 1, "Window size must be odd for proper median");
    
    MedianFilter() : index_(0), count_(0) {
        std::memset(buffer_, 0, sizeof(buffer_));
    }
    
    void add(T value) {
        buffer_[index_] = value;
        index_ = (index_ + 1) % WINDOW_SIZE;
        
        if (count_ < WINDOW_SIZE) {
            count_++;
        }
    }
    
    T getMedian() const {
        if (count_ == 0) return static_cast<T>(0);
        
        // Create sorted copy (don't modify original buffer)
        T sorted[WINDOW_SIZE];
        std::memcpy(sorted, buffer_, count_ * sizeof(T));
        
        // Sort the values
        std::sort(sorted, sorted + count_);
        
        // Return median (middle value)
        return sorted[count_ / 2];
    }
    
    void reset() {
        std::memset(buffer_, 0, sizeof(buffer_));
        index_ = 0;
        count_ = 0;
    }
    
    bool isFull() const { return count_ >= WINDOW_SIZE; }
    size_t getCount() const { return count_; }
    
private:
    T buffer_[WINDOW_SIZE];
    size_t index_;
    size_t count_;
};

#endif // MEDIAN_FILTER_HPP
