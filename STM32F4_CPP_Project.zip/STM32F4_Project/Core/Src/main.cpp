/**
 * @file main.cpp
 * @brief STM32F4 C++ Exercises - Complete Example
 * 
 * This file demonstrates all 4 exercises working together:
 * 1. UART Driver Class (Exercise 1)
 * 2. RAII Wrappers (Exercise 2)
 * 3. Template Data Structures (Exercise 3)
 * 4. Hardware Abstraction (Exercise 4)
 */

#include "main.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

// Exercise 1: UART Driver
#include "UartDriver.hpp"

// Exercise 2: RAII Wrappers
#include "MutexGuard.hpp"
#include "CriticalSection.hpp"
#include "SpiTransaction.hpp"

// Exercise 3: Template Data Structures
#include "MovingAverage.hpp"
#include "MedianFilter.hpp"
#include "FixedVector.hpp"

// Exercise 4: Hardware Abstraction
#include "ISensor.hpp"
#include "AccelSensor.hpp"

// HAL handles (initialized by STM32CubeMX generated code)
extern UART_HandleTypeDef huart2;
extern I2C_HandleTypeDef hi2c1;
extern SPI_HandleTypeDef hspi1;

// FreeRTOS objects
SemaphoreHandle_t dataMutex;

// Global objects (created once, used throughout program)
UartDriver* g_uart = nullptr;
AccelSensor* g_accel = nullptr;

// Event structure for FixedVector demonstration
struct SensorEvent {
    uint32_t timestamp;
    float x, y, z;
};

// Task function declarations
void sensorTask(void* parameter);
void loggingTask(void* parameter);

/**
 * @brief Main function
 */
int main(void) {
    // Initialize HAL
    HAL_Init();
    SystemClock_Config();
    
    // Initialize peripherals (STM32CubeMX generated)
    MX_GPIO_Init();
    MX_USART2_UART_Init();
    MX_I2C1_Init();
    MX_SPI1_Init();
    
    // Create UART driver (Exercise 1)
    static UartDriver uart(&huart2);
    g_uart = &uart;
    
    uart.transmitString("\r\n=== STM32F4 C++ Exercises ===\r\n");
    uart.transmitString("Compiled: " __DATE__ " " __TIME__ "\r\n\r\n");
    
    // Create accelerometer (Exercise 4)
    static AccelSensor accel(&hi2c1, 0x68);
    g_accel = &accel;
    
    if (accel.init()) {
        uart.transmitString("Accelerometer initialized!\r\n");
        
        // Calibrate sensor
        uart.transmitString("Calibrating... keep device still\r\n");
        if (accel.calibrate(50)) {
            uart.transmitString("Calibration complete!\r\n");
        }
    } else {
        uart.transmitString("Accelerometer init failed!\r\n");
    }
    
    // Create FreeRTOS mutex (Exercise 2)
    dataMutex = xSemaphoreCreateMutex();
    
    // Create tasks
    xTaskCreate(sensorTask, "Sensor", 256, NULL, 2, NULL);
    xTaskCreate(loggingTask, "Logging", 256, NULL, 1, NULL);
    
    uart.transmitString("Starting scheduler...\r\n\r\n");
    
    // Start scheduler
    vTaskStartScheduler();
    
    // Should never reach here
    while (1) {}
}

/**
 * @brief Sensor reading task
 * 
 * Demonstrates:
 * - Exercise 2: MutexGuard for thread-safe operations
 * - Exercise 3: MovingAverage and MedianFilter
 * - Exercise 4: Polymorphic sensor interface
 */
void sensorTask(void* parameter) {
    (void)parameter;
    
    // Exercise 3: Create filters
    MovingAverage<float, 10> avgFilter_x;
    MovingAverage<float, 10> avgFilter_y;
    MovingAverage<float, 10> avgFilter_z;
    
    MedianFilter<int16_t, 5> medianFilter_x;
    
    // Exercise 3: Event queue
    static FixedVector<SensorEvent, 100> eventQueue;
    
    while (1) {
        float x, y, z;
        
        // Read sensor (Exercise 4: polymorphism)
        if (g_accel && g_accel->read(x, y, z)) {
            
            // Exercise 3: Apply filters
            avgFilter_x.add(x);
            avgFilter_y.add(y);
            avgFilter_z.add(z);
            
            // For median filter, convert to int16_t
            int16_t x_int = static_cast<int16_t>(x * 1000);
            medianFilter_x.add(x_int);
            
            // Exercise 2: Thread-safe data access
            {
                MutexGuard lock(dataMutex);
                
                if (lock.isLocked()) {
                    // Store event in queue
                    SensorEvent event;
                    event.timestamp = HAL_GetTick();
                    event.x = avgFilter_x.getAverage();
                    event.y = avgFilter_y.getAverage();
                    event.z = avgFilter_z.getAverage();
                    
                    if (!eventQueue.push_back(event)) {
                        // Queue full, remove oldest
                        eventQueue.clear();
                        eventQueue.push_back(event);
                    }
                }
                // Mutex automatically released here!
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

/**
 * @brief Logging task
 * 
 * Demonstrates periodic logging with UART
 */
void loggingTask(void* parameter) {
    (void)parameter;
    
    uint32_t counter = 0;
    
    while (1) {
        // Exercise 2: Critical section for counter
        {
            CriticalSection cs;
            counter++;
        }
        
        // Log every second
        if (counter % 10 == 0) {
            char msg[128];
            
            // Exercise 2: Thread-safe data access
            {
                MutexGuard lock(dataMutex, pdMS_TO_TICKS(10));
                
                if (lock.isLocked()) {
                    float x, y, z;
                    if (g_accel && g_accel->read(x, y, z)) {
                        snprintf(msg, sizeof(msg),
                                "Accel: X=%.3f, Y=%.3f, Z=%.3f g\r\n",
                                x, y, z);
                        
                        if (g_uart) {
                            g_uart->transmitString(msg);
                        }
                    }
                }
            }
        }
        
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}

/**
 * @brief SPI Example Function (not called in this demo)
 * 
 * Demonstrates Exercise 2: SpiTransaction RAII wrapper
 */
void readSpiSensor() {
    // Exercise 2: SPI transaction with automatic CS control
    {
        SpiTransaction spi(&hspi1, GPIOA, GPIO_PIN_4);
        
        uint8_t tx_data[2] = {0x80, 0x00};  // Read register 0x00
        uint8_t rx_data[2];
        
        if (spi.transceive(tx_data, rx_data, 2)) {
            // Process rx_data[1]
        }
        
        // CS automatically released when spi goes out of scope!
    }
}

/**
 * @brief Error handler
 */
void Error_Handler(void) {
    __disable_irq();
    while (1) {
        // Blink LED or log error
    }
}
