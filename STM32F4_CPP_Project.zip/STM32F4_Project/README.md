# STM32F4 C++ Practice Exercises

Complete, production-ready C++ code for STM32F4 demonstrating modern C++ practices for embedded systems.

## Overview

This project contains 4 comprehensive exercises that teach C++ for embedded systems:

1. **Exercise 1: Class-Based UART Driver**
   - Encapsulation and RAII
   - Constructor/Destructor resource management
   - Deleted copy operations

2. **Exercise 2: RAII Wrappers**
   - MutexGuard (FreeRTOS semaphores)
   - CriticalSection (interrupt disabling)
   - SpiTransaction (automatic CS control)

3. **Exercise 3: Template Data Structures**
   - MovingAverage (signal smoothing)
   - MedianFilter (spike removal)
   - FixedVector (no heap allocation)

4. **Exercise 4: Hardware Abstraction**
   - Abstract base class (ISensor)
   - Derived sensor classes
   - Polymorphism without vtable overhead

## Prerequisites

- **Hardware**: STM32F4 Discovery board (or any STM32F4xx)
- **IDE**: STM32CubeIDE 1.9 or later
- **Compiler**: ARM GCC with C++17 support
- **RTOS**: FreeRTOS (included in STM32CubeMX)

## Hardware Connections

### Default Configuration (STM32F407VG Discovery)
- **UART2**: PA9 (TX), PA10 (RX) - 115200 baud
- **I2C1**: PB6 (SCL), PB7 (SDA) - for accelerometer
- **SPI1**: PA5 (SCK), PA6 (MISO), PA7 (MOSI), PA4 (CS)
- **LED**: PD12-PD15 (built-in LEDs)

### Optional Sensor
- ICM-42688 or MPU-6050 accelerometer on I2C1 (address 0x68)

## Project Structure

```
STM32F4_Project/
├── Application/
│   ├── Exercise1/           # UART Driver
│   │   ├── UartDriver.hpp
│   │   └── UartDriver.cpp
│   ├── Exercise2/           # RAII Wrappers
│   │   ├── MutexGuard.hpp
│   │   ├── CriticalSection.hpp
│   │   └── SpiTransaction.hpp
│   ├── Exercise3/           # Templates
│   │   ├── MovingAverage.hpp
│   │   ├── MedianFilter.hpp
│   │   └── FixedVector.hpp
│   └── Exercise4/           # Hardware Abstraction
│       ├── ISensor.hpp
│       ├── AccelSensor.hpp
│       └── AccelSensor.cpp
├── Core/
│   ├── Inc/                 # Headers
│   └── Src/
│       └── main.cpp         # Complete example
└── README.md
```

## Setup Instructions

### 1. Create New STM32CubeIDE Project

1. Open STM32CubeIDE
2. File → New → STM32 Project
3. Select your board (e.g., STM32F407VG Discovery)
4. Name: `STM32F4_CPP_Exercises`
5. Finish

### 2. Enable C++17 and Configure Compiler

Right-click project → Properties:

**C/C++ Build → Settings → MCU G++ Compiler → Miscellaneous:**
```
-std=c++17
-fno-exceptions
-fno-rtti
-fno-use-cxa-atexit
```

**C/C++ Build → Settings → MCU G++ Compiler → Optimization:**
```
-O2  (or -Os for size)
```

**C/C++ Build → Settings → MCU G++ Compiler → Warnings:**
```
-Wall -Wextra
```

### 3. Configure Peripherals in STM32CubeMX

Open `.ioc` file and configure:

**Pinout & Configuration:**
- **USART2**: Asynchronous mode, 115200 baud
- **I2C1**: I2C mode, 100 kHz
- **SPI1**: Full-Duplex Master
- **FreeRTOS**: CMSIS_V2 interface, heap_4

**Middleware → FreeRTOS:**
- Enable FreeRTOS
- Tasks: Set stack size to 256 words minimum
- Mutexes: Enable at least 1

**Clock Configuration:**
- HSE: 8 MHz (Crystal/Ceramic Resonator)
- HCLK: 168 MHz

Generate code.

### 4. Copy Files to Project

Copy all files from this package to your project:
```bash
cp -r Application/* <your_project>/Application/
cp Core/Src/main.cpp <your_project>/Core/Src/
```

### 5. Add Include Paths

Project Properties → C/C++ General → Paths and Symbols → Includes:

Add these paths:
```
${workspace_loc:/${ProjName}/Application/Exercise1}
${workspace_loc:/${ProjName}/Application/Exercise2}
${workspace_loc:/${ProjName}/Application/Exercise3}
${workspace_loc:/${ProjName}/Application/Exercise4}
```

### 6. Exclude from Build (Optional)

If not using all exercises, right-click unused folders → Resource Configurations → Exclude from Build.

### 7. Build and Flash

1. Build: Project → Build Project (Ctrl+B)
2. Flash: Run → Debug (F11) or Run (Ctrl+F11)
3. Open serial terminal (115200 baud, 8N1)

## Usage Examples

### Exercise 1: UART Driver

```cpp
UartDriver uart(&huart2);
uart.transmitString("Hello World!\r\n");

if (uart.available()) {
    uint8_t data = uart.read();
    uart.transmit(&data, 1);  // Echo
}
```

### Exercise 2: RAII Wrappers

```cpp
// Mutex automatically released
{
    MutexGuard lock(myMutex);
    sharedData++;
}  // Released here

// Critical section
{
    CriticalSection cs;
    atomicCounter++;
}  // Interrupts re-enabled

// SPI transaction
{
    SpiTransaction spi(&hspi1, GPIOA, GPIO_PIN_4);
    uint8_t data = 0x42;
    spi.transmit(&data, 1);
}  // CS de-asserted
```

### Exercise 3: Templates

```cpp
MovingAverage<float, 10> tempFilter;
tempFilter.add(23.5f);
float avg = tempFilter.getAverage();

MedianFilter<int16_t, 5> accelFilter;
accelFilter.add(raw_value);
int16_t filtered = accelFilter.getMedian();

FixedVector<Event, 32> eventQueue;
eventQueue.push_back(myEvent);
for (auto& event : eventQueue) {
    processEvent(event);
}
```

### Exercise 4: Hardware Abstraction

```cpp
AccelSensor accel(&hi2c1, 0x68);
accel.init();

float x, y, z;
if (accel.read(x, y, z)) {
    printf("X: %.2f g\r\n", x);
}

// Polymorphism
ISensor* sensor = &accel;
sensor->read(x, y, z);
```

## Testing Checklist

- [ ] UART receives and echoes characters
- [ ] Mutex prevents race conditions
- [ ] Filters smooth noisy data
- [ ] Sensor reads successfully (if connected)
- [ ] No memory leaks (check heap usage)
- [ ] No dynamic allocation used

## Troubleshooting

### Linker Error: "undefined reference to operator new"
**Solution**: Don't use `new`/`delete`. All objects should be stack or static.

### Code Size Too Large
**Solution**: 
- Use `-Os` optimization
- Enable LTO (Link Time Optimization)
- Remove unused exercises

### C and C++ Mixing Issues
**Solution**: Use `extern "C"` for C functions:
```cpp
extern "C" {
    void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
}
```

### Build Errors After Adding Files
**Solution**: Clean and rebuild (Project → Clean)

## Performance Notes

- **Zero Overhead**: Templates generate code at compile time
- **No Exceptions**: `-fno-exceptions` removes exception handling overhead
- **No RTTI**: `-fno-rtti` removes runtime type information
- **Stack Allocated**: No heap fragmentation
- **Inline Functions**: Small functions automatically inlined

## Next Steps

1. Combine all exercises in one system
2. Add unit tests (Google Test)
3. Implement state machines with `enum class`
4. Add USB CDC class for logging
5. Port to Zephyr RTOS

## Resources

- [STM32F4 Reference Manual](https://www.st.com/resource/en/reference_manual/dm00031020.pdf)
- [FreeRTOS Documentation](https://www.freertos.org/Documentation/RTOS_book.html)
- [Modern C++ for Embedded](https://github.com/PacktPublishing/Embedded-Systems-Architecture)

## License

MIT License - Free to use for learning and commercial projects.

## Author

Created for STM32F4 C++ learning exercises.

---

**Happy Embedded C++ Coding! 🚀**
