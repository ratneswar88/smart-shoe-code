#ifndef BIT_MANIPULATION_GUIDE_HPP
#define BIT_MANIPULATION_GUIDE_HPP

#include <cstdint>

/**
 * @file BitManipulation.hpp
 * @brief Comprehensive guide to bit manipulation in embedded systems
 * 
 * FUNDAMENTAL CONCEPTS:
 * ====================
 * 
 * Bits: Binary digits, can be 0 or 1
 * Registers: Collections of bits (usually 32-bit in STM32F4)
 * 
 * 32-bit Register Layout:
 * [31][30][29]...[3][2][1][0]
 *  MSB                      LSB
 * 
 * Each bit can control different hardware features.
 */

// ============================================================================
// OPERATION 1: SET BIT (Turn ON a bit)
// ============================================================================

/**
 * Formula: REG |= (1 << bit)
 * 
 * DETAILED EXPLANATION:
 * ---------------------
 * 
 * Step 1: Create a mask with only the target bit set
 *   (1 << 5) creates: 0b00100000
 * 
 * Step 2: OR with register
 *   OR operator rule: X | 1 = 1 (forces bit to 1)
 *                     X | 0 = X (keeps bit unchanged)
 * 
 * Example: Set bit 5
 * Before:  REG = 0b00010010  (bits 1, 4 set)
 * Mask:         (1 << 5) = 0b00100000
 * Operation:    REG |= (1 << 5)
 * After:   REG = 0b00110010  (bits 1, 4, 5 set)
 * 
 * WHY THIS WORKS:
 *   Position 5: 0 | 1 = 1 (bit gets set)
 *   Position 4: 1 | 0 = 1 (stays set)
 *   Position 1: 1 | 0 = 1 (stays set)
 *   Others:     0 | 0 = 0 (stay clear)
 */
inline void set_bit_example() {
    volatile uint32_t reg = 0b00010010;  // Initial: bits 1, 4
    
    // Set bit 5
    reg |= (1 << 5);
    // Result: 0b00110010 (bits 1, 4, 5)
    
    // Set multiple bits at once
    reg |= (1 << 7) | (1 << 12);
    // Result: bits 1, 4, 5, 7, 12 are all set
}

/**
 * REAL HARDWARE EXAMPLE: Turn on LED
 */
inline void LED_On_Example() {
    // STM32F4 Discovery has LED on PD12
    // GPIOD Output Data Register (ODR) controls pin state
    
    // Turn on LED (set bit 12)
    // GPIOD->ODR |= (1 << 12);
    
    // Visual representation:
    // Before: GPIOD->ODR = 0b0000000000000000
    // After:  GPIOD->ODR = 0b0001000000000000
    //                            ↑ bit 12
}

// ============================================================================
// OPERATION 2: CLEAR BIT (Turn OFF a bit)
// ============================================================================

/**
 * Formula: REG &= ~(1 << bit)
 * 
 * DETAILED EXPLANATION:
 * ---------------------
 * 
 * Step 1: Create a mask with only the target bit set
 *   (1 << 4) creates: 0b00010000
 * 
 * Step 2: Invert the mask using NOT (~)
 *   ~(1 << 4) creates: 0b11101111
 *   (All bits are 1 EXCEPT bit 4)
 * 
 * Step 3: AND with register
 *   AND operator rule: X & 1 = X (keeps bit unchanged)
 *                      X & 0 = 0 (forces bit to 0)
 * 
 * Example: Clear bit 4
 * Before:  REG = 0b00110010  (bits 1, 4, 5 set)
 * Mask:    (1 << 4) = 0b00010000
 * Invert: ~(1 << 4) = 0b11101111
 * Operation: REG &= ~(1 << 4)
 * After:   REG = 0b00100010  (bits 1, 5 set; bit 4 cleared)
 * 
 * WHY THIS WORKS:
 *   Position 4: 1 & 0 = 0 (bit gets cleared)
 *   Position 5: 1 & 1 = 1 (stays set)
 *   Position 1: 1 & 1 = 1 (stays set)
 *   Others:     0 & 1 = 0 (stay clear)
 */
inline void clear_bit_example() {
    volatile uint32_t reg = 0b00110010;  // Initial: bits 1, 4, 5
    
    // Clear bit 4
    reg &= ~(1 << 4);
    // Result: 0b00100010 (bits 1, 5; bit 4 cleared)
    
    // Clear multiple bits
    reg &= ~((1 << 1) | (1 << 5));
    // Result: 0b00000000 (all cleared)
}

/**
 * REAL HARDWARE EXAMPLE: Turn off LED
 */
inline void LED_Off_Example() {
    // Turn off LED on PD12 (clear bit 12)
    // GPIOD->ODR &= ~(1 << 12);
    
    // Step by step:
    // 1. (1 << 12)  = 0b0001000000000000
    // 2. ~(1 << 12) = 0b1110111111111111
    // 3. AND with ODR clears only bit 12, keeps others
}

// ============================================================================
// OPERATION 3: TOGGLE BIT (Flip state: 0→1 or 1→0)
// ============================================================================

/**
 * Formula: REG ^= (1 << bit)
 * 
 * DETAILED EXPLANATION:
 * ---------------------
 * 
 * Step 1: Create a mask with only the target bit set
 *   (1 << 5) creates: 0b00100000
 * 
 * Step 2: XOR with register
 *   XOR operator rule: 0 ^ 1 = 1 (0 flips to 1)
 *                      1 ^ 1 = 0 (1 flips to 0)
 *                      X ^ 0 = X (bit unchanged)
 * 
 * Example: Toggle bit 5
 * Before:  REG = 0b00110010  (bit 5 is 1)
 * Mask:         (1 << 5) = 0b00100000
 * Operation:    REG ^= (1 << 5)
 * After:   REG = 0b00010010  (bit 5 is now 0)
 * 
 * Toggle again:
 * Before:  REG = 0b00010010  (bit 5 is 0)
 * Operation:    REG ^= (1 << 5)
 * After:   REG = 0b00110010  (bit 5 is now 1 again!)
 * 
 * WHY THIS WORKS:
 *   XOR with 1: Flips bit
 *   XOR with 0: Keeps bit unchanged
 */
inline void toggle_bit_example() {
    volatile uint32_t reg = 0b00110010;  // Initial: bit 5 = 1
    
    // First toggle
    reg ^= (1 << 5);
    // Result: 0b00010010 (bit 5 now 0)
    
    // Second toggle
    reg ^= (1 << 5);
    // Result: 0b00110010 (bit 5 back to 1)
}

/**
 * REAL HARDWARE EXAMPLE: Blink LED
 */
inline void LED_Toggle_Example() {
    // Toggle LED on PD12
    // GPIOD->ODR ^= (1 << 12);
    
    // First call:  LED OFF → ON
    // Second call: LED ON  → OFF
    // Third call:  LED OFF → ON
    // Perfect for blinking!
}

// ============================================================================
// OPERATION 4: READ BIT (Check if bit is set or clear)
// ============================================================================

/**
 * Formula: (REG & (1 << bit))
 * 
 * DETAILED EXPLANATION:
 * ---------------------
 * 
 * Step 1: Create a mask with only the target bit set
 *   (1 << 5) creates: 0b00100000
 * 
 * Step 2: AND with register
 *   AND operator extracts only the bit we care about
 *   Result is non-zero if bit is set, zero if clear
 * 
 * Example: Check if bit 5 is set
 * Register: REG = 0b00110010  (bit 5 is 1)
 * Mask:          (1 << 5) = 0b00100000
 * Operation:     REG & (1 << 5)
 * Result:        0b00100000 = 32 (non-zero = TRUE)
 * 
 * Check bit 3 (which is 0):
 * Register: REG = 0b00110010  (bit 3 is 0)
 * Mask:          (1 << 3) = 0b00001000
 * Operation:     REG & (1 << 3)
 * Result:        0b00000000 = 0 (zero = FALSE)
 * 
 * WHY THIS WORKS:
 *   AND with 1: If bit is 1, result = 1
 *               If bit is 0, result = 0
 *   AND with 0: Always gives 0 (masks out other bits)
 */
inline void read_bit_example() {
    volatile uint32_t reg = 0b00110010;  // Bits 1, 4, 5 set
    
    // Check bit 5 (is set)
    if (reg & (1 << 5)) {
        // This executes! Result is 0b00100000 (non-zero)
    }
    
    // Check bit 3 (is clear)
    if (reg & (1 << 3)) {
        // This doesn't execute. Result is 0 (zero)
    }
    
    // Extract bit value as 0 or 1
    uint8_t bit5_value = (reg >> 5) & 1;
    // Result: 1 (because bit 5 is set)
    
    uint8_t bit3_value = (reg >> 3) & 1;
    // Result: 0 (because bit 3 is clear)
}

/**
 * REAL HARDWARE EXAMPLE: Read button state
 */
inline void Button_Read_Example() {
    // Check if button pressed on PA0
    // Buttons are read from Input Data Register (IDR)
    
    // if (GPIOA->IDR & (1 << 0)) {
    //     // Button pressed! (bit 0 is high)
    //     LED_On();
    // } else {
    //     // Button not pressed (bit 0 is low)
    //     LED_Off();
    // }
}

// ============================================================================
// ADVANCED PATTERNS
// ============================================================================

/**
 * PATTERN 1: Set specific bits, clear others in a field
 * 
 * Problem: Configure bits 4-6 to pattern 101b
 * Solution: Clear field, then set pattern
 */
inline void configure_bit_field() {
    volatile uint32_t reg = 0xFF;  // All bits set
    
    // Goal: Set bits 4-6 to 0b101
    
    // Method 1: Two operations
    reg &= ~(0b111 << 4);  // Clear bits 4-6 (000)
    reg |= (0b101 << 4);   // Set pattern (101)
    
    // Method 2: Single operation
    reg = (reg & ~(0b111 << 4)) | (0b101 << 4);
    
    // Visual:
    // Start:  0b11111111
    // Clear:  0b10001111  (bits 4-6 cleared)
    // Set:    0b10101111  (bits 4-6 = 101)
}

/**
 * PATTERN 2: Read multi-bit field
 * 
 * Extract value from bits 8-10 (3-bit field)
 */
inline uint32_t read_bit_field() {
    volatile uint32_t reg = 0xF3A5;  // Example value
    
    // Extract 3-bit field from bits 8-10
    uint32_t field_value = (reg >> 8) & 0b111;
    
    // Step by step:
    // reg = 0xF3A5 = 0b1111001110100101
    // Shift right 8: 0b11110011
    // Mask 3 bits:   0b00000011 = 3
    
    return field_value;
}

/**
 * PATTERN 3: Check multiple bits
 */
inline void check_multiple_bits() {
    volatile uint32_t reg = 0b00110010;
    
    // Check if ANY of bits 1, 5, 7 are set
    if (reg & ((1 << 1) | (1 << 5) | (1 << 7))) {
        // True if at least one is set
    }
    
    // Check if ALL of bits 1, 4, 5 are set
    uint32_t mask = (1 << 1) | (1 << 4) | (1 << 5);
    if ((reg & mask) == mask) {
        // True only if all three are set
    }
}

/**
 * PATTERN 4: Atomic bit operations (important for interrupts!)
 */
inline void atomic_operations() {
    // PROBLEM: Normal read-modify-write is not atomic
    // If interrupt occurs during operation, can cause race condition
    
    // NON-ATOMIC (dangerous with interrupts):
    // REG |= (1 << 5);  // Read, modify, write - 3 steps
    
    // ATOMIC SOLUTION 1: Disable interrupts
    // __disable_irq();
    // REG |= (1 << 5);
    // __enable_irq();
    
    // ATOMIC SOLUTION 2: Use hardware atomic registers
    // STM32 has BSRR (Bit Set/Reset Register) for GPIO
    // GPIOD->BSRR = (1 << 12);      // Set bit 12 (atomic!)
    // GPIOD->BSRR = (1 << (12+16)); // Clear bit 12 (atomic!)
    
    // BSRR is single-write operation, no read needed!
}

// ============================================================================
// PRACTICAL EXAMPLES FROM STM32
// ============================================================================

/**
 * Example 1: Configure GPIO as Output
 */
inline void GPIO_Configure_Output() {
    // Goal: Configure PD12 as output
    
    // MODER register: 2 bits per pin
    // Pin 12 uses bits 24-25
    // Values: 00=Input, 01=Output, 10=AF, 11=Analog
    
    // Step 1: Clear bits 24-25
    // GPIOD->MODER &= ~(0b11 << 24);
    
    // Step 2: Set to 01 (output)
    // GPIOD->MODER |= (0b01 << 24);
    
    // Or combined:
    // GPIOD->MODER = (GPIOD->MODER & ~(3 << 24)) | (1 << 24);
}

/**
 * Example 2: Set UART Baud Rate
 */
inline void UART_Set_Baud() {
    // BRR register format:
    // Bits [15:4] = Mantissa
    // Bits [3:0]  = Fraction
    
    uint32_t mantissa = 22;
    uint32_t fraction = 12;
    
    // Combine into BRR register
    // USART2->BRR = (mantissa << 4) | fraction;
    
    // Visual:
    // mantissa (22) = 0x16
    // Shift left 4:   0x160
    // fraction (12) = 0x00C
    // OR together:    0x16C
}

/**
 * Example 3: Enable UART Interrupt
 */
inline void UART_Enable_RX_Interrupt() {
    // Enable RXNE interrupt (bit 5 of CR1)
    // USART2->CR1 |= (1 << 5);
    
    // Or use named constant
    // USART2->CR1 |= USART_CR1_RXNEIE;
    
    // Both do the same thing: set bit 5
}

/**
 * Example 4: Wait for Flag
 */
inline void UART_Wait_TX_Ready() {
    // Wait for TXE flag (bit 7 of SR)
    // while (!(USART2->SR & (1 << 7))) {
    //     // Wait until bit 7 is set
    // }
    
    // Or with named constant
    // while (!(USART2->SR & USART_SR_TXE)) {
    //     // Same thing, more readable
    // }
}

// ============================================================================
// COMMON MISTAKES TO AVOID
// ============================================================================

/**
 * MISTAKE 1: Using = instead of |=
 */
inline void mistake_assignment() {
    volatile uint32_t reg = 0xFF;
    
    // WRONG! This overwrites entire register
    // reg = (1 << 5);  // Result: 0x20, all other bits lost!
    
    // CORRECT! This sets only bit 5
    reg |= (1 << 5);  // Result: 0xFF (bit 5 was already set)
}

/**
 * MISTAKE 2: Forgetting parentheses
 */
inline void mistake_parentheses() {
    volatile uint32_t reg = 0;
    
    // WRONG! Operator precedence issue
    // reg |= 1 << 5 | 1 << 7;
    // Parsed as: reg |= (1 << (5 | 1) << 7)
    
    // CORRECT!
    reg |= (1 << 5) | (1 << 7);
}

/**
 * MISTAKE 3: Not using volatile
 */
inline void mistake_volatile() {
    // WRONG! Compiler may optimize away
    // uint32_t* reg = (uint32_t*)0x40020C00;
    // *reg |= (1 << 5);  // May not actually write!
    
    // CORRECT! Forces hardware access
    volatile uint32_t* reg = (volatile uint32_t*)0x40020C00;
    *reg |= (1 << 5);  // Guaranteed write
}

/**
 * MISTAKE 4: Wrong bit number
 */
inline void mistake_bit_number() {
    // Remember: Bits are 0-indexed!
    
    // For 16-bit register (bits 0-15):
    // WRONG: (1 << 16)  // Bit 16 doesn't exist!
    // CORRECT: (1 << 15)  // Bit 15 is the last one
    
    // For 32-bit register (bits 0-31):
    // WRONG: (1 << 32)  // Bit 32 doesn't exist!
    // CORRECT: (1 << 31)  // Bit 31 is the last one
}

// ============================================================================
// SUMMARY: THE FOUR FUNDAMENTAL OPERATIONS
// ============================================================================

/**
 * 1. SET BIT (turn ON):     REG |= (1 << bit)
 *    - OR with 1 forces bit to 1
 *    - OR with 0 keeps bit unchanged
 * 
 * 2. CLEAR BIT (turn OFF):  REG &= ~(1 << bit)
 *    - NOT inverts mask (all 1s except target bit)
 *    - AND with 0 forces bit to 0
 *    - AND with 1 keeps bit unchanged
 * 
 * 3. TOGGLE BIT (flip):     REG ^= (1 << bit)
 *    - XOR with 1 flips bit (0→1, 1→0)
 *    - XOR with 0 keeps bit unchanged
 * 
 * 4. READ BIT (check):      if (REG & (1 << bit))
 *    - AND extracts only target bit
 *    - Non-zero = bit is set
 *    - Zero = bit is clear
 */

#endif // BIT_MANIPULATION_GUIDE_HPP
