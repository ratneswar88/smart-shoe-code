/*******************************************************************************
 * BIT MANIPULATION QUICK REFERENCE CHEAT SHEET
 * ============================================================================
 * 
 * BASIC OPERATIONS:
 * 
 * SET BIT        REG |= (1 << n)        Turn bit ON
 * CLEAR BIT      REG &= ~(1 << n)       Turn bit OFF
 * TOGGLE BIT     REG ^= (1 << n)        Flip bit state
 * READ BIT       if (REG & (1 << n))    Check if bit is set
 * 
 ******************************************************************************/

// ============================================================================
// VISUAL EXAMPLES
// ============================================================================

Initial:  REG = 0b00010010  (bits 1, 4 set)

// SET bit 5
REG |= (1 << 5);
Result:   REG = 0b00110010  (bits 1, 4, 5 set)

// CLEAR bit 4
REG &= ~(1 << 4);
Result:   REG = 0b00100010  (bits 1, 5 set)

// TOGGLE bit 1
REG ^= (1 << 1);
Result:   REG = 0b00100000  (only bit 5 set)

// READ bit 5
if (REG & (1 << 5))  → TRUE (bit 5 is set)

// ============================================================================
// BITWISE OPERATORS
// ============================================================================

<<  Left Shift   : 1 << 3  = 0b00001000 = 8
>>  Right Shift  : 8 >> 3  = 0b00000001 = 1

|   OR           : 0b0101 | 0b0011 = 0b0111  (set bits)
&   AND          : 0b0101 & 0b0011 = 0b0001  (mask bits)
^   XOR          : 0b0101 ^ 0b0011 = 0b0110  (toggle bits)
~   NOT          : ~0b0101 = 0b1010          (invert bits)

// ============================================================================
// COMMON PATTERNS
// ============================================================================

// Set multiple bits
REG |= (1 << 5) | (1 << 7) | (1 << 12);

// Clear multiple bits
REG &= ~((1 << 5) | (1 << 7));

// Configure 3-bit field to value
#define FIELD_POS 4
#define FIELD_MASK 0x7
REG &= ~(FIELD_MASK << FIELD_POS);  // Clear
REG |= (value << FIELD_POS);        // Set

// Read multi-bit field
value = (REG >> FIELD_POS) & FIELD_MASK;

// Check if ANY bits set
if (REG & ((1 << 3) | (1 << 5)))  // True if bit 3 OR 5 set

// Check if ALL bits set
mask = (1 << 3) | (1 << 5);
if ((REG & mask) == mask)  // True only if BOTH set

// ============================================================================
// STM32 PRACTICAL EXAMPLES
// ============================================================================

// Turn on LED (PD12)
GPIOD->ODR |= (1 << 12);

// Turn off LED (PD12)
GPIOD->ODR &= ~(1 << 12);

// Toggle LED (PD12)
GPIOD->ODR ^= (1 << 12);

// Check button (PA0)
if (GPIOA->IDR & (1 << 0)) {
    // Button pressed
}

// Configure GPIO as output (PD12, bits 24-25 in MODER)
GPIOD->MODER &= ~(3 << 24);  // Clear 2 bits
GPIOD->MODER |= (1 << 24);   // Set to 01 (output)

// Enable UART RX interrupt (bit 5)
USART2->CR1 |= USART_CR1_RXNEIE;

// Wait for TX ready (bit 7)
while (!(USART2->SR & USART_SR_TXE));

// Set baud rate register
USART2->BRR = (mantissa << 4) | fraction;

// ============================================================================
// BIT POSITIONS (POWERS OF 2)
// ============================================================================

Bit 0  = 0x0001 = 1
Bit 1  = 0x0002 = 2
Bit 2  = 0x0004 = 4
Bit 3  = 0x0008 = 8
Bit 4  = 0x0010 = 16
Bit 5  = 0x0020 = 32
Bit 6  = 0x0040 = 64
Bit 7  = 0x0080 = 128
Bit 8  = 0x0100 = 256
Bit 9  = 0x0200 = 512
Bit 10 = 0x0400 = 1024
Bit 11 = 0x0800 = 2048
Bit 12 = 0x1000 = 4096
Bit 15 = 0x8000 = 32768
Bit 31 = 0x80000000 = 2147483648

// ============================================================================
// HEXADECIMAL <-> BINARY CONVERSION
// ============================================================================

Hex:   0    1    2    3    4    5    6    7
Bin: 0000 0001 0010 0011 0100 0101 0110 0111

Hex:   8    9    A    B    C    D    E    F
Bin: 1000 1001 1010 1011 1100 1101 1110 1111

Example: 0xA5 = 0b10100101
         A=1010, 5=0101

// ============================================================================
// COMMON MISTAKES
// ============================================================================

WRONG: REG = (1 << 5);     // Overwrites entire register!
RIGHT: REG |= (1 << 5);    // Sets only bit 5

WRONG: *reg |= (1 << 5);   // May be optimized away
RIGHT: *(volatile uint32_t*)reg |= (1 << 5);

WRONG: REG |= 1 << 5 | 1 << 7;     // Precedence issue
RIGHT: REG |= (1 << 5) | (1 << 7);  // Clear with parentheses

// ============================================================================
// ATOMIC OPERATIONS (for interrupts)
// ============================================================================

// Method 1: Disable interrupts
__disable_irq();
REG |= (1 << 5);
__enable_irq();

// Method 2: Use hardware atomic operations
GPIOD->BSRR = (1 << 12);      // Set bit 12 (atomic)
GPIOD->BSRR = (1 << (12+16)); // Clear bit 12 (atomic)

// ============================================================================
// REMEMBER:
// ============================================================================

1. Bits are 0-indexed (first bit is bit 0)
2. Always use volatile for hardware registers
3. Use parentheses to clarify precedence
4. Set = OR, Clear = AND with inverted mask
5. Toggle = XOR, Read = AND then check if non-zero
6. (1 << n) creates a mask with only bit n set

/*******************************************************************************
 * END OF CHEAT SHEET
 ******************************************************************************/
