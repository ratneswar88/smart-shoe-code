# STM32 Bare Metal Project Generator - Quick Start Guide

## What This Script Does

This Python script automatically generates a complete bare metal STM32 project structure with:
- ✓ Linker script (.ld file)
- ✓ Startup assembly code
- ✓ System initialization (SystemInit)
- ✓ Main.c template with GPIO example
- ✓ Makefile for command-line compilation
- ✓ Proper directory structure
- ✓ README and .gitignore

**No HAL or LL libraries** - pure register-level programming!

## Usage

### Basic Syntax
```bash
python3 stm32_baremetal_generator.py -n PROJECT_NAME -f FAMILY -m MODEL -flash FLASH_KB -ram RAM_KB
```

### Common Examples

#### STM32F407VG (Discovery Board)
```bash
python3 stm32_baremetal_generator.py -n MyDiscovery -f STM32F4 -m STM32F407VG -flash 1024 -ram 192
```

#### STM32F103C8 (Blue Pill)
```bash
python3 stm32_baremetal_generator.py -n BluePill -f STM32F1 -m STM32F103C8 -flash 64 -ram 20
```

#### STM32F411CE (Black Pill)
```bash
python3 stm32_baremetal_generator.py -n BlackPill -f STM32F4 -m STM32F411CE -flash 512 -ram 128
```

#### STM32L476RG (Nucleo Board)
```bash
python3 stm32_baremetal_generator.py -n NucleoL476 -f STM32L4 -m STM32L476RG -flash 1024 -ram 128
```

#### STM32H743ZI (Nucleo-144)
```bash
python3 stm32_baremetal_generator.py -n NucleoH7 -f STM32H7 -m STM32H743ZI -flash 2048 -ram 1024
```

## Arguments

| Argument | Description | Example |
|----------|-------------|---------|
| `-n` or `--name` | Project name (required) | `MyProject` |
| `-f` or `--family` | MCU family (required) | `STM32F4` |
| `-m` or `--model` | MCU model (required) | `STM32F407VG` |
| `-flash` or `--flash-size` | Flash size in KB (required) | `1024` |
| `-ram` or `--ram-size` | RAM size in KB (required) | `192` |

## After Generation

### 1. Download CMSIS Headers
You need the CMSIS headers for your specific MCU family. Get them from:
- ST's official website: [STM32Cube MCU Packages](https://www.st.com/en/embedded-software/stm32cube-mcu-mpu-packages.html)
- Or extract from STM32CubeIDE installation

Required files:
```
Drivers/CMSIS/Include/
├── core_cm4.h
├── cmsis_gcc.h
└── cmsis_version.h

Drivers/CMSIS/Device/STM32F4/Include/
├── stm32f4xx.h
├── stm32f407xx.h  (or your specific model)
└── system_stm32f4xx.h
```

### 2. Build the Project
```bash
cd YourProjectName
make
```

### 3. Flash to Board

**Using ST-Link:**
```bash
st-flash write build/YourProject.bin 0x8000000
```

**Using OpenOCD:**
```bash
openocd -f interface/stlink.cfg -f target/stm32f4x.cfg \
  -c "program build/YourProject.elf verify reset exit"
```

**Using STM32CubeProgrammer GUI:**
- Open STM32CubeProgrammer
- Connect to your board
- Load the .hex or .bin file
- Click "Download"

### 4. Debug (Optional)
```bash
# Terminal 1: Start OpenOCD
openocd -f interface/stlink.cfg -f target/stm32f4x.cfg

# Terminal 2: Start GDB
arm-none-eabi-gdb build/YourProject.elf
(gdb) target remote localhost:3333
(gdb) load
(gdb) monitor reset halt
(gdb) continue
```

## Project Structure

The generated project looks like:
```
YourProject/
├── Core/
│   ├── Inc/                    # Your header files go here
│   └── Src/
│       ├── main.c              # Your main application
│       └── system_stm32xx.c    # System initialization
├── Startup/
│   └── startup_stm32xxx.s      # Startup assembly code
├── Drivers/
│   └── CMSIS/                  # You add CMSIS headers here
├── build/                      # Build output (created by make)
├── Makefile                    # Build configuration
├── STM32XXX_FLASH.ld          # Linker script
├── README.md                   # Project documentation
└── .gitignore
```

## Customization Tips

### Change LED Pin
Edit `main.c` and modify:
```c
// Change from PD12 to PA5 (common on Nucleo boards)
GPIOD->ODR ^= GPIO_ODR_OD12;  // Old
GPIOA->ODR ^= GPIO_ODR_OD5;   // New

// Don't forget to update GPIO_Init() too!
```

### Add Your Own Peripheral Init
Add functions in `main.c`:
```c
void UART_Init(void);
void Timer_Init(void);
void ADC_Init(void);
// etc.
```

### Modify Clock Settings
Edit `system_stm32xx.c` to configure PLL for higher speeds:
```c
void SystemInit(void) {
    // Your clock configuration here
    // Configure PLL for 168MHz (F4) or your target speed
}
```

### Add Interrupt Handlers
In `startup_xxx.s`, add your ISR handlers and update the vector table:
```c
void USART1_IRQHandler(void) {
    // Your UART interrupt code
}
```

## Common Issues

### Issue: "No such file or directory: stm32f4xx.h"
**Solution:** You need to download and add CMSIS headers to `Drivers/CMSIS/`

### Issue: "undefined reference to `_sbrk`"
**Solution:** Already handled in the Makefile with `-lnosys` flag

### Issue: Flash size mismatch
**Solution:** Check your MCU's actual flash size and update the `-flash` argument

### Issue: "make: arm-none-eabi-gcc: No such file or directory"
**Solution:** Install ARM GCC toolchain:
```bash
# Ubuntu/Debian
sudo apt-get install gcc-arm-none-eabi

# macOS
brew install --cask gcc-arm-embedded

# Windows
# Download from ARM's website or use MSYS2
```

## Additional Resources

- [ARM Cortex-M Programming Guide](https://developer.arm.com/documentation)
- [STM32 Reference Manuals](https://www.st.com/en/microcontrollers-microprocessors/stm32-32-bit-arm-cortex-mcus.html)
- [Register-level Programming Tutorial](https://www.embedded.com/)

## Why Bare Metal?

**Advantages:**
- Complete control over hardware
- Smaller code size
- Faster execution
- Better understanding of MCU internals
- No library dependencies
- Perfect for learning

**When to use:**
- Learning embedded systems
- Resource-constrained projects
- Real-time critical applications
- When you need maximum control
- Custom bootloader development

## Next Steps

After generating your project:
1. ✓ Understand the startup sequence
2. ✓ Study the linker script
3. ✓ Learn register-level GPIO control
4. ✓ Add UART for debugging
5. ✓ Implement timers and interrupts
6. ✓ Explore DMA for efficient data transfer
7. ✓ Build your own peripheral drivers

Happy bare metal coding! 🚀
