#!/usr/bin/env python3
"""
STM32 Bare Metal Project Generator
Generates a minimal bare metal project structure for STM32 microcontrollers
"""

import os
import argparse
from pathlib import Path


class STM32BareMetalGenerator:
    def __init__(self, project_name, mcu_family, mcu_model, flash_size, ram_size):
        self.project_name = project_name
        self.mcu_family = mcu_family.upper()
        self.mcu_model = mcu_model.upper()
        self.flash_size = flash_size
        self.ram_size = ram_size
        self.project_dir = Path(project_name)
        
    def create_directories(self):
        """Create project directory structure"""
        dirs = [
            self.project_dir,
            self.project_dir / "Core" / "Src",
            self.project_dir / "Core" / "Inc",
            self.project_dir / "Startup",
            self.project_dir / "Drivers" / "CMSIS" / "Include",
            self.project_dir / "Drivers" / "CMSIS" / "Device" / self.mcu_family / "Include",
        ]
        
        for dir_path in dirs:
            dir_path.mkdir(parents=True, exist_ok=True)
        print(f"✓ Created directory structure for {self.project_name}")
    
    def generate_linker_script(self):
        """Generate linker script for the MCU"""
        linker_script = f"""/*
******************************************************************************
* File Name          : {self.mcu_model}_FLASH.ld
* Description        : Linker script for {self.mcu_model} Device
******************************************************************************
*/

/* Entry Point */
ENTRY(Reset_Handler)

/* Highest address of the user mode stack */
_estack = ORIGIN(RAM) + LENGTH(RAM);    /* end of RAM */

/* Generate a link error if heap and stack don't fit into RAM */
_Min_Heap_Size = 0x200;      /* required amount of heap  */
_Min_Stack_Size = 0x400;     /* required amount of stack */

/* Specify the memory areas */
MEMORY
{{
  RAM (xrw)      : ORIGIN = 0x20000000, LENGTH = {self.ram_size}K
  FLASH (rx)     : ORIGIN = 0x08000000, LENGTH = {self.flash_size}K
}}

/* Define output sections */
SECTIONS
{{
  /* The startup code goes first into FLASH */
  .isr_vector :
  {{
    . = ALIGN(4);
    KEEP(*(.isr_vector)) /* Startup code */
    . = ALIGN(4);
  }} >FLASH

  /* The program code and other data goes into FLASH */
  .text :
  {{
    . = ALIGN(4);
    *(.text)           /* .text sections (code) */
    *(.text*)          /* .text* sections (code) */
    *(.glue_7)         /* glue arm to thumb code */
    *(.glue_7t)        /* glue thumb to arm code */
    *(.eh_frame)

    KEEP (*(.init))
    KEEP (*(.fini))

    . = ALIGN(4);
    _etext = .;        /* define a global symbols at end of code */
  }} >FLASH

  /* Constant data goes into FLASH */
  .rodata :
  {{
    . = ALIGN(4);
    *(.rodata)         /* .rodata sections (constants, strings, etc.) */
    *(.rodata*)        /* .rodata* sections (constants, strings, etc.) */
    . = ALIGN(4);
  }} >FLASH

  .ARM.extab   : {{ *(.ARM.extab* .gnu.linkonce.armextab.*) }} >FLASH
  .ARM : {{
    __exidx_start = .;
    *(.ARM.exidx*)
    __exidx_end = .;
  }} >FLASH

  .preinit_array     :
  {{
    PROVIDE_HIDDEN (__preinit_array_start = .);
    KEEP (*(.preinit_array*))
    PROVIDE_HIDDEN (__preinit_array_end = .);
  }} >FLASH
  
  .init_array :
  {{
    PROVIDE_HIDDEN (__init_array_start = .);
    KEEP (*(SORT(.init_array.*)))
    KEEP (*(.init_array*))
    PROVIDE_HIDDEN (__init_array_end = .);
  }} >FLASH
  
  .fini_array :
  {{
    PROVIDE_HIDDEN (__fini_array_start = .);
    KEEP (*(SORT(.fini_array.*)))
    KEEP (*(.fini_array*))
    PROVIDE_HIDDEN (__fini_array_end = .);
  }} >FLASH

  /* used by the startup to initialize data */
  _sidata = LOADADDR(.data);

  /* Initialized data sections goes into RAM, load LMA copy after code */
  .data : 
  {{
    . = ALIGN(4);
    _sdata = .;        /* create a global symbol at data start */
    *(.data)           /* .data sections */
    *(.data*)          /* .data* sections */

    . = ALIGN(4);
    _edata = .;        /* define a global symbol at data end */
  }} >RAM AT> FLASH

  /* Uninitialized data section */
  . = ALIGN(4);
  .bss :
  {{
    /* This is used by the startup in order to initialize the .bss section */
    _sbss = .;         /* define a global symbol at bss start */
    __bss_start__ = _sbss;
    *(.bss)
    *(.bss*)
    *(COMMON)

    . = ALIGN(4);
    _ebss = .;         /* define a global symbol at bss end */
    __bss_end__ = _ebss;
  }} >RAM

  /* User_heap_stack section, used to check that there is enough RAM left */
  ._user_heap_stack :
  {{
    . = ALIGN(8);
    PROVIDE ( end = . );
    PROVIDE ( _end = . );
    . = . + _Min_Heap_Size;
    . = . + _Min_Stack_Size;
    . = ALIGN(8);
  }} >RAM

  /* Remove information from the standard libraries */
  /DISCARD/ :
  {{
    libc.a ( * )
    libm.a ( * )
    libgcc.a ( * )
  }}

  .ARM.attributes 0 : {{ *(.ARM.attributes) }}
}}
"""
        linker_path = self.project_dir / f"{self.mcu_model}_FLASH.ld"
        with open(linker_path, 'w') as f:
            f.write(linker_script)
        print(f"✓ Generated linker script: {linker_path}")
    
    def generate_startup_file(self):
        """Generate startup assembly file"""
        startup_code = f"""/**
  ******************************************************************************
  * @file      startup_{self.mcu_model.lower()}.s
  * @author    Auto-generated
  * @brief     {self.mcu_model} startup file for bare metal
  ******************************************************************************
  */

.syntax unified
.cpu cortex-m4
.fpu softvfp
.thumb

.global g_pfnVectors
.global Default_Handler

/* start address for the initialization values of the .data section */
.word _sidata
/* start address for the .data section */
.word _sdata
/* end address for the .data section */
.word _edata
/* start address for the .bss section */
.word _sbss
/* end address for the .bss section */
.word _ebss

/**
 * @brief  This is the code that gets called when the processor first
 *         starts execution following a reset event. 
 */
.section .text.Reset_Handler
.weak Reset_Handler
.type Reset_Handler, %function
Reset_Handler:
  ldr   sp, =_estack    /* Set stack pointer */

/* Copy the data segment initializers from flash to SRAM */
  ldr r0, =_sdata
  ldr r1, =_edata
  ldr r2, =_sidata
  movs r3, #0
  b LoopCopyDataInit

CopyDataInit:
  ldr r4, [r2, r3]
  str r4, [r0, r3]
  adds r3, r3, #4

LoopCopyDataInit:
  adds r4, r0, r3
  cmp r4, r1
  bcc CopyDataInit
  
/* Zero fill the bss segment. */
  ldr r2, =_sbss
  ldr r4, =_ebss
  movs r3, #0
  b LoopFillZerobss

FillZerobss:
  str  r3, [r2]
  adds r2, r2, #4

LoopFillZerobss:
  cmp r2, r4
  bcc FillZerobss

/* Call the clock system initialization function.*/
  bl  SystemInit
/* Call static constructors */
  bl __libc_init_array
/* Call the application's entry point.*/
  bl main
  bx lr
.size Reset_Handler, .-Reset_Handler

/**
 * @brief  This is the code that gets called when the processor receives an
 *         unexpected interrupt.
 */
.section .text.Default_Handler,"ax",%progbits
Default_Handler:
Infinite_Loop:
  b Infinite_Loop
  .size Default_Handler, .-Default_Handler

/******************************************************************************
*
* The minimal vector table for a Cortex M4.
*
*******************************************************************************/
.section .isr_vector,"a",%progbits
.type g_pfnVectors, %object
.size g_pfnVectors, .-g_pfnVectors

g_pfnVectors:
  .word _estack
  .word Reset_Handler
  .word NMI_Handler
  .word HardFault_Handler
  .word MemManage_Handler
  .word BusFault_Handler
  .word UsageFault_Handler
  .word 0
  .word 0
  .word 0
  .word 0
  .word SVC_Handler
  .word DebugMon_Handler
  .word 0
  .word PendSV_Handler
  .word SysTick_Handler
  
  /* External Interrupts */
  .word WWDG_IRQHandler                   /* Window WatchDog              */
  .word PVD_IRQHandler                    /* PVD through EXTI Line detection */
  .word TAMP_STAMP_IRQHandler            /* Tamper and TimeStamps through the EXTI line */
  .word RTC_WKUP_IRQHandler              /* RTC Wakeup through the EXTI line */
  /* Add more interrupt vectors as needed for your specific MCU */

/*******************************************************************************
* Provide weak aliases for each Exception handler to the Default_Handler.
*******************************************************************************/
  .weak NMI_Handler
  .thumb_set NMI_Handler,Default_Handler

  .weak HardFault_Handler
  .thumb_set HardFault_Handler,Default_Handler

  .weak MemManage_Handler
  .thumb_set MemManage_Handler,Default_Handler

  .weak BusFault_Handler
  .thumb_set BusFault_Handler,Default_Handler

  .weak UsageFault_Handler
  .thumb_set UsageFault_Handler,Default_Handler

  .weak SVC_Handler
  .thumb_set SVC_Handler,Default_Handler

  .weak DebugMon_Handler
  .thumb_set DebugMon_Handler,Default_Handler

  .weak PendSV_Handler
  .thumb_set PendSV_Handler,Default_Handler

  .weak SysTick_Handler
  .thumb_set SysTick_Handler,Default_Handler

  .weak WWDG_IRQHandler
  .thumb_set WWDG_IRQHandler,Default_Handler

  .weak PVD_IRQHandler
  .thumb_set PVD_IRQHandler,Default_Handler

  .weak TAMP_STAMP_IRQHandler
  .thumb_set TAMP_STAMP_IRQHandler,Default_Handler

  .weak RTC_WKUP_IRQHandler
  .thumb_set RTC_WKUP_IRQHandler,Default_Handler
"""
        startup_path = self.project_dir / "Startup" / f"startup_{self.mcu_model.lower()}.s"
        with open(startup_path, 'w') as f:
            f.write(startup_code)
        print(f"✓ Generated startup file: {startup_path}")
    
    def generate_system_init(self):
        """Generate system initialization file"""
        system_c = f"""/**
  ******************************************************************************
  * @file    system_{self.mcu_family.lower()}.c
  * @author  Auto-generated
  * @brief   CMSIS Cortex-M4 Device Peripheral Access Layer System Source File
  ******************************************************************************
  */

#include "{self.mcu_family.lower()}.h"

/* System Clock frequency (SYSCLK) */
uint32_t SystemCoreClock = 16000000;  /* Default HSI clock */

/**
  * @brief  Setup the microcontroller system
  *         Initialize the FPU setting and vector table location
  * @param  None
  * @retval None
  */
void SystemInit(void)
{{
    /* FPU settings */
    #if (__FPU_PRESENT == 1) && (__FPU_USED == 1)
        SCB->CPACR |= ((3UL << 10*2)|(3UL << 11*2));  /* Enable CP10 and CP11 Full Access */
    #endif
    
    /* Configure Vector Table location - default to Flash */
    #ifdef VECT_TAB_SRAM
        SCB->VTOR = SRAM_BASE | VECT_TAB_OFFSET;
    #else
        SCB->VTOR = FLASH_BASE | VECT_TAB_OFFSET;
    #endif
}}

/**
  * @brief  Update SystemCoreClock variable according to Clock Register Values.
  * @note   Call this function when you change the clock configuration
  * @param  None
  * @retval None
  */
void SystemCoreClockUpdate(void)
{{
    /* TODO: Implement clock calculation based on RCC registers */
    SystemCoreClock = 16000000;  /* HSI default */
}}
"""
        system_path = self.project_dir / "Core" / "Src" / f"system_{self.mcu_family.lower()}.c"
        with open(system_path, 'w') as f:
            f.write(system_c)
        print(f"✓ Generated system init file: {system_path}")
    
    def generate_main_file(self):
        """Generate main application file"""
        main_c = f"""/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - Bare Metal
  ******************************************************************************
  * @attention
  *
  * Bare metal application for {self.mcu_model}
  * No HAL/LL libraries - direct register access only
  *
  ******************************************************************************
  */

#include "{self.mcu_family.lower()}.h"

/* Private function prototypes */
void GPIO_Init(void);
void delay_ms(uint32_t ms);

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{{
    /* Initialize GPIO */
    GPIO_Init();
    
    /* Infinite loop */
    while (1)
    {{
        /* Toggle LED (example: PD12 on STM32F4-Discovery) */
        GPIOD->ODR ^= GPIO_ODR_OD12;
        delay_ms(500);
    }}
}}

/**
  * @brief  Initialize GPIO for LED
  * @retval None
  */
void GPIO_Init(void)
{{
    /* Enable GPIOD clock */
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
    
    /* Configure PD12 as output */
    GPIOD->MODER &= ~GPIO_MODER_MODER12;  /* Clear mode bits */
    GPIOD->MODER |= GPIO_MODER_MODER12_0; /* Set as output (01) */
    
    /* Set output type to push-pull */
    GPIOD->OTYPER &= ~GPIO_OTYPER_OT12;
    
    /* Set speed to high */
    GPIOD->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR12;
    
    /* No pull-up, pull-down */
    GPIOD->PUPDR &= ~GPIO_PUPDR_PUPD12;
}}

/**
  * @brief  Simple delay function (blocking)
  * @param  ms: delay in milliseconds (approximate)
  * @retval None
  */
void delay_ms(uint32_t ms)
{{
    /* Assumes 16MHz clock - adjust multiplier for your clock speed */
    for(uint32_t i = 0; i < ms; i++)
    {{
        for(volatile uint32_t j = 0; j < 4000; j++)
        {{
            __NOP();
        }}
    }}
}}

/**
  * @brief  This function handles Hard Fault exception.
  * @retval None
  */
void HardFault_Handler(void)
{{
    while (1)
    {{
        /* Trap in infinite loop on hard fault */
    }}
}}
"""
        main_path = self.project_dir / "Core" / "Src" / "main.c"
        with open(main_path, 'w') as f:
            f.write(main_c)
        print(f"✓ Generated main.c: {main_path}")
    
    def generate_makefile(self):
        """Generate Makefile for bare metal compilation"""
        makefile = f"""######################################
# target
######################################
TARGET = {self.project_name}

######################################
# building variables
######################################
# debug build?
DEBUG = 1
# optimization
OPT = -Og

#######################################
# paths
#######################################
# Build path
BUILD_DIR = build

######################################
# source
######################################
# C sources
C_SOURCES = \\
Core/Src/main.c \\
Core/Src/system_{self.mcu_family.lower()}.c

# ASM sources
ASM_SOURCES = \\
Startup/startup_{self.mcu_model.lower()}.s

#######################################
# binaries
#######################################
PREFIX = arm-none-eabi-
CC = $(PREFIX)gcc
AS = $(PREFIX)gcc -x assembler-with-cpp
CP = $(PREFIX)objcopy
SZ = $(PREFIX)size

HEX = $(CP) -O ihex
BIN = $(CP) -O binary -S

#######################################
# CFLAGS
#######################################
# cpu
CPU = -mcpu=cortex-m4

# fpu
FPU = -mfpu=fpv4-sp-d16

# float-abi
FLOAT-ABI = -mfloat-abi=hard

# mcu
MCU = $(CPU) -mthumb $(FPU) $(FLOAT-ABI)

# macros for gcc
AS_DEFS = 

# C defines
C_DEFS = \\
-D{self.mcu_model} \\
-DUSE_STDPERIPH_DRIVER

# AS includes
AS_INCLUDES = 

# C includes
C_INCLUDES = \\
-ICore/Inc \\
-IDrivers/CMSIS/Include \\
-IDrivers/CMSIS/Device/{self.mcu_family}/Include

# compile gcc flags
ASFLAGS = $(MCU) $(AS_DEFS) $(AS_INCLUDES) $(OPT) -Wall -fdata-sections -ffunction-sections

CFLAGS = $(MCU) $(C_DEFS) $(C_INCLUDES) $(OPT) -Wall -fdata-sections -ffunction-sections

ifeq ($(DEBUG), 1)
CFLAGS += -g -gdwarf-2
endif

# Generate dependency information
CFLAGS += -MMD -MP -MF"$(@:%.o=%.d)"

#######################################
# LDFLAGS
#######################################
# link script
LDSCRIPT = {self.mcu_model}_FLASH.ld

# libraries
LIBS = -lc -lm -lnosys 
LIBDIR = 
LDFLAGS = $(MCU) -specs=nano.specs -T$(LDSCRIPT) $(LIBDIR) $(LIBS) -Wl,-Map=$(BUILD_DIR)/$(TARGET).map,--cref -Wl,--gc-sections

# default action: build all
all: $(BUILD_DIR)/$(TARGET).elf $(BUILD_DIR)/$(TARGET).hex $(BUILD_DIR)/$(TARGET).bin

#######################################
# build the application
#######################################
# list of objects
OBJECTS = $(addprefix $(BUILD_DIR)/,$(notdir $(C_SOURCES:.c=.o)))
vpath %.c $(sort $(dir $(C_SOURCES)))
# list of ASM program objects
OBJECTS += $(addprefix $(BUILD_DIR)/,$(notdir $(ASM_SOURCES:.s=.o)))
vpath %.s $(sort $(dir $(ASM_SOURCES)))

$(BUILD_DIR)/%.o: %.c Makefile | $(BUILD_DIR) 
\t$(CC) -c $(CFLAGS) -Wa,-a,-ad,-alms=$(BUILD_DIR)/$(notdir $(<:.c=.lst)) $< -o $@

$(BUILD_DIR)/%.o: %.s Makefile | $(BUILD_DIR)
\t$(AS) -c $(CFLAGS) $< -o $@

$(BUILD_DIR)/$(TARGET).elf: $(OBJECTS) Makefile
\t$(CC) $(OBJECTS) $(LDFLAGS) -o $@
\t$(SZ) $@

$(BUILD_DIR)/%.hex: $(BUILD_DIR)/%.elf | $(BUILD_DIR)
\t$(HEX) $< $@
\t
$(BUILD_DIR)/%.bin: $(BUILD_DIR)/%.elf | $(BUILD_DIR)
\t$(BIN) $< $@\t
\t
$(BUILD_DIR):
\tmkdir $@\t\t

#######################################
# clean up
#######################################
clean:
\t-rm -fR $(BUILD_DIR)

#######################################
# dependencies
#######################################
-include $(wildcard $(BUILD_DIR)/*.d)
"""
        makefile_path = self.project_dir / "Makefile"
        with open(makefile_path, 'w') as f:
            f.write(makefile)
        print(f"✓ Generated Makefile: {makefile_path}")
    
    def generate_readme(self):
        """Generate README file"""
        readme = f"""# {self.project_name}

Bare Metal STM32 Project for {self.mcu_model}

## Hardware Specifications
- **MCU**: {self.mcu_model}
- **Flash**: {self.flash_size}KB
- **RAM**: {self.ram_size}KB
- **Family**: {self.mcu_family}

## Project Structure
```
{self.project_name}/
├── Core/
│   ├── Inc/          # Header files
│   └── Src/          # Source files
│       ├── main.c
│       └── system_{self.mcu_family.lower()}.c
├── Startup/
│   └── startup_{self.mcu_model.lower()}.s
├── Drivers/
│   └── CMSIS/        # CMSIS headers (you need to add these)
├── Makefile
└── {self.mcu_model}_FLASH.ld
```

## Building the Project

### Prerequisites
- ARM GCC Toolchain (`arm-none-eabi-gcc`)
- Make
- STM32CubeProgrammer or OpenOCD for flashing

### Compile
```bash
make
```

### Flash
Using ST-Link:
```bash
st-flash write build/{self.project_name}.bin 0x8000000
```

Or using OpenOCD:
```bash
openocd -f interface/stlink.cfg -f target/stm32f4x.cfg -c "program build/{self.project_name}.elf verify reset exit"
```

### Clean
```bash
make clean
```

## Important Notes

### CMSIS Headers Required
You need to download CMSIS headers for your specific STM32 family from ST's website:
1. Download STM32Cube firmware package for your MCU family
2. Extract CMSIS headers to `Drivers/CMSIS/`
3. Required files:
   - `Include/core_cm4.h`
   - `Include/cmsis_gcc.h`
   - `Device/{self.mcu_family}/Include/{self.mcu_family.lower()}xx.h`

### Customization
- Modify `main.c` for your application logic
- Update GPIO pins and peripherals as needed
- Adjust clock configuration in `system_{self.mcu_family.lower()}.c`
- Add interrupt handlers in startup file

### Debugging
Use GDB with OpenOCD or ST-Link GDB server for debugging:
```bash
arm-none-eabi-gdb build/{self.project_name}.elf
```

## Features
- ✓ No HAL/LL libraries - Direct register access
- ✓ Minimal startup code
- ✓ Custom linker script
- ✓ Makefile-based build system
- ✓ Ready for bare metal development

## Example Code
The generated `main.c` includes a simple LED blink example using direct register manipulation.

## License
This is auto-generated template code. Use as you see fit.
"""
        readme_path = self.project_dir / "README.md"
        with open(readme_path, 'w') as f:
            f.write(readme)
        print(f"✓ Generated README: {readme_path}")
    
    def generate_gitignore(self):
        """Generate .gitignore file"""
        gitignore = """# Build artifacts
build/
*.o
*.elf
*.hex
*.bin
*.map
*.d
*.lst

# IDE files
.vscode/
.settings/
.cproject
.project

# Debug files
*.launch
```"""
        gitignore_path = self.project_dir / ".gitignore"
        with open(gitignore_path, 'w') as f:
            f.write(gitignore)
        print(f"✓ Generated .gitignore: {gitignore_path}")
    
    def generate_project(self):
        """Generate complete bare metal project"""
        print(f"\n🚀 Generating STM32 Bare Metal Project: {self.project_name}")
        print(f"   MCU: {self.mcu_model} ({self.mcu_family} family)")
        print(f"   Flash: {self.flash_size}KB | RAM: {self.ram_size}KB\n")
        
        self.create_directories()
        self.generate_linker_script()
        self.generate_startup_file()
        self.generate_system_init()
        self.generate_main_file()
        self.generate_makefile()
        self.generate_readme()
        self.generate_gitignore()
        
        print(f"\n✅ Project generated successfully!\n")
        print("📋 Next steps:")
        print("   1. Download CMSIS headers from STM32Cube firmware package")
        print(f"   2. Place headers in {self.project_name}/Drivers/CMSIS/")
        print(f"   3. cd {self.project_name}")
        print("   4. make")
        print("   5. Flash to your board\n")


def main():
    parser = argparse.ArgumentParser(
        description='Generate STM32 bare metal project structure',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  # STM32F407VG (Discovery board)
  python3 stm32_baremetal_generator.py -n MyProject -f STM32F4 -m STM32F407VG -flash 1024 -ram 192
  
  # STM32F103C8 (Blue Pill)
  python3 stm32_baremetal_generator.py -n BluePill -f STM32F1 -m STM32F103C8 -flash 64 -ram 20
  
  # STM32L476RG (Nucleo)
  python3 stm32_baremetal_generator.py -n NucleoL476 -f STM32L4 -m STM32L476RG -flash 1024 -ram 128
        """
    )
    
    parser.add_argument('-n', '--name', required=True, 
                       help='Project name')
    parser.add_argument('-f', '--family', required=True,
                       help='MCU family (e.g., STM32F4, STM32F1, STM32L4)')
    parser.add_argument('-m', '--model', required=True,
                       help='MCU model (e.g., STM32F407VG, STM32F103C8)')
    parser.add_argument('-flash', '--flash-size', type=int, required=True,
                       help='Flash size in KB')
    parser.add_argument('-ram', '--ram-size', type=int, required=True,
                       help='RAM size in KB')
    
    args = parser.parse_args()
    
    generator = STM32BareMetalGenerator(
        project_name=args.name,
        mcu_family=args.family,
        mcu_model=args.model,
        flash_size=args.flash_size,
        ram_size=args.ram_size
    )
    
    generator.generate_project()


if __name__ == "__main__":
    main()
