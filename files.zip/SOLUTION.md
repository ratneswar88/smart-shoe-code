# SOLUTION: Complete Fix for NaN/Infinity toInt Error

## Root Cause Found!

The error is coming from **graphs_page.dart** when the BLE sensor returns invalid data.

**Problem chain:**
1. `ble.dart` line 300: `_f32()` returns `double.nan` when BLE packet is incomplete
2. `graphs_page.dart` line 20: `_push()` doesn't validate the value before adding to chart
3. `fl_chart` tries to render the chart with NaN values
4. When calculating pixel positions, fl_chart calls `.toInt()` on NaN
5. **CRASH**: "Unsupported operation: Infinity or NaN toInt"

## Fix 1: Update graphs_page.dart (REQUIRED)

Replace the `_push` function (line 20) with validation:

```dart
void _push(List<FlSpot> s, double t, double v, {int keep = 300}) {
  // CRITICAL: Validate before adding to chart
  if (v.isNaN || v.isInfinite || t.isNaN || t.isInfinite) return;
  if (v.abs() > 1e10 || t.abs() > 1e10) return; // Filter extreme values
  
  s.add(FlSpot(t, v));
  if (s.length > keep) s.removeAt(0);
}
```

Also update `_lineCard` (line 80) to filter invalid points before rendering:

```dart
Widget _lineCard(ColorScheme cs, String title, List<FlSpot> pts,
    {double? minY, double? maxY}) {
  // Filter out any invalid points before rendering
  final validPts = pts.where((p) => 
    !p.x.isNaN && !p.x.isInfinite && 
    !p.y.isNaN && !p.y.isInfinite
  ).toList();
  
  return Card(
    color: cs.surfaceContainerHigh,
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          SizedBox(
            height: 220,
            child: validPts.isEmpty
                ? Center(child: Text('No data', style: TextStyle(color: Colors.grey[600])))
                : LineChart(
                    LineChartData(
                      minY: minY,
                      maxY: maxY,
                      gridData: const FlGridData(show: true),
                      titlesData: const FlTitlesData(
                        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: true)),
                        bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      borderData: FlBorderData(show: true),
                      lineBarsData: [
                        LineChartBarData(
                          spots: validPts,
                          isCurved: true,
                          barWidth: 2,
                          isStrokeCapRound: true,
                          dotData: const FlDotData(show: false),
                        ),
                      ],
                    ),
                  ),
          ),
        ],
      ),
    ),
  );
}
```

## Fix 2: Update ble.dart (OPTIONAL but recommended)

Change line 300 in `ble.dart` from returning `double.nan` to returning 0.0:

```dart
double _f32(List<int> b) {
  if (b.length < 4) return 0.0;  // Changed from double.nan
  final bd = ByteData.sublistView(Uint8List.fromList(b));
  final val = bd.getFloat32(0, Endian.little);
  // Filter invalid values at the source
  if (val.isNaN || val.isInfinite) return 0.0;
  return val;
}
```

## Summary

The **minimum required fix** is updating `graphs_page.dart` with the validation in the `_push` function. This will:
1. Prevent NaN/Infinity values from being added to charts
2. Filter any existing invalid values before rendering
3. Show "No data" if all points are invalid

Apply the graphs_page fix and the error will stop immediately!

## Files to Update

1. **graphs_page.dart** - Replace with the fixed version I provided
2. **ble.dart** (optional) - Change `double.nan` to `0.0` on line 300

That's it! The error was NOT from the maps - it was from the charts all along.
