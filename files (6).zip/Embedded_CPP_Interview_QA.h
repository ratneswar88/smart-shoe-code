/*******************************************************************************
 * EMBEDDED C++ INTERVIEW GUIDE
 * ============================================================================
 * Quick reference for C++ concepts in embedded systems interviews
 ******************************************************************************/

// ============================================================================
// SECTION 1: KEY CONCEPTS EXPLAINED
// ============================================================================

/**
 * 1. CLASS vs STRUCT
 * ==================
 * 
 * In C++, they're almost identical!
 * Only difference: Default access level
 * 
 * struct: Members are PUBLIC by default
 * class:  Members are PRIVATE by default
 */

struct MyStruct {
    int x;  // PUBLIC by default
};

class MyClass {
    int x;  // PRIVATE by default
};

// Use class when you want encapsulation, struct for plain data

/**
 * 2. RAII (Most Important C++ Concept for Embedded!)
 * ===================================================
 * 
 * Resource Acquisition Is Initialization
 * 
 * Constructor = Acquire resource
 * Destructor = Release resource AUTOMATICALLY
 * 
 * Why it matters:
 * - Prevents resource leaks
 * - Works even with early returns
 * - Automatic cleanup when object goes out of scope
 */

class MutexLock {
public:
    MutexLock(SemaphoreHandle_t m) : mutex(m) {
        xSemaphoreTake(mutex, portMAX_DELAY);  // ACQUIRE
    }
    ~MutexLock() {
        xSemaphoreGive(mutex);  // RELEASE automatically
    }
private:
    SemaphoreHandle_t mutex;
};

void safeFunction() {
    MutexLock lock(myMutex);  // Locks here
    
    if (error) return;  // Mutex STILL released!
    
    // Do work...
    
}  // Mutex released here automatically

/**
 * 3. CONST CORRECTNESS
 * ====================
 * 
 * const function = "I promise not to modify the object"
 * const parameter = "I promise not to modify this parameter"
 * 
 * Benefits:
 * - Compiler enforces promise
 * - Self-documenting
 * - Enables optimizations
 */

class Sensor {
public:
    int read() const {  // const = does not modify object
        return ADC->DR;
    }
    
    void calibrate() {  // non-const = can modify object
        offset = 0;
    }
    
private:
    int offset;
};

// Pass large objects by const reference (fast + safe)
void process(const SensorData& data) {
    // Can read data, cannot modify it
}

/**
 * 4. TEMPLATES
 * ============
 * 
 * Compile-time generic programming
 * Compiler generates code for each type
 * ZERO runtime overhead
 */

template<typename T, size_t N>
class Array {
    T data[N];  // Size known at compile time!
};

Array<int, 10> intArray;      // Compiler generates Array_int_10
Array<float, 20> floatArray;  // Compiler generates Array_float_20

/**
 * 5. VIRTUAL FUNCTIONS
 * ====================
 * 
 * Enable polymorphism (different behavior based on actual type)
 * 
 * Cost: vtable pointer (4-8 bytes per object) + indirect call
 * 
 * Use when: Need runtime polymorphism
 * Avoid when: Tight loops, ISRs, or when type known at compile time
 */

class Base {
public:
    virtual void func() { }  // Can be overridden
};

class Derived : public Base {
public:
    void func() override { }  // Overrides Base::func
};

// ============================================================================
// SECTION 2: INTERVIEW QUESTIONS & ANSWERS
// ============================================================================

/**
 * Q1: What's the difference between C and C++?
 * ============================================
 * 
 * A: C++ is C with additional features:
 * - Classes and objects (encapsulation, inheritance, polymorphism)
 * - Templates (generic programming)
 * - RAII (automatic resource management)
 * - Function and operator overloading
 * - References (safer than pointers)
 * - Namespaces (avoid naming conflicts)
 * - Better type safety
 * 
 * In embedded, we use a subset: avoid exceptions, RTTI, dynamic allocation
 */

/**
 * Q2: Why avoid exceptions in embedded C++?
 * =========================================
 * 
 * A: Three main reasons:
 * 1. Code size: Exception handling adds 10-30% to binary size
 * 2. Timing: Stack unwinding is non-deterministic
 * 3. Support: Not all embedded toolchains support exceptions well
 * 
 * Solution: Use error codes, return values, or assertions
 * Compile with: -fno-exceptions
 */

/**
 * Q3: What is RAII?
 * =================
 * 
 * A: Resource Acquisition Is Initialization
 * 
 * Constructor acquires resource (memory, mutex, hardware)
 * Destructor releases resource AUTOMATICALLY
 * 
 * Benefits in embedded:
 * - Prevents mutex leaks (automatic unlock)
 * - Prevents hardware resource leaks
 * - Works with early returns
 * - Makes code exception-safe (even without exceptions!)
 * 
 * Example: MutexGuard, SpiTransaction, GpioConfig
 */

/**
 * Q4: Can you use C++ in an ISR?
 * ===============================
 * 
 * A: Yes, but with care:
 * 
 * ✓ Can use: Non-virtual member functions (no overhead)
 * ✓ Can use: Static member functions (like C functions)
 * ✓ Can use: Simple objects
 * 
 * ✗ Avoid: Virtual functions (vtable lookup)
 * ✗ Avoid: Constructors/destructors in ISR
 * ✗ Avoid: Dynamic allocation
 * ✗ Avoid: Heavy computations
 */

/**
 * Q5: What are templates?
 * =======================
 * 
 * A: Templates are compile-time generic programming.
 * 
 * Write code once, works with any type.
 * Compiler generates specialized code for each type used.
 * 
 * Benefits:
 * - Type safe
 * - Code reuse
 * - ZERO runtime overhead (all resolved at compile time)
 * 
 * Trade-offs:
 * - Larger binary (code for each type)
 * - Longer compile time
 * 
 * Example: RingBuffer<T, SIZE>, MovingAverage<T, N>
 */

/**
 * Q6: Why avoid new/delete in embedded?
 * ======================================
 * 
 * A: Dynamic memory allocation issues:
 * 1. Non-deterministic timing (allocation time varies)
 * 2. Fragmentation (memory becomes fragmented over time)
 * 3. Requires exception support (for bad_alloc)
 * 4. Can fail (out of memory)
 * 
 * Solution: Use stack or static allocation
 * If dynamic needed: Fixed-size memory pools
 */

/**
 * Q7: What's the difference between struct and class?
 * ===================================================
 * 
 * A: Only default access:
 * - struct: public by default
 * - class: private by default
 * 
 * Otherwise identical.
 * 
 * Convention:
 * - struct: Plain data (no methods, public members)
 * - class: Encapsulated objects (methods, private data)
 */

/**
 * Q8: What is const correctness?
 * ===============================
 * 
 * A: Using const to indicate what cannot be modified.
 * 
 * const member function: Does not modify object
 * const parameter: Function does not modify parameter
 * const object: Cannot call non-const functions
 * 
 * Benefits:
 * - Compiler enforces const
 * - Self-documenting
 * - Prevents bugs
 * - Enables optimizations
 */

/**
 * Q9: What is override keyword?
 * ==============================
 * 
 * A: Explicitly marks function as overriding base class virtual.
 * 
 * Compiler error if:
 * - Base function doesn't exist
 * - Signature doesn't match
 * - Base function not virtual
 * 
 * Prevents bugs from typos or signature changes.
 */

/**
 * Q10: What is polymorphism?
 * ==========================
 * 
 * A: Ability to use base class interface with derived class objects.
 * 
 * Base class pointer/reference can point to derived class object.
 * Virtual functions call derived class implementation.
 * 
 * Example: ISensor base class, TemperatureSensor and PressureSensor
 *          derived classes. Code works with ISensor*, actual behavior
 *          depends on real object type.
 */

// ============================================================================
// SECTION 3: QUICK REFERENCE - COMMON PATTERNS
// ============================================================================

// Pattern 1: Hardware Abstraction Class
class Uart {
public:
    Uart(USART_TypeDef* uart, uint32_t baud);
    ~Uart();  // Cleanup
    
    void transmit(const uint8_t* data, size_t len);
    bool receive(uint8_t* data, size_t len, uint32_t timeout);
    
private:
    USART_TypeDef* uart_;
    // Implementation details hidden
};

// Pattern 2: RAII Wrapper
class CriticalSection {
public:
    CriticalSection() { __disable_irq(); }
    ~CriticalSection() { __enable_irq(); }
};

void criticalCode() {
    CriticalSection cs;  // Interrupts disabled
    // Critical code
}  // Interrupts re-enabled automatically

// Pattern 3: Template Container
template<typename T, size_t SIZE>
class FixedVector {
public:
    void push_back(const T& item);
    T& operator[](size_t index);
    size_t size() const;
private:
    T data_[SIZE];
    size_t size_;
};

// Pattern 4: Interface (Abstract Base Class)
class IPeripheral {
public:
    virtual ~IPeripheral() = default;
    virtual bool init() = 0;
    virtual bool read(uint8_t* data, size_t len) = 0;
    virtual bool write(const uint8_t* data, size_t len) = 0;
};

// Pattern 5: Deleted Copy (Non-Copyable)
class HardwareResource {
public:
    HardwareResource() { }
    
    // Prevent copying
    HardwareResource(const HardwareResource&) = delete;
    HardwareResource& operator=(const HardwareResource&) = delete;
};

// ============================================================================
// SECTION 4: COMPILER FLAGS
// ============================================================================

/*
 * Required flags for embedded C++:
 * 
 * -std=c++17          // Use C++17 standard
 * -fno-exceptions     // Disable exceptions
 * -fno-rtti           // Disable run-time type information
 * -fno-use-cxa-atexit // Don't use __cxa_atexit for destructors
 * 
 * Recommended:
 * -O2 or -Os          // Optimize for speed or size
 * -Wall -Wextra       // Enable warnings
 * -Wno-psabi          // Suppress ABI warnings
 */

// ============================================================================
// SECTION 5: WHAT TO USE / AVOID
// ============================================================================

/**
 * ✓ DO USE:
 * ---------
 * - Classes for hardware abstraction
 * - RAII for resource management
 * - Const correctness
 * - Templates for generic code
 * - Enum class for type safety
 * - Stack/static allocation
 * - References instead of pointers
 * - auto for type deduction
 * - constexpr for compile-time computation
 * 
 * ✗ AVOID:
 * --------
 * - Exceptions (compile with -fno-exceptions)
 * - RTTI (compile with -fno-rtti)
 * - new/delete (use stack/static)
 * - Virtual functions in ISRs or tight loops
 * - std::vector, std::map (use fixed-size alternatives)
 * - std::string (use char arrays)
 * - Iostreams (<iostream>) - too heavy
 * - Multiple inheritance (complex)
 */

// ============================================================================
// SECTION 6: CODE SIZE COMPARISON
// ============================================================================

/**
 * C++ overhead (when used correctly):
 * 
 * Non-virtual member function: ZERO overhead (inlined or same as C function)
 * Virtual function: 4-8 bytes per object + indirect call (~2-4 cycles)
 * Template: Code generated per type (larger binary, but optimized per type)
 * Constructor/Destructor: Small overhead (few instructions)
 * 
 * With proper compilation flags (-Os -fno-exceptions -fno-rtti):
 * C++ code can be as efficient as C code!
 */

// ============================================================================
// SECTION 7: MIGRATION FROM C TO C++
// ============================================================================

/**
 * Step 1: Start simple
 * --------------------
 * - Use .cpp extension
 * - Add extern "C" for C functions
 * - Start using classes for new code
 */

extern "C" {
    void c_function();  // C function callable from C++
}

/**
 * Step 2: Encapsulate hardware
 * ----------------------------
 * - Wrap peripherals in classes
 * - Use RAII for automatic cleanup
 */

class Spi {
    // Encapsulate SPI peripheral
};

/**
 * Step 3: Add templates
 * --------------------
 * - Replace void* with templates
 * - Use type-safe containers
 */

template<typename T, size_t N>
class Queue {
    // Type-safe queue
};

/**
 * Step 4: Use modern features
 * --------------------------
 * - auto for type deduction
 * - enum class for enumerations
 * - constexpr for constants
 */

// ============================================================================
// SECTION 8: INTERVIEW SUCCESS TIPS
// ============================================================================

/**
 * When discussing C++ in interview:
 * 
 * 1. Emphasize zero-cost abstractions
 *    "C++ features I use have no runtime overhead when compiled correctly"
 * 
 * 2. Show awareness of pitfalls
 *    "I avoid exceptions, dynamic memory, and RTTI in embedded"
 * 
 * 3. Highlight RAII
 *    "RAII is the most valuable C++ feature for preventing resource leaks"
 * 
 * 4. Demonstrate template understanding
 *    "Templates provide type safety and code reuse without runtime cost"
 * 
 * 5. Know your compiler flags
 *    "-fno-exceptions -fno-rtti -std=c++17"
 * 
 * 6. Be honest about experience level
 *    "My production work is primarily C, but I understand C++ fundamentals
 *     and how to apply them safely in embedded systems"
 */

// ============================================================================
// REMEMBER:
// ============================================================================

/**
 * C++ is NOT just "C with classes"
 * 
 * Key value adds:
 * - Better abstractions (classes, templates)
 * - Automatic cleanup (RAII)
 * - Type safety (strong typing, templates)
 * - Code reuse (inheritance, templates)
 * 
 * All available WITHOUT sacrificing performance!
 */

/*******************************************************************************
 * END OF CHEAT SHEET
 ******************************************************************************/
