/**
 * Embedded C++ Complete Examples
 * ===============================
 * 
 * Practical C++ code for embedded systems demonstrating:
 * - Classes for hardware abstraction
 * - RAII for resource management
 * - Templates for generic programming
 * - Modern C++ features
 * 
 * Compiler flags: -std=c++17 -fno-exceptions -fno-rtti
 */

#include <cstdint>
#include <cstring>

// ============================================================================
// EXAMPLE 1: Basic Class - GPIO Abstraction
// ============================================================================

/**
 * C vs C++ Comparison
 * ===================
 * 
 * C Style (what you know):
 * - Functions operate on structs
 * - Manual initialization
 * - No encapsulation
 * 
 * C++ Style (what we'll learn):
 * - Methods are part of the class
 * - Automatic initialization (constructor)
 * - Private data (encapsulation)
 */

// C-style (for comparison)
typedef struct {
    GPIO_TypeDef* port;
    uint16_t pin;
} GPIO_Pin_t;

void gpio_pin_init(GPIO_Pin_t* pin, GPIO_TypeDef* port, uint16_t pinNum) {
    pin->port = port;
    pin->pin = pinNum;
}

void gpio_pin_set(GPIO_Pin_t* pin) {
    pin->port->BSRR = (1 << pin->pin);
}

// C++ style - much cleaner!
class GpioPin {
public:
    // Constructor - automatically called when object created
    GpioPin(GPIO_TypeDef* port, uint16_t pin)
        : port_(port)  // Member initialization list
        , pin_(pin)
    {
        enableClock();  // Automatic initialization
    }
    
    // Methods - functions that operate on this object
    void set() const {
        port_->BSRR = (1 << pin_);
    }
    
    void clear() const {
        port_->BSRR = (1 << (pin_ + 16));
    }
    
    void toggle() const {
        port_->ODR ^= (1 << pin_);
    }
    
    bool read() const {
        return (port_->IDR & (1 << pin_)) != 0;
    }
    
private:
    // Private data - can only be accessed by class methods
    GPIO_TypeDef* port_;
    uint16_t pin_;
    
    void enableClock() {
        // Implementation details hidden
    }
};

// Usage comparison:
void demo_gpio() {
    // C style:
    GPIO_Pin_t led_c;
    gpio_pin_init(&led_c, GPIOD, 12);
    gpio_pin_set(&led_c);
    
    // C++ style:
    GpioPin led(GPIOD, 12);  // Constructor called automatically
    led.set();                // Clean syntax
}

// ============================================================================
// EXAMPLE 2: RAII (Resource Acquisition Is Initialization)
// ============================================================================

/**
 * RAII Pattern - THE Most Important C++ Feature for Embedded
 * ===========================================================
 * 
 * Problem in C:
 * - Must manually clean up resources
 * - Easy to forget on error paths
 * - Easy to forget with early returns
 * 
 * Solution in C++:
 * - Constructor acquires resource
 * - Destructor releases resource AUTOMATICALLY
 * - Even with early returns or exceptions!
 */

// Example: Automatic Mutex Lock/Unlock
class MutexGuard {
public:
    // Constructor acquires mutex
    explicit MutexGuard(SemaphoreHandle_t mutex)
        : mutex_(mutex)
    {
        xSemaphoreTake(mutex_, portMAX_DELAY);
    }
    
    // Destructor releases mutex AUTOMATICALLY
    ~MutexGuard() {
        xSemaphoreGive(mutex_);
    }
    
    // Delete copy constructor - prevent accidental copying
    MutexGuard(const MutexGuard&) = delete;
    MutexGuard& operator=(const MutexGuard&) = delete;
    
private:
    SemaphoreHandle_t mutex_;
};

// C style - error prone!
void update_data_c_style() {
    xSemaphoreTake(dataMutex, portMAX_DELAY);
    
    sharedData++;
    
    if (error_condition) {
        // BUG: Forgot to release mutex!
        return;
    }
    
    // More code...
    
    xSemaphoreGive(dataMutex);
}

// C++ style - automatic cleanup!
void update_data_cpp_style() {
    MutexGuard lock(dataMutex);  // Lock acquired
    
    sharedData++;
    
    if (error_condition) {
        return;  // Mutex AUTOMATICALLY released!
    }
    
    // More code...
    
}  // Mutex released here automatically

// ============================================================================
// EXAMPLE 3: Templates for Type-Safe Generic Code
// ============================================================================

/**
 * Templates - Compile-Time Generic Programming
 * =============================================
 * 
 * Problem in C:
 * - Need separate function for each type
 * - void* loses type safety
 * 
 * Solution in C++:
 * - Write once, works with any type
 * - Compiler generates specialized code
 * - ZERO runtime overhead
 * - Type safe!
 */

// C-style ring buffer (one type only)
typedef struct {
    uint8_t buffer[64];
    size_t head;
    size_t tail;
    size_t count;
} RingBuffer_uint8_t;

// Need separate struct for each type!
typedef struct {
    float buffer[64];
    size_t head;
    size_t tail;
    size_t count;
} RingBuffer_float;

// C++ template - works with ANY type
template<typename T, size_t SIZE>
class RingBuffer {
public:
    RingBuffer() : head_(0), tail_(0), count_(0) {}
    
    bool push(const T& item) {
        if (full()) {
            return false;
        }
        buffer_[head_] = item;
        head_ = (head_ + 1) % SIZE;
        count_++;
        return true;
    }
    
    bool pop(T& item) {
        if (empty()) {
            return false;
        }
        item = buffer_[tail_];
        tail_ = (tail_ + 1) % SIZE;
        count_--;
        return true;
    }
    
    bool full() const { return count_ >= SIZE; }
    bool empty() const { return count_ == 0; }
    size_t size() const { return count_; }
    
private:
    T buffer_[SIZE];  // Type and size are compile-time!
    size_t head_;
    size_t tail_;
    size_t count_;
};

// Usage - compiler generates optimized code for each type
void demo_templates() {
    RingBuffer<uint8_t, 64> uartRx;    // 64-byte buffer
    RingBuffer<float, 100> sensorData;  // 100-float buffer
    RingBuffer<MyStruct, 10> commands;  // 10-command buffer
    
    uint8_t byte = 0x42;
    uartRx.push(byte);
    
    float temperature = 25.5f;
    sensorData.push(temperature);
}

// ============================================================================
// EXAMPLE 4: Const Correctness
// ============================================================================

/**
 * Const Correctness - Document Intent
 * ====================================
 * 
 * const tells compiler and programmers:
 * "This function does not modify the object"
 * 
 * Benefits:
 * - Compiler enforces const correctness
 * - Self-documenting code
 * - Enables optimizations
 * - Prevents bugs
 */

class Sensor {
public:
    Sensor() : value_(0) {}
    
    // const member function - does NOT modify object
    int getValue() const {
        return value_;  // OK: Reading is allowed
        // value_ = 0;  // ERROR: Modifying is not allowed
    }
    
    // Non-const member function - CAN modify object
    void updateValue() {
        value_ = readFromHardware();  // OK: Can modify
    }
    
    // const parameter - function will not modify it
    void calibrate(const float& offset) {
        // Can read offset, cannot modify it
        value_ += static_cast<int>(offset);
    }
    
private:
    int value_;
    
    int readFromHardware() const {
        // Even though this is const, we can read hardware
        return ADC1->DR;
    }
};

// Pass by const reference - fast and safe
void processSensor(const Sensor& sensor) {
    int value = sensor.getValue();  // OK: const function
    // sensor.updateValue();  // ERROR: non-const function
}

// ============================================================================
// EXAMPLE 5: Enum Class (Strongly-Typed Enums)
// ============================================================================

/**
 * Enum Class - Type-Safe Enumerations
 * ====================================
 * 
 * Problem with C enums:
 * - Pollute global namespace
 * - Implicit conversion to int
 * - Name conflicts
 * 
 * C++ enum class:
 * - Scoped to enum
 * - No implicit conversion
 * - Type safe
 */

// C-style enum - problems!
enum Mode {
    MODE_IDLE,
    MODE_ACTIVE
};

enum State {
    STATE_IDLE,  // ERROR: Conflicts with MODE_IDLE
    STATE_BUSY
};

int x = MODE_IDLE;  // Implicitly converts to int

// C++ enum class - better!
enum class OperatingMode {
    Idle,
    Active,
    Sleep
};

enum class SystemState {
    Idle,   // OK: No conflict
    Busy,
    Error
};

// Usage
void demo_enum_class() {
    OperatingMode mode = OperatingMode::Active;  // Must use scope
    
    // Type safe - cannot accidentally mix
    // if (mode == SystemState::Busy) {}  // ERROR: Different types
    
    if (mode == OperatingMode::Active) {
        // Correct comparison
    }
    
    // No implicit conversion
    // int x = mode;  // ERROR: Must explicitly cast
    int x = static_cast<int>(mode);  // Explicit
}

// ============================================================================
// EXAMPLE 6: Inheritance for Hardware Abstraction
// ============================================================================

/**
 * Inheritance and Polymorphism
 * =============================
 * 
 * Create a common interface for similar devices
 * Different implementations share same interface
 */

// Base class - interface for all sensors
class ISensor {
public:
    // Virtual destructor - ALWAYS for base classes
    virtual ~ISensor() = default;
    
    // Pure virtual functions - MUST be implemented by derived classes
    virtual bool init() = 0;
    virtual bool read(float& value) = 0;
    
    // Virtual function with default implementation
    virtual void calibrate() {
        // Default calibration (can be overridden)
    }
};

// Derived class - Temperature sensor
class TemperatureSensor : public ISensor {
public:
    TemperatureSensor(I2C_HandleTypeDef* i2c, uint8_t address)
        : i2c_(i2c), address_(address)
    {}
    
    bool init() override {
        // Temperature sensor specific init
        return i2cWrite(0x20, 0x80);  // Power on
    }
    
    bool read(float& value) override {
        uint16_t raw;
        if (i2cRead(0x00, raw)) {
            value = raw * 0.0625f;  // Convert to Celsius
            return true;
        }
        return false;
    }
    
private:
    I2C_HandleTypeDef* i2c_;
    uint8_t address_;
    
    bool i2cWrite(uint8_t reg, uint8_t data) {
        // Implementation
        return true;
    }
    
    bool i2cRead(uint8_t reg, uint16_t& data) {
        // Implementation
        return true;
    }
};

// Derived class - Pressure sensor
class PressureSensor : public ISensor {
public:
    PressureSensor(I2C_HandleTypeDef* i2c, uint8_t address)
        : i2c_(i2c), address_(address)
    {}
    
    bool init() override {
        // Pressure sensor specific init
        return i2cWrite(0xF4, 0x27);
    }
    
    bool read(float& value) override {
        uint32_t raw;
        if (i2cReadLong(0xF7, raw)) {
            value = raw / 256.0f;  // Convert to hPa
            return true;
        }
        return false;
    }
    
private:
    I2C_HandleTypeDef* i2c_;
    uint8_t address_;
    
    bool i2cWrite(uint8_t reg, uint8_t data) { return true; }
    bool i2cReadLong(uint8_t reg, uint32_t& data) { return true; }
};

// Polymorphism - work with any sensor through base class
void readAllSensors(ISensor** sensors, size_t count) {
    for (size_t i = 0; i < count; i++) {
        float value;
        if (sensors[i]->read(value)) {
            printf("Sensor %d: %.2f\n", i, value);
        }
    }
}

void demo_inheritance() {
    TemperatureSensor tempSensor(&hi2c1, 0x48);
    PressureSensor pressSensor(&hi2c1, 0x77);
    
    ISensor* sensors[] = { &tempSensor, &pressSensor };
    readAllSensors(sensors, 2);
}

// ============================================================================
// EXAMPLE 7: Modern C++ Features (C++11/14/17)
// ============================================================================

/**
 * Modern C++ Features Safe for Embedded
 * ======================================
 */

// 1. Auto type deduction
void demo_auto() {
    auto led = GpioPin(GPIOD, 12);  // Type deduced
    auto value = ADC1->DR;           // uint32_t
    
    // Useful for complex types
    auto buffer = RingBuffer<SensorData, 100>();
}

// 2. Range-based for loops
void demo_range_for() {
    uint32_t data[] = {1, 2, 3, 4, 5};
    
    // Old way
    for (size_t i = 0; i < 5; i++) {
        process(data[i]);
    }
    
    // New way - cleaner
    for (auto value : data) {
        process(value);
    }
    
    // With reference to avoid copying
    for (const auto& value : data) {
        process(value);
    }
}

// 3. nullptr instead of NULL
void demo_nullptr() {
    int* ptr = nullptr;  // Type-safe null pointer
    
    if (ptr != nullptr) {
        // Use ptr
    }
    
    // Benefits:
    void func(int x);
    void func(int* ptr);
    
    // func(NULL);     // Ambiguous! NULL is 0
    func(nullptr);  // Clear - calls func(int*)
}

// 4. constexpr - compile-time computation
constexpr uint32_t factorial(uint32_t n) {
    return n <= 1 ? 1 : n * factorial(n - 1);
}

constexpr uint32_t calculateBRR(uint32_t clock, uint32_t baud) {
    return clock / (16 * baud);
}

void demo_constexpr() {
    // Computed at compile time - zero runtime cost!
    constexpr uint32_t fact5 = factorial(5);  // = 120
    constexpr uint32_t brr = calculateBRR(42000000, 115200);
    
    USART2->BRR = brr;  // Just loads a constant
}

// 5. Static assert - compile-time checking
template<typename T, size_t N>
class StaticArray {
    static_assert(N > 0, "Array size must be positive");
    static_assert(N < 10000, "Array size too large");
    
    T data[N];
};

// ============================================================================
// EXAMPLE 8: Complete Driver Class
// ============================================================================

/**
 * Complete UART Driver Class
 * ===========================
 * 
 * Demonstrates:
 * - RAII (constructor/destructor)
 * - Encapsulation (private data)
 * - Const correctness
 * - Deleted copy operations
 */

class UartDriver {
public:
    UartDriver(USART_TypeDef* uart, uint32_t baudRate)
        : uart_(uart)
        , baudRate_(baudRate)
        , rxHead_(0)
        , rxTail_(0)
    {
        initHardware();
    }
    
    ~UartDriver() {
        // Disable UART
        uart_->CR1 &= ~USART_CR1_UE;
    }
    
    // Delete copy operations - UART is unique resource
    UartDriver(const UartDriver&) = delete;
    UartDriver& operator=(const UartDriver&) = delete;
    
    void transmitByte(uint8_t byte) {
        while (!(uart_->SR & USART_SR_TXE));
        uart_->DR = byte;
    }
    
    void transmitString(const char* str) {
        while (*str) {
            transmitByte(*str++);
        }
    }
    
    bool rxAvailable() const {
        return rxHead_ != rxTail_;
    }
    
    uint8_t readByte() {
        if (!rxAvailable()) {
            return 0;
        }
        uint8_t data = rxBuffer_[rxTail_];
        rxTail_ = (rxTail_ + 1) % RX_BUFFER_SIZE;
        return data;
    }
    
    // Call from ISR
    void rxCallback() {
        uint8_t data = uart_->DR;
        uint16_t nextHead = (rxHead_ + 1) % RX_BUFFER_SIZE;
        if (nextHead != rxTail_) {
            rxBuffer_[rxHead_] = data;
            rxHead_ = nextHead;
        }
    }
    
private:
    static constexpr size_t RX_BUFFER_SIZE = 256;
    
    USART_TypeDef* uart_;
    uint32_t baudRate_;
    uint8_t rxBuffer_[RX_BUFFER_SIZE];
    volatile uint16_t rxHead_;
    volatile uint16_t rxTail_;
    
    void initHardware() {
        // Clock enable, GPIO config, baud rate, etc.
    }
};

// ============================================================================
// BEST PRACTICES SUMMARY
// ============================================================================

/**
 * DO:
 * ✓ Use classes for hardware abstraction
 * ✓ Use RAII for automatic cleanup
 * ✓ Use const correctness
 * ✓ Use templates for generic code
 * ✓ Use enum class for type safety
 * ✓ Use stack/static allocation
 * ✓ Compile with -fno-exceptions -fno-rtti
 * 
 * DON'T:
 * ✗ Use exceptions
 * ✗ Use dynamic memory (new/delete)
 * ✗ Use RTTI (typeid, dynamic_cast)
 * ✗ Use heavy STL (std::vector, std::string)
 * ✗ Use virtual functions in ISRs
 */

// ============================================================================
// INTERVIEW TALKING POINTS
// ============================================================================

/**
 * When asked about C++ experience:
 * 
 * "I have solid C++ fundamentals and understand how to apply them safely
 * in embedded systems. I'm familiar with:
 * 
 * - Classes for hardware abstraction and better code organization
 * - RAII for automatic resource management (mutexes, hardware resources)
 * - Templates for type-safe generic programming without runtime overhead
 * - Const correctness for clearer interfaces
 * - Modern C++ features like auto, constexpr, enum class
 * 
 * I understand embedded C++ best practices:
 * - Avoid exceptions, dynamic allocation, and RTTI
 * - Use stack or static allocation
 * - Compile with -fno-exceptions and -fno-rtti
 * - Leverage zero-cost abstractions
 * 
 * While my production work has been primarily in C, I recognize the value
 * of C++ for complex embedded systems and am eager to apply and expand
 * this knowledge."
 */
