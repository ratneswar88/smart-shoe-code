# eInfochips Embedded Software Engineer - Interview Answers (Part 2)

*Continued from Part 1*

---

## 5. Wi-Fi, MQTT/TLS, WebSocket

### Q: How do you build a reliable MQTT publisher with TLS on an embedded target?

**Answer:**

Building reliable MQTT over TLS requires a **robust state machine, proper certificate management, time synchronization, and comprehensive error handling**.

**Architecture Overview:**

```
State Machine Flow:
INIT → WIFI_CONNECTING → WIFI_CONNECTED → TIME_SYNC → 
TLS_HANDSHAKE → MQTT_CONNECTING → MQTT_CONNECTED → RUNNING → ERROR
    ↑                                                                 ↓
    └─────────────────────────────────────────────────────────────────┘
                    (Exponential backoff + jitter)
```

**Detailed Implementation:**

**1. State Machine with Explicit Error Handling:**

```c
typedef enum {
    MQTT_STATE_INIT,
    MQTT_STATE_WIFI_CONNECTING,
    MQTT_STATE_WIFI_CONNECTED,
    MQTT_STATE_TIME_SYNC,
    MQTT_STATE_TLS_HANDSHAKE,
    MQTT_STATE_MQTT_CONNECTING,
    MQTT_STATE_MQTT_CONNECTED,
    MQTT_STATE_RUNNING,
    MQTT_STATE_ERROR
} mqtt_connection_state_t;

typedef struct {
    mqtt_connection_state_t state;
    uint32_t retry_count;
    uint32_t backoff_ms;
    uint32_t last_error_code;
    uint32_t state_enter_time_ms;
    char last_error_string[64];
} mqtt_context_t;

static mqtt_context_t mqtt_ctx = {
    .state = MQTT_STATE_INIT,
    .retry_count = 0,
    .backoff_ms = 100,
};

#define MAX_RETRY_COUNT      10
#define MAX_BACKOFF_MS       30000
#define STATE_TIMEOUT_MS     30000
```

**2. Certificate Management:**

```c
// Embedded certificate chain in code (DER format)
extern const uint8_t ca_cert_der_start[] asm("_binary_ca_cert_der_start");
extern const uint8_t ca_cert_der_end[]   asm("_binary_ca_cert_der_end");

extern const uint8_t client_cert_der_start[] asm("_binary_client_cert_der_start");
extern const uint8_t client_cert_der_end[]   asm("_binary_client_cert_der_end");

extern const uint8_t client_key_der_start[] asm("_binary_client_key_der_start");
extern const uint8_t client_key_der_end[]   asm("_binary_client_key_der_end");

esp_err_t mqtt_configure_tls(esp_mqtt_client_config_t *mqtt_cfg) {
    // Root CA certificate (validates broker)
    mqtt_cfg->cert_pem = (const char *)ca_cert_der_start;
    mqtt_cfg->cert_len = ca_cert_der_end - ca_cert_der_start;
    
    // Client certificate (mutual TLS)
    mqtt_cfg->client_cert_pem = (const char *)client_cert_der_start;
    mqtt_cfg->client_cert_len = client_cert_der_end - client_cert_der_start;
    
    // Client private key
    mqtt_cfg->client_key_pem = (const char *)client_key_der_start;
    mqtt_cfg->client_key_len = client_key_der_end - client_key_der_start;
    
    // TLS configuration
    mqtt_cfg->use_global_ca_store = false;
    mqtt_cfg->skip_cert_common_name_check = false;  // Enforce CN check
    
    log_info("TLS configured: CA cert %d bytes, Client cert %d bytes",
            mqtt_cfg->cert_len, mqtt_cfg->client_cert_len);
    
    return ESP_OK;
}
```

**3. Time Synchronization (Critical for TLS):**

```c
// TLS requires accurate time for certificate validation
esp_err_t sync_time_sntp(void) {
    log_info("Synchronizing time via NTP...");
    
    // Configure SNTP
    sntp_setoperatingmode(SNTP_OPMODE_POLL);
    sntp_setservername(0, "pool.ntp.org");
    sntp_setservername(1, "time.google.com");
    sntp_init();
    
    // Wait for time sync (with timeout)
    int retry = 0;
    const int max_retry = 15;
    
    while (sntp_get_sync_status() == SNTP_SYNC_STATUS_RESET && ++retry < max_retry) {
        log_info("Waiting for NTP sync... (%d/%d)", retry, max_retry);
        vTaskDelay(pdMS_TO_TICKS(2000));
    }
    
    if (retry >= max_retry) {
        log_error("NTP sync timeout");
        return ESP_ERR_TIMEOUT;
    }
    
    // Verify time is reasonable (after 2020)
    time_t now;
    struct tm timeinfo;
    time(&now);
    localtime_r(&now, &timeinfo);
    
    if (timeinfo.tm_year < (2020 - 1900)) {
        log_error("Invalid time after NTP sync: %04d-%02d-%02d",
                 timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday);
        return ESP_FAIL;
    }
    
    log_info("Time synced: %04d-%02d-%02d %02d:%02d:%02d",
            timeinfo.tm_year + 1900, timeinfo.tm_mon + 1, timeinfo.tm_mday,
            timeinfo.tm_hour, timeinfo.tm_min, timeinfo.tm_sec);
    
    return ESP_OK;
}
```

**4. Non-Blocking MQTT Configuration:**

```c
void mqtt_event_handler(void *handler_args, esp_event_base_t base, 
                       int32_t event_id, void *event_data) {
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
            log_info("MQTT connected to broker");
            mqtt_ctx.state = MQTT_STATE_MQTT_CONNECTED;
            mqtt_ctx.retry_count = 0;
            mqtt_ctx.backoff_ms = 100;
            
            // Subscribe to command topics
            esp_mqtt_client_subscribe(event->client, "device/+/cmd", 1);
            
            metrics.mqtt_connect_count++;
            break;
            
        case MQTT_EVENT_DISCONNECTED:
            log_warning("MQTT disconnected (reason: %d)", event->error_handle->connect_return_code);
            mqtt_ctx.state = MQTT_STATE_ERROR;
            mqtt_ctx.last_error_code = event->error_handle->connect_return_code;
            
            metrics.mqtt_disconnect_count++;
            break;
            
        case MQTT_EVENT_PUBLISHED:
            log_debug("MQTT message published (msg_id=%d)", event->msg_id);
            metrics.mqtt_publish_success++;
            break;
            
        case MQTT_EVENT_DATA:
            log_info("MQTT data received: topic=%.*s, data=%.*s",
                    event->topic_len, event->topic,
                    event->data_len, event->data);
            
            // Handle command
            handle_mqtt_command(event->topic, event->topic_len,
                               event->data, event->data_len);
            break;
            
        case MQTT_EVENT_ERROR:
            log_error("MQTT error: type=%d", event->error_handle->error_type);
            
            if (event->error_handle->error_type == MQTT_ERROR_TYPE_TCP_TRANSPORT) {
                log_error("TCP transport error: 0x%x", event->error_handle->esp_tls_last_esp_err);
            } else if (event->error_handle->error_type == MQTT_ERROR_TYPE_CONNECTION_REFUSED) {
                log_error("Connection refused: %d", event->error_handle->connect_return_code);
            }
            
            mqtt_ctx.state = MQTT_STATE_ERROR;
            mqtt_ctx.last_error_code = event->error_handle->error_type;
            
            metrics.mqtt_error_count++;
            break;
            
        default:
            log_debug("MQTT event: %d", event->event_id);
            break;
    }
}

esp_err_t mqtt_client_init(void) {
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = CONFIG_MQTT_BROKER_URI,  // "mqtts://broker.example.com:8883"
        .credentials.client_id = get_device_id(),
        .session.keepalive = 60,
        .network.timeout_ms = 10000,
        .network.reconnect_timeout_ms = 10000,
        .network.disable_auto_reconnect = true,  // Manual control via state machine
    };
    
    // Configure TLS certificates
    mqtt_configure_tls(&mqtt_cfg);
    
    // Create MQTT client (non-blocking)
    esp_mqtt_client_handle_t client = esp_mqtt_client_init(&mqtt_cfg);
    if (!client) {
        log_error("MQTT client init failed");
        return ESP_FAIL;
    }
    
    // Register event handler
    esp_mqtt_client_register_event(client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);
    
    // Start client (non-blocking connection attempt)
    esp_mqtt_client_start(client);
    
    log_info("MQTT client initialized");
    return ESP_OK;
}
```

**5. State Machine Task with Recovery:**

```c
void mqtt_connection_task(void *params) {
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(100));  // 10 Hz state machine update
        
        // Check for state timeout
        uint32_t now_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
        if (now_ms - mqtt_ctx.state_enter_time_ms > STATE_TIMEOUT_MS) {
            log_error("State %d timeout after %lu ms", mqtt_ctx.state, STATE_TIMEOUT_MS);
            mqtt_ctx.state = MQTT_STATE_ERROR;
        }
        
        switch (mqtt_ctx.state) {
            case MQTT_STATE_INIT:
                log_info("MQTT state: INIT");
                mqtt_ctx.state_enter_time_ms = now_ms;
                
                // Start WiFi connection
                if (wifi_connect(WIFI_SSID, WIFI_PASSWORD) == ESP_OK) {
                    mqtt_ctx.state = MQTT_STATE_WIFI_CONNECTING;
                }
                break;
                
            case MQTT_STATE_WIFI_CONNECTING:
                if (wifi_is_connected()) {
                    log_info("WiFi connected, IP: %s", wifi_get_ip_address());
                    mqtt_ctx.state = MQTT_STATE_WIFI_CONNECTED;
                    mqtt_ctx.state_enter_time_ms = now_ms;
                }
                break;
                
            case MQTT_STATE_WIFI_CONNECTED:
                mqtt_ctx.state = MQTT_STATE_TIME_SYNC;
                mqtt_ctx.state_enter_time_ms = now_ms;
                break;
                
            case MQTT_STATE_TIME_SYNC:
                if (sync_time_sntp() == ESP_OK) {
                    log_info("Time synchronized");
                    mqtt_ctx.state = MQTT_STATE_TLS_HANDSHAKE;
                    mqtt_ctx.state_enter_time_ms = now_ms;
                } else {
                    mqtt_ctx.state = MQTT_STATE_ERROR;
                }
                break;
                
            case MQTT_STATE_TLS_HANDSHAKE:
                // Initiate MQTT connection (includes TLS handshake)
                if (mqtt_client_init() == ESP_OK) {
                    mqtt_ctx.state = MQTT_STATE_MQTT_CONNECTING;
                    mqtt_ctx.state_enter_time_ms = now_ms;
                } else {
                    mqtt_ctx.state = MQTT_STATE_ERROR;
                }
                break;
                
            case MQTT_STATE_MQTT_CONNECTING:
                // Wait for event handler to transition to MQTT_CONNECTED
                break;
                
            case MQTT_STATE_MQTT_CONNECTED:
                // Transition to running state
                mqtt_ctx.state = MQTT_STATE_RUNNING;
                mqtt_ctx.state_enter_time_ms = now_ms;
                log_info("MQTT fully operational");
                break;
                
            case MQTT_STATE_RUNNING:
                // Normal operation: publish telemetry, handle commands
                mqtt_publish_telemetry();
                mqtt_handle_commands();
                
                // Monitor connection health
                if (!mqtt_is_connected()) {
                    log_warning("MQTT connection lost");
                    mqtt_ctx.state = MQTT_STATE_ERROR;
                }
                break;
                
            case MQTT_STATE_ERROR:
                log_error("MQTT error state, initiating recovery");
                
                // Exponential backoff with jitter
                uint32_t jitter_ms = rand() % 1000;
                uint32_t delay_ms = mqtt_ctx.backoff_ms + jitter_ms;
                
                log_info("Retry %lu after %lu ms", mqtt_ctx.retry_count + 1, delay_ms);
                vTaskDelay(pdMS_TO_TICKS(delay_ms));
                
                // Update backoff
                mqtt_ctx.backoff_ms = MIN(mqtt_ctx.backoff_ms * 2, MAX_BACKOFF_MS);
                mqtt_ctx.retry_count++;
                
                if (mqtt_ctx.retry_count > MAX_RETRY_COUNT) {
                    log_error("Max retries exceeded, triggering system reset");
                    esp_restart();
                }
                
                // Restart from init
                mqtt_ctx.state = MQTT_STATE_INIT;
                mqtt_ctx.state_enter_time_ms = now_ms;
                break;
        }
    }
}
```

**6. Quality of Service (QoS) Strategy:**

```c
// QoS 0: At most once (fire and forget)
// QoS 1: At least once (acknowledged)
// QoS 2: Exactly once (complex handshake)

void mqtt_publish_telemetry(void) {
    static uint32_t last_publish_ms = 0;
    uint32_t now_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    // Throttle: Publish every 1 second
    if (now_ms - last_publish_ms < 1000) {
        return;
    }
    last_publish_ms = now_ms;
    
    // High-rate telemetry: QoS 0 (occasional loss acceptable)
    char telemetry[256];
    snprintf(telemetry, sizeof(telemetry), 
            "{\"temp\":%.2f,\"humidity\":%.2f,\"rssi\":%d,\"uptime\":%lu}",
            get_temperature(), get_humidity(), get_rssi(), xTaskGetTickCount());
    
    int msg_id = esp_mqtt_client_publish(mqtt_client, 
                                        "device/sensor/telemetry", 
                                        telemetry, 
                                        0,      // Length (0 = auto)
                                        0,      // QoS 0
                                        false); // Not retained
    
    if (msg_id < 0) {
        log_warning("Telemetry publish failed");
        metrics.mqtt_publish_failures++;
    }
}

void mqtt_publish_event(const char *event_type, const char *event_data) {
    // Important events: QoS 1 (guaranteed delivery)
    char event_msg[512];
    snprintf(event_msg, sizeof(event_msg),
            "{\"type\":\"%s\",\"data\":\"%s\",\"timestamp\":%lu}",
            event_type, event_data, time(NULL));
    
    int msg_id = esp_mqtt_client_publish(mqtt_client,
                                        "device/events",
                                        event_msg,
                                        0,
                                        1,      // QoS 1
                                        false);
    
    if (msg_id < 0) {
        // Critical: Store in offline buffer for retry
        offline_buffer_append(event_msg);
        metrics.events_buffered++;
    }
}
```

**7. Offline Buffering:**

```c
#define OFFLINE_BUFFER_SIZE  10

typedef struct {
    char messages[OFFLINE_BUFFER_SIZE][512];
    uint32_t timestamps[OFFLINE_BUFFER_SIZE];
    uint8_t write_idx;
    uint8_t read_idx;
    uint8_t count;
} offline_buffer_t;

static offline_buffer_t offline_buffer = {0};

void offline_buffer_append(const char *message) {
    if (offline_buffer.count >= OFFLINE_BUFFER_SIZE) {
        log_warning("Offline buffer full, dropping oldest message");
        offline_buffer.read_idx = (offline_buffer.read_idx + 1) % OFFLINE_BUFFER_SIZE;
        offline_buffer.count--;
    }
    
    strncpy(offline_buffer.messages[offline_buffer.write_idx], message, 511);
    offline_buffer.timestamps[offline_buffer.write_idx] = time(NULL);
    offline_buffer.write_idx = (offline_buffer.write_idx + 1) % OFFLINE_BUFFER_SIZE;
    offline_buffer.count++;
    
    log_info("Offline buffer: %u messages pending", offline_buffer.count);
}

void offline_buffer_flush(void) {
    while (offline_buffer.count > 0 && mqtt_is_connected()) {
        const char *msg = offline_buffer.messages[offline_buffer.read_idx];
        
        int msg_id = esp_mqtt_client_publish(mqtt_client,
                                            "device/events/buffered",
                                            msg,
                                            0,
                                            1,  // QoS 1
                                            false);
        
        if (msg_id >= 0) {
            log_info("Flushed buffered message from offline storage");
            offline_buffer.read_idx = (offline_buffer.read_idx + 1) % OFFLINE_BUFFER_SIZE;
            offline_buffer.count--;
            metrics.messages_flushed++;
        } else {
            log_warning("Failed to flush buffered message, will retry");
            break;
        }
        
        vTaskDelay(pdMS_TO_TICKS(100));  // Rate limit
    }
}
```

**8. Certificate Rotation Strategy:**

```c
// Over-the-Air certificate update
esp_err_t mqtt_update_certificates(const char *new_ca_cert, 
                                   const char *new_client_cert,
                                   const char *new_client_key) {
    log_info("Updating TLS certificates...");
    
    // 1. Validate new certificates (parse and check expiry)
    if (validate_certificate_pem(new_ca_cert) != ESP_OK) {
        log_error("Invalid CA certificate");
        return ESP_ERR_INVALID_ARG;
    }
    
    if (validate_certificate_pem(new_client_cert) != ESP_OK) {
        log_error("Invalid client certificate");
        return ESP_ERR_INVALID_ARG;
    }
    
    // 2. Store new certificates in NVS (non-volatile storage)
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open("tls_certs", NVS_READWRITE, &nvs_handle);
    if (ret != ESP_OK) {
        log_error("Failed to open NVS");
        return ret;
    }
    
    nvs_set_str(nvs_handle, "ca_cert", new_ca_cert);
    nvs_set_str(nvs_handle, "client_cert", new_client_cert);
    nvs_set_str(nvs_handle, "client_key", new_client_key);
    nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    
    log_info("New certificates stored in NVS");
    
    // 3. Disconnect and reconnect with new certificates
    esp_mqtt_client_stop(mqtt_client);
    esp_mqtt_client_destroy(mqtt_client);
    
    vTaskDelay(pdMS_TO_TICKS(1000));
    
    // 4. Reinitialize with new certificates
    mqtt_ctx.state = MQTT_STATE_TLS_HANDSHAKE;
    
    log_info("Certificate rotation complete, reconnecting...");
    return ESP_OK;
}
```

**9. Diagnostics and Instrumentation:**

```c
typedef struct {
    uint32_t mqtt_connect_count;
    uint32_t mqtt_disconnect_count;
    uint32_t mqtt_publish_success;
    uint32_t mqtt_publish_failures;
    uint32_t mqtt_error_count;
    uint32_t messages_buffered;
    uint32_t messages_flushed;
    uint32_t tls_handshake_failures;
    uint32_t ntp_sync_failures;
    char last_disconnect_reason[64];
} mqtt_metrics_t;

void mqtt_publish_diagnostics(void) {
    char diagnostics[512];
    snprintf(diagnostics, sizeof(diagnostics),
            "{\"connects\":%lu,\"disconnects\":%lu,"
            "\"pub_success\":%lu,\"pub_fail\":%lu,"
            "\"errors\":%lu,\"buffered\":%lu,\"flushed\":%lu,"
            "\"state\":%d,\"retry_count\":%lu,\"backoff_ms\":%lu}",
            metrics.mqtt_connect_count, metrics.mqtt_disconnect_count,
            metrics.mqtt_publish_success, metrics.mqtt_publish_failures,
            metrics.mqtt_error_count, metrics.messages_buffered,
            metrics.messages_flushed, mqtt_ctx.state, 
            mqtt_ctx.retry_count, mqtt_ctx.backoff_ms);
    
    esp_mqtt_client_publish(mqtt_client, "device/diagnostics", diagnostics, 0, 1, false);
}
```

**Summary:**

**Key Design Principles:**
1. ✅ **Explicit State Machine:** Clear transitions and error handling
2. ✅ **Time Sync First:** NTP synchronization before TLS handshake
3. ✅ **Certificate Validation:** Proper certificate chain with expiry checks
4. ✅ **Non-Blocking:** Dedicated task, doesn't stall other work
5. ✅ **QoS Strategy:** QoS 0 for high-rate telemetry, QoS 1 for critical events
6. ✅ **Offline Buffer:** Short outages don't cause data loss
7. ✅ **Exponential Backoff:** Graceful recovery, avoid server overload
8. ✅ **Instrumentation:** Comprehensive metrics for field diagnosis
9. ✅ **Certificate Rotation:** Support OTA certificate updates

**Common Failure Modes and Solutions:**
- **TLS handshake fails:** Check time sync, certificate validity, and CN matching
- **Frequent disconnects:** Increase keepalive interval, check network stability
- **Publish failures:** Implement offline buffering, verify QoS settings
- **Memory leaks:** Use static buffers, monitor heap usage
- **Connection storms:** Exponential backoff with jitter prevents synchronized retries

### Q: WebSocket vs MQTT - when do you use each?

**Answer:**

**Quick Comparison:**

| Aspect | MQTT | WebSocket |
|--------|------|-----------|
| **Protocol Layer** | Application (on top of TCP) | Transport (upgrades HTTP) |
| **Broker Required** | Yes | No (direct peer-to-peer possible) |
| **Message Pattern** | Pub/Sub with topics | Bidirectional streaming |
| **QoS Built-in** | Yes (QoS 0/1/2) | No (manual implementation) |
| **Overhead** | Low (2-byte header minimum) | Moderate (6-14 byte frame) |
| **IoT Optimized** | Yes (designed for IoT) | No (general purpose) |
| **Firewall Friendly** | Moderate (port 1883/8883) | High (port 80/443) |
| **Browser Support** | No (requires library) | Native (JavaScript) |

**Use MQTT When:**

1. **IoT Platform Integration:**
```c
// AWS IoT Core, Azure IoT Hub, Google Cloud IoT
// These platforms provide MQTT brokers with built-in features:
// - Device registry and authentication
// - Topic-based routing
// - Rules engine for data processing
// - Integration with cloud services

esp_mqtt_client_config_t mqtt_cfg = {
    .broker.address.uri = "mqtts://iot.us-east-1.amazonaws.com:8883",
    .credentials.client_id = device_id,
    // AWS IoT handles routing, rules, shadow state
};
```

2. **Topic-Based Routing:**
```c
// Publish to specific topics
esp_mqtt_client_publish(client, "factory/line1/sensor1/temp", data, 0, 1, 0);
esp_mqtt_client_publish(client, "factory/line1/sensor2/humidity", data, 0, 1, 0);

// Subscribe to wildcard topics
esp_mqtt_client_subscribe(client, "factory/+/+/temp", 1);  // All temp sensors
esp_mqtt_client_subscribe(client, "factory/line1/#", 1);   // All line1 devices
```

3. **QoS Requirements:**
```c
// Critical command: QoS 1 (at least once delivery)
mqtt_publish("device/cmd/firmware_update", payload, QOS_1);

// Telemetry: QoS 0 (best effort, occasional loss OK)
mqtt_publish("device/telemetry/temp", payload, QOS_0);
```

4. **Low Bandwidth / Constrained Networks:**
```
MQTT Overhead:
- Fixed header: 2 bytes minimum
- Topic: Variable (e.g., "device/temp" = 11 bytes)
- Payload: Your data

Example: 100 byte payload
Total: 2 + 11 + 100 = 113 bytes (13% overhead)

WebSocket Overhead:
- Frame header: 6-14 bytes (depending on payload size)
- No topic routing (need to add in application layer)

Example: Same 100 byte payload
Total: 6 + 100 = 106 bytes (6% overhead)
BUT: No topic routing, need to add metadata in payload
```

**Use WebSocket When:**

1. **Real-Time Web Dashboard:**
```javascript
// Browser-native WebSocket support
const ws = new WebSocket('wss://device.local:443/ws');

ws.onopen = () => {
    console.log('Connected to device');
};

ws.onmessage = (event) => {
    const data = JSON.parse(event.data);
    updateChart(data.temperature);  // Real-time chart update
};

ws.send(JSON.stringify({cmd: 'start_logging'}));
```

2. **Direct Device-to-Dashboard Communication:**
```c
// Embedded WebSocket server (no broker needed)
// Example: ESP32 serving real-time sensor data to web UI

httpd_handle_t ws_server = NULL;

// WebSocket handler
esp_err_t ws_handler(httpd_req_t *req) {
    if (req->method == HTTP_GET) {
        // Upgrade to WebSocket
        httpd_ws_frame_t ws_pkt;
        ws_pkt.type = HTTPD_WS_TYPE_TEXT;
        
        while (client_connected) {
            // Send sensor data directly to browser
            char json[256];
            snprintf(json, sizeof(json), 
                    "{\"temp\":%.2f,\"humidity\":%.2f}", 
                    read_temperature(), read_humidity());
            
            ws_pkt.payload = (uint8_t*)json;
            ws_pkt.len = strlen(json);
            httpd_ws_send_frame(req, &ws_pkt);
            
            vTaskDelay(pdMS_TO_TICKS(1000));
        }
    }
    return ESP_OK;
}
```

3. **Custom Backend (Not IoT Platform):**
```c
// Backend is custom Node.js/Python/Go server (not AWS/Azure)
// No need for MQTT broker infrastructure

// WebSocket client on ESP32
esp_websocket_client_config_t ws_cfg = {
    .uri = "wss://my-custom-backend.com/device/stream",
};

esp_websocket_client_handle_t client = esp_websocket_client_init(&ws_cfg);
esp_websocket_register_events(client, WEBSOCKET_EVENT_ANY, ws_event_handler, NULL);
esp_websocket_client_start(client);
```

4. **Bidirectional RPC-Style Communication:**
```c
// Request-Response pattern
// Example: Device queries server for configuration

// Send request
ws_send_text("{\"type\":\"get_config\",\"req_id\":123}");

// Wait for response (with correlation ID)
void ws_event_handler(esp_websocket_event_data_t *data) {
    if (data->op_code == WEBSOCKET_OP_TEXT) {
        parse_response(data->data_ptr);
        // {\"type\":\"config\",\"req_id\":123,\"data\":{...}}
    }
}
```

**Hybrid Architecture Example:**

```c
// Smart Building System:
// - MQTT for cloud telemetry and commands
// - WebSocket for local dashboard

// MQTT Task (cloud connectivity)
void mqtt_cloud_task(void *params) {
    // Connect to AWS IoT Core
    mqtt_connect("mqtts://iot.us-east-1.amazonaws.com:8883");
    
    while (1) {
        // Publish aggregate telemetry every 60 seconds
        mqtt_publish("building/floor3/temp_avg", data, QOS_1);
        vTaskDelay(pdMS_TO_TICKS(60000));
    }
}

// WebSocket Task (local dashboard)
void ws_dashboard_task(void *params) {
    // Serve local WebSocket for building operators
    httpd_start(&server, &config);
    
    while (1) {
        // Stream high-rate data to connected dashboards
        if (ws_clients > 0) {
            ws_broadcast_sensor_data();
            vTaskDelay(pdMS_TO_TICKS(100));  // 10 Hz update
        }
    }
}
```

**Decision Matrix:**

```
Choose MQTT if:
✅ Connecting to IoT platform (AWS IoT, Azure IoT Hub)
✅ Need topic-based pub/sub routing
✅ Require QoS guarantees
✅ Multiple subscribers to same data
✅ Low bandwidth critical
✅ Standard IoT patterns (telemetry, commands, shadow state)

Choose WebSocket if:
✅ Direct web browser integration needed
✅ Custom backend (not IoT platform)
✅ Real-time bidirectional streaming
✅ Firewall traversal critical (HTTP/HTTPS ports)
✅ RPC-style request-response pattern
✅ Low latency more important than QoS

Use Both if:
✅ Cloud integration (MQTT) + Local dashboard (WebSocket)
✅ High-rate local data (WebSocket) + Aggregate cloud data (MQTT)
✅ Redundant connectivity (failover between protocols)
```

**Implementation Similarity:**

Regardless of protocol choice, the embedded design patterns remain similar:

```c
// Common pattern for both MQTT and WebSocket

typedef enum {
    CONN_STATE_DISCONNECTED,
    CONN_STATE_CONNECTING,
    CONN_STATE_CONNECTED,
    CONN_STATE_ERROR
} connection_state_t;

typedef struct {
    connection_state_t state;
    uint32_t retry_count;
    uint32_t backoff_ms;
    // Protocol-specific handle (MQTT or WebSocket)
    void *protocol_handle;
} connection_context_t;

// Both protocols need:
// 1. State machine with recovery
// 2. Exponential backoff
// 3. Health monitoring
// 4. Instrumentation
// 5. Non-blocking I/O
```

**My Typical Choice:**
- **Production IoT device → MQTT** (robust, standardized, IoT platform integration)
- **Development dashboard → WebSocket** (fast iteration, browser-native)
- **Final product → Hybrid** (MQTT for cloud, WebSocket for local monitoring)

---

## 6. Cloud Connectivity: AWS/Azure Patterns

### Q: Describe an end-to-end device flow: provisioning to cloud telemetry.

**Answer:**

An end-to-end IoT device lifecycle involves **provisioning, first-boot, runtime operation, and maintenance**. I'll describe a comprehensive flow using AWS IoT Core as an example.

**Phase 1: Manufacturing and Provisioning**

**1A. Factory Provisioning:**
```c
// During manufacturing, each device receives:
// 1. Unique device ID (based on chip ID or UUID)
// 2. X.509 certificate and private key (burned to secure element)
// 3. Root CA certificate (validates AWS IoT Core)

typedef struct {
    char device_id[64];              // e.g., "shoe-001a2b3c4d5e"
    uint8_t private_key[2048];       // RSA-2048 or ECC-P256 private key
    uint8_t device_cert[2048];       // X.509 device certificate
    uint8_t root_ca_cert[2048];      // AWS IoT Root CA
    bool provisioned;
} device_identity_t;

// Secure storage (eFuse, secure element, or encrypted NVS)
esp_err_t store_device_identity(const device_identity_t *identity) {
    nvs_handle_t nvs_handle;
    esp_err_t ret = nvs_open("device_id", NVS_READWRITE, &nvs_handle);
    
    // Store in encrypted NVS partition
    nvs_set_blob(nvs_handle, "identity", identity, sizeof(device_identity_t));
    nvs_commit(nvs_handle);
    nvs_close(nvs_handle);
    
    log_info("Device identity provisioned: %s", identity->device_id);
    return ESP_OK;
}
```

**1B. Cloud-Side Provisioning:**
```bash
# AWS IoT Core: Create Thing and attach certificate
aws iot create-thing --thing-name shoe-001a2b3c4d5e

# Attach certificate to Thing
aws iot attach-thing-principal \
    --thing-name shoe-001a2b3c4d5e \
    --principal arn:aws:iot:us-east-1:123456789012:cert/abc123...

# Attach policy (defines MQTT permissions)
aws iot attach-policy \
    --policy-name DevicePolicy \
    --target arn:aws:iot:us-east-1:123456789012:cert/abc123...
```

**Phase 2: First Boot Sequence**

```c
void first_boot_sequence(void) {
    log_info("=== First Boot Sequence ===");
    
    // Step 1: Validate device identity
    device_identity_t identity;
    if (load_device_identity(&identity) != ESP_OK || !identity.provisioned) {
        log_error("Device not provisioned! Factory reset required.");
        enter_provisioning_mode();
        return;
    }
    
    log_info("Device ID: %s", identity.device_id);
    
    // Step 2: Connect to WiFi (credentials from BLE provisioning or hardcoded)
    wifi_config_t wifi_config = {
        .sta = {
            .ssid = WIFI_SSID,
            .password = WIFI_PASSWORD,
        },
    };
    
    esp_err_t ret = esp_wifi_set_config(WIFI_IF_STA, &wifi_config);
    esp_wifi_start();
    esp_wifi_connect();
    
    // Wait for IP
    EventBits_t bits = xEventGroupWaitBits(wifi_event_group, 
                                           WIFI_CONNECTED_BIT,
                                           pdFALSE, pdFALSE,
                                           pdMS_TO_TICKS(30000));
    
    if (!(bits & WIFI_CONNECTED_BIT)) {
        log_error("WiFi connection timeout");
        return;
    }
    
    log_info("WiFi connected, IP: %s", get_ip_address());
    
    // Step 3: Sync time via NTP (required for TLS)
    if (sync_time_ntp() != ESP_OK) {
        log_error("NTP sync failed");
        return;
    }
    
    log_info("Time synced: %s", get_time_string());
    
    // Step 4: Validate certificates
    if (validate_certificates(&identity) != ESP_OK) {
        log_error("Certificate validation failed");
        return;
    }
    
    // Step 5: Connect to AWS IoT Core
    esp_mqtt_client_config_t mqtt_cfg = {
        .broker.address.uri = "mqtts://a1b2c3d4e5f6g7-ats.iot.us-east-1.amazonaws.com:8883",
        .credentials.client_id = identity.device_id,
        .cert_pem = (const char *)identity.root_ca_cert,
        .client_cert_pem = (const char *)identity.device_cert,
        .client_key_pem = (const char *)identity.private_key,
    };
    
    mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    esp_mqtt_client_start(mqtt_client);
    
    // Step 6: Wait for connection
    if (wait_for_mqtt_connected(30000) == ESP_OK) {
        log_info("Connected to AWS IoT Core");
        
        // Step 7: Subscribe to command topics
        subscribe_to_commands();
        
        // Step 8: Publish first-boot message
        publish_first_boot_message();
        
        // Step 9: Mark first boot complete
        mark_first_boot_complete();
    } else {
        log_error("AWS IoT connection timeout");
    }
}

void publish_first_boot_message(void) {
    char payload[512];
    snprintf(payload, sizeof(payload),
            "{\"event\":\"first_boot\","
            "\"device_id\":\"%s\","
            "\"fw_version\":\"%s\","
            "\"hw_revision\":\"%s\","
            "\"rssi\":%d,"
            "\"heap_free\":%lu}",
            get_device_id(),
            get_firmware_version(),
            get_hardware_revision(),
            get_rssi(),
            esp_get_free_heap_size());
    
    esp_mqtt_client_publish(mqtt_client, 
                           "$aws/things/shoe-001a2b3c4d5e/shadow/update",
                           payload, 0, 1, false);
}
```

**Phase 3: Runtime Operation**

**3A. Telemetry Publishing:**
```c
// Publish sensor data to AWS IoT Core
void publish_telemetry(void) {
    static uint32_t sequence_number = 0;
    
    // Read sensors
    sensor_data_t sensors = {
        .temperature = read_temperature(),
        .humidity = read_humidity(),
        .pressure = read_pressure(),
        .accel_x = read_accel_x(),
        .accel_y = read_accel_y(),
        .accel_z = read_accel_z(),
    };
    
    // Create JSON payload
    char payload[512];
    snprintf(payload, sizeof(payload),
            "{\"seq\":%lu,"
            "\"ts\":%lu,"
            "\"temp\":%.2f,"
            "\"humidity\":%.2f,"
            "\"pressure\":%.2f,"
            "\"accel\":[%.3f,%.3f,%.3f]}",
            sequence_number++,
            time(NULL),
            sensors.temperature,
            sensors.humidity,
            sensors.pressure,
            sensors.accel_x,
            sensors.accel_y,
            sensors.accel_z);
    
    // Publish to telemetry topic
    int msg_id = esp_mqtt_client_publish(mqtt_client,
                                        "dt/shoe-001a2b3c4d5e/telemetry",
                                        payload,
                                        0,     // Length (0 = auto)
                                        0,     // QoS 0 (high-rate data)
                                        false); // Not retained
    
    if (msg_id < 0) {
        metrics.telemetry_publish_failures++;
    } else {
        metrics.telemetry_publish_success++;
    }
}
```

**3B. Command Handling:**
```c
// Subscribe to command topics
void subscribe_to_commands(void) {
    esp_mqtt_client_subscribe(mqtt_client, 
                             "cmd/shoe-001a2b3c4d5e/+",  // Wildcard for all commands
                             1);  // QoS 1
}

// Handle incoming commands
void mqtt_event_handler(esp_mqtt_event_handle_t event) {
    if (event->event_id == MQTT_EVENT_DATA) {
        log_info("Command received: topic=%.*s", event->topic_len, event->topic);
        
        // Parse command type from topic
        if (strstr(event->topic, "/set_config") != NULL) {
            handle_set_config_command(event->data, event->data_len);
        } else if (strstr(event->topic, "/start_logging") != NULL) {
            handle_start_logging_command(event->data, event->data_len);
        } else if (strstr(event->topic, "/ota_update") != NULL) {
            handle_ota_update_command(event->data, event->data_len);
        } else {
            log_warning("Unknown command: %.*s", event->topic_len, event->topic);
        }
        
        // Send acknowledgment
        send_command_ack(event->topic, "success");
    }
}

void handle_set_config_command(const char *data, int len) {
    // Parse JSON command
    cJSON *json = cJSON_ParseWithLength(data, len);
    if (!json) {
        log_error("Invalid JSON command");
        return;
    }
    
    // Extract parameters
    cJSON *sample_rate = cJSON_GetObjectItem(json, "sample_rate");
    if (cJSON_IsNumber(sample_rate)) {
        set_sample_rate(sample_rate->valueint);
        log_info("Sample rate updated: %d Hz", sample_rate->valueint);
    }
    
    cJSON_Delete(json);
    
    // Persist config to NVS
    save_config_to_nvs();
}
```

**3C. Device Shadow (State Synchronization):**
```c
// AWS IoT Device Shadow pattern
// Reported state: Device publishes current state
// Desired state: Cloud publishes desired state
// Device reconciles differences

void publish_shadow_state(void) {
    char payload[1024];
    snprintf(payload, sizeof(payload),
            "{"
            "\"state\":{"
              "\"reported\":{"
                "\"connected\":true,"
                "\"fw_version\":\"%s\","
                "\"sample_rate\":%d,"
                "\"battery_level\":%d,"
                "\"uptime\":%lu,"
                "\"rssi\":%d"
              "}"
            "}"
            "}",
            get_firmware_version(),
            get_sample_rate(),
            get_battery_level(),
            get_uptime_seconds(),
            get_rssi());
    
    esp_mqtt_client_publish(mqtt_client,
                           "$aws/things/shoe-001a2b3c4d5e/shadow/update",
                           payload, 0, 1, false);
}

void handle_shadow_delta(const char *data, int len) {
    // Device receives delta when desired != reported
    // Example: Cloud sets desired.sample_rate = 200
    
    cJSON *json = cJSON_ParseWithLength(data, len);
    cJSON *state = cJSON_GetObjectItem(json, "state");
    
    cJSON *sample_rate = cJSON_GetObjectItem(state, "sample_rate");
    if (cJSON_IsNumber(sample_rate)) {
        int new_rate = sample_rate->valueint;
        log_info("Shadow delta: sample_rate %d -> %d", get_sample_rate(), new_rate);
        
        // Apply new configuration
        set_sample_rate(new_rate);
        
        // Report updated state
        publish_shadow_state();
    }
    
    cJSON_Delete(json);
}
```

**3D. Device Health Channel:**
```c
// Periodic health metrics for diagnostics
void publish_device_health(void) {
    // Collect health metrics
    device_health_t health = {
        .uptime_seconds = get_uptime_seconds(),
        .reset_reason = esp_reset_reason(),
        .free_heap = esp_get_free_heap_size(),
        .min_free_heap = esp_get_minimum_free_heap_size(),
        .wifi_rssi = get_rssi(),
        .mqtt_reconnect_count = metrics.mqtt_reconnect_count,
        .task_stack_hwm = get_all_task_stack_watermarks(),
    };
    
    char payload[1024];
    snprintf(payload, sizeof(payload),
            "{"
            "\"uptime\":%lu,"
            "\"reset_reason\":%d,"
            "\"heap\":{\"free\":%lu,\"min_free\":%lu},"
            "\"wifi_rssi\":%d,"
            "\"mqtt_reconnects\":%lu,"
            "\"stack_hwm\":{\"sensor\":%u,\"mqtt\":%u,\"main\":%u}"
            "}",
            health.uptime_seconds,
            health.reset_reason,
            health.free_heap,
            health.min_free_heap,
            health.wifi_rssi,
            health.mqtt_reconnect_count,
            health.task_stack_hwm.sensor,
            health.task_stack_hwm.mqtt,
            health.task_stack_hwm.main);
    
    // Publish to health topic
    esp_mqtt_client_publish(mqtt_client,
                           "dt/shoe-001a2b3c4d5e/health",
                           payload, 0, 1, false);
}
```

**Phase 4: Maintenance**

**4A. Over-the-Air (OTA) Firmware Updates:**
```c
// OTA update triggered by cloud command
void handle_ota_update_command(const char *data, int len) {
    cJSON *json = cJSON_ParseWithLength(data, len);
    cJSON *fw_url = cJSON_GetObjectItem(json, "firmware_url");
    cJSON *fw_version = cJSON_GetObjectItem(json, "version");
    
    if (!cJSON_IsString(fw_url) || !cJSON_IsString(fw_version)) {
        log_error("Invalid OTA command");
        cJSON_Delete(json);
        return;
    }
    
    log_info("OTA update to version %s from %s", 
            fw_version->valuestring, fw_url->valuestring);
    
    // Download and apply firmware update
    esp_err_t ret = perform_ota_update(fw_url->valuestring);
    
    if (ret == ESP_OK) {
        // Publish success before reboot
        publish_ota_status("success", fw_version->valuestring);
        vTaskDelay(pdMS_TO_TICKS(1000));
        
        log_info("OTA complete, rebooting...");
        esp_restart();
    } else {
        publish_ota_status("failed", fw_version->valuestring);
        log_error("OTA failed: %s", esp_err_to_name(ret));
    }
    
    cJSON_Delete(json);
}

esp_err_t perform_ota_update(const char *url) {
    // Configure OTA partition
    esp_http_client_config_t config = {
        .url = url,
        .cert_pem = (char *)server_cert_pem_start,
        .timeout_ms = 10000,
    };
    
    esp_https_ota_config_t ota_config = {
        .http_config = &config,
    };
    
    esp_https_ota_handle_t https_ota_handle = NULL;
    esp_err_t err = esp_https_ota_begin(&ota_config, &https_ota_handle);
    if (err != ESP_OK) {
        log_error("OTA begin failed");
        return err;
    }
    
    // Download firmware in chunks
    while (1) {
        err = esp_https_ota_perform(https_ota_handle);
        if (err != ESP_ERR_HTTPS_OTA_IN_PROGRESS) {
            break;
        }
        
        // Report progress
        int progress = esp_https_ota_get_image_len_read(https_ota_handle);
        publish_ota_progress(progress);
    }
    
    if (err == ESP_OK) {
        // Verify and commit update
        err = esp_https_ota_finish(https_ota_handle);
        log_info("OTA update complete");
    } else {
        esp_https_ota_abort(https_ota_handle);
        log_error("OTA update failed");
    }
    
    return err;
}
```

**4B. Configuration Updates:**
```c
// Cloud-triggered configuration updates
void handle_config_update(const char *config_json) {
    log_info("Applying configuration update");
    
    // Parse and validate new configuration
    device_config_t new_config;
    if (parse_config_json(config_json, &new_config) != ESP_OK) {
        log_error("Invalid configuration");
        return;
    }
    
    // Apply configuration
    apply_config(&new_config);
    
    // Persist to NVS
    save_config_to_nvs(&new_config);
    
    // Report updated state
    publish_shadow_state();
    
    log_info("Configuration applied successfully");
}
```

**4C. Certificate Rotation:**
```c
// Periodic certificate rotation (before expiry)
void check_certificate_expiry(void) {
    time_t now = time(NULL);
    time_t cert_expiry = get_certificate_expiry_time();
    
    int days_until_expiry = (cert_expiry - now) / 86400;
    
    if (days_until_expiry < 30) {
        log_warning("Certificate expires in %d days", days_until_expiry);
        
        // Request new certificate from cloud
        request_certificate_rotation();
    }
}
```

**Failure Handling and Safety:**

```c
// Graceful degradation when cloud is unavailable
void cloud_unavailable_mode(void) {
    log_warning("Operating in offline mode (cloud unavailable)");
    
    // Continue local operation
    // - Sensors still sampled
    // - Data buffered for later upload
    // - Critical functions still work
    
    // Periodic reconnection attempts
    static uint32_t last_reconnect_attempt = 0;
    uint32_t now = xTaskGetTickCount();
    
    if (now - last_reconnect_attempt > pdMS_TO_TICKS(60000)) {
        log_info("Attempting cloud reconnect...");
        mqtt_reconnect();
        last_reconnect_attempt = now;
    }
}
```

**Summary of End-to-End Flow:**

```
Manufacturing:
├─ Burn device ID, certificates to secure storage
└─ Register device in cloud (AWS IoT Core)

First Boot:
├─ Load device identity
├─ Connect WiFi
├─ Sync time (NTP)
├─ Validate certificates
├─ Connect MQTT (TLS)
├─ Subscribe to commands
├─ Publish first-boot message
└─ Update device shadow

Runtime:
├─ Publish telemetry (QoS 0, high-rate)
├─ Publish events (QoS 1, critical)
├─ Handle commands (config, OTA, etc.)
├─ Sync device shadow state
├─ Publish health metrics
└─ Buffer data during outages

Maintenance:
├─ OTA firmware updates
├─ Configuration updates
├─ Certificate rotation
└─ Remote diagnostics
```

**Key Principles:**
1. ✅ **Secure by Default:** TLS + X.509 mutual authentication
2. ✅ **Graceful Degradation:** Operate offline, buffer data
3. ✅ **Observable:** Health metrics, diagnostics, logging
4. ✅ **Recoverable:** OTA updates, remote config, rollback
5. ✅ **Fail-Safe:** Never brick device (bootloader safety)

### Q: How do you design an OTA update mechanism for reliability?

**Answer:**

A reliable OTA update mechanism must handle **power loss, network failures, and corrupted downloads** without bricking the device.

**Architecture: Dual-Partition (A/B) with Bootloader Validation**

```
Flash Layout:
┌──────────────────────────┐
│ Bootloader               │ 64 KB (read-only, never updated)
├──────────────────────────┤
│ Partition Table          │ 4 KB
├──────────────────────────┤
│ OTA Data Partition       │ 8 KB (stores boot state)
├──────────────────────────┤
│ Factory Partition        │ 1 MB (original firmware, fallback)
├──────────────────────────┤
│ OTA_0 (App Partition A)  │ 1.5 MB (active firmware)
├──────────────────────────┤
│ OTA_1 (App Partition B)  │ 1.5 MB (new firmware)
├──────────────────────────┤
│ NVS (Config)             │ 64 KB
├──────────────────────────┤
│ SPIFFS (Data)            │ Remaining space
└──────────────────────────┘
```

**OTA State Machine:**

```c
typedef enum {
    OTA_STATE_IDLE,
    OTA_STATE_DOWNLOADING,
    OTA_STATE_VERIFYING,
    OTA_STATE_ACTIVATING,
    OTA_STATE_REBOOTING,
    OTA_STATE_SUCCESS,
    OTA_STATE_FAILED,
    OTA_STATE_ROLLBACK
} ota_state_t;

typedef struct {
    ota_state_t state;
    char firmware_url[256];
    char target_version[32];
    size_t total_size;
    size_t downloaded_size;
    uint32_t download_start_ms;
    esp_ota_handle_t ota_handle;
    const esp_partition_t *update_partition;
    char sha256_expected[65];
    char sha256_actual[65];
} ota_context_t;
```

**Step 1: Pre-Download Validation**

```c
esp_err_t ota_start(const char *firmware_url, const char *target_version, 
                    const char *sha256_hash) {
    log_info("=== OTA Update Start ===");
    log_info("Current version: %s", get_current_version());
    log_info("Target version: %s", target_version);
    log_info("URL: %s", firmware_url);
    
    // Validate inputs
    if (!firmware_url || !target_version || !sha256_hash) {
        log_error("Invalid OTA parameters");
        return ESP_ERR_INVALID_ARG;
    }
    
    // Check if already on target version
    if (strcmp(get_current_version(), target_version) == 0) {
        log_info("Already on target version, skipping OTA");
        return ESP_OK;
    }
    
    // Check available space
    const esp_partition_t *update_partition = esp_ota_get_next_update_partition(NULL);
    if (!update_partition) {
        log_error("No OTA partition available");
        return ESP_FAIL;
    }
    
    log_info("OTA partition: %s (size: %lu bytes)", 
            update_partition->label, update_partition->size);
    
    // Initialize OTA context
    ota_ctx.state = OTA_STATE_DOWNLOADING;
    strncpy(ota_ctx.firmware_url, firmware_url, sizeof(ota_ctx.firmware_url) - 1);
    strncpy(ota_ctx.target_version, target_version, sizeof(ota_ctx.target_version) - 1);
    strncpy(ota_ctx.sha256_expected, sha256_hash, sizeof(ota_ctx.sha256_expected) - 1);
    ota_ctx.update_partition = update_partition;
    ota_ctx.total_size = 0;
    ota_ctx.downloaded_size = 0;
    ota_ctx.download_start_ms = xTaskGetTickCount() * portTICK_PERIOD_MS;
    
    // Begin OTA
    esp_err_t ret = esp_ota_begin(update_partition, OTA_SIZE_UNKNOWN, &ota_ctx.ota_handle);
    if (ret != ESP_OK) {
        log_error("esp_ota_begin failed: %s", esp_err_to_name(ret));
        ota_ctx.state = OTA_STATE_FAILED;
        return ret;
    }
    
    log_info("OTA download started");
    return ESP_OK;
}
```

**Step 2: Resumable Download with Integrity Checks**

```c
esp_err_t ota_download_chunk(const uint8_t *data, size_t len) {
    // Write chunk to OTA partition
    esp_err_t ret = esp_ota_write(ota_ctx.ota_handle, data, len);
    if (ret != ESP_OK) {
        log_error("esp_ota_write failed: %s", esp_err_to_name(ret));
        ota_ctx.state = OTA_STATE_FAILED;
        return ret;
    }
    
    ota_ctx.downloaded_size += len;
    
    // Report progress every 10%
    if (ota_ctx.total_size > 0) {
        uint32_t progress_pct = (ota_ctx.downloaded_size * 100) / ota_ctx.total_size;
        static uint32_t last_reported_pct = 0;
        
        if (progress_pct >= last_reported_pct + 10) {
            log_info("OTA progress: %lu%%", progress_pct);
            publish_ota_progress(progress_pct);
            last_reported_pct = progress_pct;
        }
    }
    
    return ESP_OK;
}

// HTTP download with resume support
esp_err_t ota_download_from_url(void) {
    esp_http_client_config_t config = {
        .url = ota_ctx.firmware_url,
        .cert_pem = (char *)server_cert_pem_start,
        .timeout_ms = 10000,
        .buffer_size = 4096,
    };
    
    esp_http_client_handle_t client = esp_http_client_init(&config);
    
    // Set Range header for resume support
    if (ota_ctx.downloaded_size > 0) {
        char range_header[64];
        snprintf(range_header, sizeof(range_header), "bytes=%zu-", ota_ctx.downloaded_size);
        esp_http_client_set_header(client, "Range", range_header);
        log_info("Resuming download from byte %zu", ota_ctx.downloaded_size);
    }
    
    esp_err_t ret = esp_http_client_open(client, 0);
    if (ret != ESP_OK) {
        log_error("HTTP client open failed");
        esp_http_client_cleanup(client);
        return ret;
    }
    
    // Get content length
    int content_length = esp_http_client_fetch_headers(client);
    if (content_length <= 0) {
        log_error("Invalid content length");
        esp_http_client_cleanup(client);
        return ESP_FAIL;
    }
    
    ota_ctx.total_size = ota_ctx.downloaded_size + content_length;
    log_info("Total firmware size: %zu bytes", ota_ctx.total_size);
    
    // Download in chunks
    uint8_t buffer[4096];
    int data_read;
    
    while ((data_read = esp_http_client_read(client, (char *)buffer, sizeof(buffer))) > 0) {
        ret = ota_download_chunk(buffer, data_read);
        if (ret != ESP_OK) {
            break;
        }
        
        // Allow other tasks to run
        vTaskDelay(pdMS_TO_TICKS(10));
    }
    
    esp_http_client_close(client);
    esp_http_client_cleanup(client);
    
    if (data_read < 0) {
        log_error("HTTP read error");
        return ESP_FAIL;
    }
    
    log_info("Download complete: %zu bytes", ota_ctx.downloaded_size);
    return ESP_OK;
}
```

**Step 3: Cryptographic Verification**

```c
esp_err_t ota_verify_firmware(void) {
    log_info("=== Verifying OTA Firmware ===");
    ota_ctx.state = OTA_STATE_VERIFYING;
    
    // 1. End OTA write (finalizes partition)
    esp_err_t ret = esp_ota_end(ota_ctx.ota_handle);
    if (ret != ESP_OK) {
        log_error("esp_ota_end failed: %s", esp_err_to_name(ret));
        ota_ctx.state = OTA_STATE_FAILED;
        return ret;
    }
    
    // 2. Calculate SHA-256 hash of downloaded firmware
    uint8_t sha256[32];
    ret = esp_partition_get_sha256(ota_ctx.update_partition, sha256);
    if (ret != ESP_OK) {
        log_error("Failed to calculate SHA-256");
        ota_ctx.state = OTA_STATE_FAILED;
        return ret;
    }
    
    // Convert to hex string
    for (int i = 0; i < 32; i++) {
        sprintf(&ota_ctx.sha256_actual[i * 2], "%02x", sha256[i]);
    }
    ota_ctx.sha256_actual[64] = '\0';
    
    log_info("Expected SHA-256: %s", ota_ctx.sha256_expected);
    log_info("Actual SHA-256:   %s", ota_ctx.sha256_actual);
    
    // 3. Compare hashes
    if (strncmp(ota_ctx.sha256_expected, ota_ctx.sha256_actual, 64) != 0) {
        log_error("SHA-256 mismatch! Firmware corrupted.");
        ota_ctx.state = OTA_STATE_FAILED;
        return ESP_FAIL;
    }
    
    log_info("Firmware integrity verified ✓");
    
    // 4. Verify firmware signature (if applicable)
    // ret = verify_firmware_signature(ota_ctx.update_partition);
    
    return ESP_OK;
}
```

**Step 4: Bootloader-Level Validation (Trial Boot)**

```c
esp_err_t ota_activate_and_reboot(void) {
    log_info("=== Activating OTA Firmware ===");
    ota_ctx.state = OTA_STATE_ACTIVATING;
    
    // Set new partition as boot partition
    esp_err_t ret = esp_ota_set_boot_partition(ota_ctx.update_partition);
    if (ret != ESP_OK) {
        log_error("esp_ota_set_boot_partition failed");
        ota_ctx.state = OTA_STATE_FAILED;
        return ret;
    }
    
    log_info("Boot partition set to: %s", ota_ctx.update_partition->label);
    
    // Publish OTA status before reboot
    publish_ota_status("activating", ota_ctx.target_version);
    vTaskDelay(pdMS_TO_TICKS(1000));  // Allow message to send
    
    log_info("Rebooting to new firmware in 3 seconds...");
    vTaskDelay(pdMS_TO_TICKS(3000));
    
    ota_ctx.state = OTA_STATE_REBOOTING;
    esp_restart();
    
    return ESP_OK;  // Never reached
}

// After reboot: New firmware validates itself
void ota_post_boot_validation(void) {
    const esp_partition_t *running_partition = esp_ota_get_running_partition();
    esp_ota_img_states_t ota_state;
    
    esp_err_t ret = esp_ota_get_state_partition(running_partition, &ota_state);
    if (ret != ESP_OK) {
        log_error("Failed to get OTA state");
        return;
    }
    
    log_info("OTA state: %d", ota_state);
    
    if (ota_state == ESP_OTA_IMG_PENDING_VERIFY) {
        log_info("New firmware booted, running validation tests...");
        
        // Run health checks
        bool validation_passed = true;
        
        // 1. Check critical peripherals
        if (sensor_self_test() != ESP_OK) {
            log_error("Sensor self-test failed");
            validation_passed = false;
        }
        
        // 2. Check WiFi connectivity
        if (wifi_connect_test() != ESP_OK) {
            log_error("WiFi connectivity test failed");
            validation_passed = false;
        }
        
        // 3. Check MQTT connectivity
        if (mqtt_connect_test() != ESP_OK) {
            log_error("MQTT connectivity test failed");
            validation_passed = false;
        }
        
        // 4. Verify config schema compatibility
        if (validate_config_schema() != ESP_OK) {
            log_error("Config schema incompatible");
            validation_passed = false;
        }
        
        if (validation_passed) {
            log_info("Validation passed, marking firmware as valid");
            esp_ota_mark_app_valid_cancel_rollback();
            publish_ota_status("success", get_current_version());
        } else {
            log_error("Validation failed, rolling back to previous firmware");
            esp_ota_mark_app_invalid_rollback_and_reboot();
            // Device will reboot to previous firmware
        }
    } else if (ota_state == ESP_OTA_IMG_VALID) {
        log_info("Running validated firmware");
    } else if (ota_state == ESP_OTA_IMG_INVALID) {
        log_warning("Running invalid firmware (rollback occurred)");
    }
}
```

**Step 5: Automatic Rollback on Failure**

```c
// Watchdog-triggered rollback
// If new firmware crashes or hangs, watchdog triggers rollback

void watchdog_rollback_handler(void) {
    const esp_partition_t *running_partition = esp_ota_get_running_partition();
    esp_ota_img_states_t ota_state;
    
    esp_ota_get_state_partition(running_partition, &ota_state);
    
    if (ota_state == ESP_OTA_IMG_PENDING_VERIFY) {
        log_error("Watchdog triggered during OTA validation, rolling back!");
        
        // Mark current firmware as invalid
        esp_ota_mark_app_invalid_rollback_and_reboot();
        // Bootloader will boot previous firmware on next reset
    }
}
```

**Handling Power Loss During Update:**

```c
// Power loss scenarios:

// 1. During download:
//    - Resume from last written byte (HTTP Range header)
//    - OTA partition incomplete, running partition unchanged
//    - Safe: Device still boots to old firmware

// 2. During verification:
//    - Download complete, verification incomplete
//    - OTA partition written but not activated
//    - Safe: Device still boots to old firmware

// 3. During activation (before reboot):
//    - New partition marked as boot partition
//    - Device hasn't rebooted yet
//    - Safe: On next power-on, bootloader validates new firmware

// 4. During first boot of new firmware:
//    - New firmware booted, health checks running
//    - If power lost before marking valid, bootloader rolls back
//    - Safe: Bootloader enforces max boot attempts

void ota_power_loss_recovery(void) {
    // On every boot, check for interrupted OTA
    nvs_handle_t nvs;
    nvs_open("ota_state", NVS_READONLY, &nvs);
    
    ota_state_t saved_state;
    size_t len = sizeof(saved_state);
    esp_err_t ret = nvs_get_blob(nvs, "ota_ctx", &saved_state, &len);
    
    if (ret == ESP_OK) {
        if (saved_state == OTA_STATE_DOWNLOADING) {
            log_info("Resuming interrupted OTA download");
            // Resume download using Range header
            ota_resume_download();
        } else if (saved_state == OTA_STATE_VERIFYING) {
            log_info("Restarting interrupted OTA verification");
            ota_verify_firmware();
        }
    }
    
    nvs_close(nvs);
}
```

**Configuration Schema Migration:**

```c
#define CONFIG_SCHEMA_VERSION  3

typedef struct {
    uint32_t schema_version;
    // v1 fields
    uint32_t sample_rate;
    // v2 fields (added in firmware v2.0)
    uint32_t reporting_interval;
    // v3 fields (added in firmware v3.0)
    char device_name[32];
} device_config_t;

esp_err_t migrate_config_schema(device_config_t *config) {
    if (config->schema_version == CONFIG_SCHEMA_VERSION) {
        log_info("Config schema up-to-date (v%lu)", config->schema_version);
        return ESP_OK;
    }
    
    log_info("Migrating config schema from v%lu to v%lu", 
            config->schema_version, CONFIG_SCHEMA_VERSION);
    
    // Migrate v1 → v2
    if (config->schema_version == 1) {
        config->reporting_interval = 60;  // Default value for new field
        config->schema_version = 2;
    }
    
    // Migrate v2 → v3
    if (config->schema_version == 2) {
        strncpy(config->device_name, "unnamed", sizeof(config->device_name));
        config->schema_version = 3;
    }
    
    // Save migrated config
    save_config_to_nvs(config);
    
    log_info("Config migration complete");
    return ESP_OK;
}
```

**OTA Metrics and Logging:**

```c
typedef struct {
    uint32_t ota_attempts;
    uint32_t ota_successes;
    uint32_t ota_failures;
    uint32_t ota_rollbacks;
    uint32_t last_ota_duration_ms;
    char last_ota_version[32];
    time_t last_ota_timestamp;
} ota_metrics_t;

void publish_ota_metrics(void) {
    char payload[512];
    snprintf(payload, sizeof(payload),
            "{\"ota_metrics\":{"
            "\"attempts\":%lu,"
            "\"successes\":%lu,"
            "\"failures\":%lu,"
            "\"rollbacks\":%lu,"
            "\"last_duration_ms\":%lu,"
            "\"last_version\":\"%s\","
            "\"last_timestamp\":%ld"
            "}}",
            ota_metrics.ota_attempts,
            ota_metrics.ota_successes,
            ota_metrics.ota_failures,
            ota_metrics.ota_rollbacks,
            ota_metrics.last_ota_duration_ms,
            ota_metrics.last_ota_version,
            ota_metrics.last_ota_timestamp);
    
    mqtt_publish("device/ota/metrics", payload, QOS_1);
}
```

**Summary:**

**Key Reliability Features:**
1. ✅ **A/B Partitioning:** Never overwrite running firmware
2. ✅ **Resumable Downloads:** HTTP Range header for recovery
3. ✅ **Cryptographic Validation:** SHA-256 + signature verification
4. ✅ **Trial Boot:** Health checks before committing
5. ✅ **Automatic Rollback:** Bootloader + watchdog enforcement
6. ✅ **Schema Migration:** Config compatibility across versions
7. ✅ **Power-Loss Safe:** Interruption at any stage is recoverable
8. ✅ **Factory Fallback:** Original firmware always available

**OTA Flow Summary:**
```
Cloud Command → Download (resumable) → Verify Hash → Activate → Reboot →
Health Checks → Mark Valid OR Rollback
```

**Safety Guarantees:**
- **Never brick:** Bootloader enforces max boot attempts (3), then rolls back
- **Power loss safe:** Every stage is atomic or resumable
- **Network failure safe:** Partial downloads are resumable
- **Corrupted download:** SHA-256 verification catches corruption
- **Failed validation:** Automatic rollback to previous firmware
- **Factory reset:** Factory partition always available as last resort

---

[*Document continues with sections 7-11 covering Debugging, Testing, Documentation, and Rapid-Fire Questions...*]

---

## Additional Resources

**Interview Preparation Checklist:**
- [ ] Review all technical answers above
- [ ] Prepare STAR stories for each section
- [ ] Practice explaining concepts out loud (60-120 seconds)
- [ ] Rehearse smart shoe project end-to-end
- [ ] Review resume for technical depth alignment
- [ ] Prepare 3-5 questions for interviewer
- [ ] Print or save this document for reference

**Key Themes to Emphasize:**
1. **Production-Quality Focus:** FDA compliance, field reliability
2. **Instrumentation:** Logging, metrics, observability
3. **State Machines:** Explicit, testable, recoverable
4. **Determinism:** Bounded queues, timing constraints
5. **End-to-End Ownership:** Architecture → Testing → Deployment

Good luck with your interview at eInfochips!
