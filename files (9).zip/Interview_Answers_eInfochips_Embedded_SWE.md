# eInfochips Embedded Software Engineer - Interview Answers Guide

**Prepared for: Roy**  
**Position: Senior Embedded Firmware Engineer**  
**Date: February 2025**

---

## Table of Contents
1. [Opening and Fit Questions](#1-opening-and-fit)
2. [C/C++ and Embedded Fundamentals](#2-cc-and-embedded-fundamentals)
3. [RTOS: Zephyr or FreeRTOS](#3-rtos-zephyr-or-freertos)
4. [Low-Level Interfaces and Bring-up](#4-low-level-interfaces-and-bring-up)
5. [Wi-Fi, MQTT/TLS, WebSocket](#5-wi-fi-mqtttls-websocket)
6. [Cloud Connectivity: AWS/Azure Patterns](#6-cloud-connectivity-awsazure-patterns)
7. [Debugging and Performance](#7-debugging-and-performance)
8. [Testing and Python Automation](#8-testing-and-python-automation)
9. [Documentation, Process, and Collaboration](#9-documentation-process-and-collaboration)
10. [Role-Specific Deep Dives](#10-role-specific-deep-dives)
11. [Rapid-Fire Questions](#11-rapid-fire-questions)

---

## 1. Opening and Fit

### Q: Tell me about yourself and why this role.

**Answer:**

I'm a Senior Embedded Firmware Engineer with over 12 years of experience specializing in biomedical wearables and connected IoT devices. My work sits at the intersection of real-time embedded systems, wireless connectivity, and sensor integration—taking products from initial board bring-up through field-ready production deployment.

Throughout my career, I've focused on building robust, FDA-compliant systems that operate reliably in real-world conditions. My experience spans the full embedded stack: low-level driver development for ARM Cortex platforms (M4/M7), RTOS-based firmware architecture using FreeRTOS, sensor fusion with IMUs and environmental sensors, and wireless connectivity over BLE and Wi-Fi.

What particularly excites me about this role is the combination of:
- **Modern RTOS frameworks** (Zephyr/FreeRTOS) - which I've used extensively for task scheduling, inter-task communication, and resource management
- **Production-grade connectivity** - implementing robust BLE/Wi-Fi stacks with MQTT over TLS, handling edge cases like reconnection storms and certificate management
- **End-to-end ownership** - from architecture design through testing, documentation, and field deployment
- **Onsite collaboration** - working directly with hardware and cross-functional teams to solve complex integration challenges

I'm motivated by building systems that work reliably in the field, not just in the lab. I believe in instrumenting code from day one with proper logging, health metrics, and diagnostic capabilities, which dramatically reduces debug time and improves long-term maintainability.

**Key Strengths:**
- RTOS architecture and inter-task communication
- BLE GATT service design and optimization
- Sensor integration (I2C/SPI) with signal processing pipelines
- Power optimization and battery life analysis
- FDA regulatory compliance and design controls
- Python test automation and CI/CD integration

### Q: Describe a recent embedded project end-to-end.

**Answer:**

I'd like to describe my smart shoe gait analysis platform, which showcases end-to-end embedded system development from sensors to cloud telemetry.

**Project Overview:**
A wearable IoT device embedded in footwear that performs real-time gait analysis using multi-sensor fusion. The system samples IMU data at 100Hz, processes it on-device for stride detection and ZUPT (Zero-velocity Update) algorithms, and streams results via BLE to a mobile dashboard.

**My Technical Responsibilities:**

**1. Hardware Integration & Driver Development:**
- Integrated ICM-42688 6-axis IMU over SPI at 100Hz sample rate
- Implemented MS5637 barometric pressure sensor over I2C for altitude tracking
- Developed DMA-based SPI drivers to offload CPU during continuous sampling
- Created calibration routines for IMU bias correction and orientation alignment

**2. Real-Time System Architecture (ESP32-S3 with FreeRTOS):**
- Designed 4-tier task architecture:
  - **High-priority ISR handler** (50μs execution time) for timestamping sensor data
  - **Sensor sampling task** (Priority 23) running at 100Hz with tight timing constraints
  - **Processing task** (Priority 20) for stride detection, ZUPT algorithm, and sensor fusion
  - **BLE communication task** (Priority 18) for non-blocking data transmission
  - **Logging/diagnostics task** (Priority 10) for system health monitoring
- Implemented ring buffers with backpressure handling between tasks
- Used FreeRTOS queues for inter-task messaging with bounded queue sizes to prevent memory exhaustion

**3. BLE GATT Service Design:**
- Created custom GATT profile with optimized characteristics:
  - Real-time streaming characteristic (notify, 244-byte MTU) for sensor data at ~20 packets/sec
  - Command characteristic (write) for device configuration
  - Status characteristic (read/notify) for system health metrics
- Negotiated maximum MTU (517 bytes on iOS, 244 bytes baseline) to minimize packet overhead
- Implemented connection parameter optimization (7.5ms-15ms interval) for low latency

**4. Power Optimization:**
- Developed patent-pending algorithm for adaptive sampling that reduced power by 30%
- Implemented dynamic clock scaling based on motion state (active walk vs. idle)
- Optimized BLE advertising intervals and connection parameters for battery life
- Measured and validated 12+ hours continuous operation on 200mAh battery

**5. Signal Processing Pipeline:**
- Implemented ZUPT algorithm for drift-free stride length estimation
- Developed Kalman filter for sensor fusion (IMU + barometer)
- Created event detection state machine for gait phase identification (heel-strike, toe-off, swing)
- Validated accuracy against motion capture ground truth (±2cm stride length error)

**6. Reliability & Field Readiness:**
- Designed robust reconnection state machine with exponential backoff (100ms → 5 seconds)
- Implemented watchdog strategy with graceful recovery and telemetry logging
- Added comprehensive instrumentation:
  - Health counters: packet drops, reconnects, sensor failures
  - Performance metrics: task execution times, heap/stack watermarks, CPU utilization
  - Error codes with descriptive enumerations for field diagnosis
- Developed memory profiling tools to catch leaks during 48-hour stress tests

**7. Testing & Validation:**
- Created Python automation framework for:
  - Automated BLE connection/disconnection stress tests (1000+ cycles)
  - Data integrity validation (CRC checks on streaming packets)
  - Performance regression testing (measuring latency and throughput)
- Developed hardware-in-the-loop test rig with programmable motion platform
- Performed extensive field testing with 50+ volunteers for different gait patterns

**Quantifiable Results:**
- **Latency:** Reduced sensor-to-BLE latency from 150ms to 45ms through optimization
- **Reliability:** Achieved <0.1% packet loss rate in nominal conditions
- **Power:** 30% reduction in power consumption through adaptive algorithms
- **Debug efficiency:** Instrumentation reduced average bug diagnosis time from days to hours
- **Field stability:** Zero critical field failures in 6-month deployment with 100+ units

**Technical Artifacts Produced:**
- Detailed design document with state machine diagrams and data flow charts
- Comprehensive test plan with test cases for edge conditions
- API documentation for BLE GATT service
- Python test automation suite with CI/CD integration
- Release notes with version history and known limitations

This project demonstrates my ability to own the full embedded development lifecycle while maintaining production-quality standards throughout.

---

## 2. C/C++ and Embedded Fundamentals

### Q: How do you handle memory safety and performance in embedded C/C++?

**Answer:**

My approach to memory safety and performance centers on **determinism and observability**:

**Memory Safety Strategies:**

**1. Minimize Dynamic Allocation:**
- I avoid `malloc/free` in long-lived tasks and steady-state operation
- Use dynamic allocation only during initialization phase for one-time setup
- Prefer static allocation with compile-time bounds checking
- Stack-allocate temporary buffers in function scope when sizes are known

**2. Fixed-Size Memory Pools:**
When dynamic behavior is needed, I use memory pools:
```c
// FreeRTOS example
#define POOL_BLOCK_SIZE 256
#define POOL_NUM_BLOCKS 16
static uint8_t memory_pool[POOL_BLOCK_SIZE * POOL_NUM_BLOCKS];
static StaticSemaphore_t pool_mutex;

void* pool_alloc(size_t size) {
    if (size > POOL_BLOCK_SIZE) return NULL;
    // Allocate from fixed-size blocks with deterministic time
    // Return block to pool after use
}
```

**3. Stack Management:**
- Size stacks based on measured high-water marks using FreeRTOS `uxTaskGetStackHighWaterMark()`
- Add 20-30% margin for safety
- Enable stack overflow detection hooks in debug builds:
```c
void vApplicationStackOverflowHook(TaskHandle_t xTask, char *pcTaskName) {
    // Log overflow, halt system in debug, reset in production
    log_fatal("Stack overflow in task: %s", pcTaskName);
    trigger_controlled_reset();
}
```

**4. Buffer Management:**
- Use fixed-size ring buffers for hot paths (I/O, telemetry, logging)
- Implement explicit bounds checking before buffer access
- Define clear ownership rules (single-writer, single-reader patterns)

**C++ Specific Practices:**

**1. RAII for Resource Management:**
```cpp
class SpiTransaction {
    SPI_HandleTypeDef* hspi_;
public:
    SpiTransaction(SPI_HandleTypeDef* hspi) : hspi_(hspi) {
        HAL_SPI_Acquire(hspi_);
    }
    ~SpiTransaction() {
        HAL_SPI_Release(hspi_);
    }
    // Deleted copy, move only
    SpiTransaction(const SpiTransaction&) = delete;
};
```

**2. Avoid Exceptions and RTTI:**
- Compile with `-fno-exceptions -fno-rtti` for code size
- Use error return codes or `std::optional` (C++17)
- Keep interfaces simple with explicit error handling

**Performance Optimization:**

**1. Profiling-Driven Optimization:**
I always measure before optimizing:
- **ISR timing:** Use GPIO toggle + oscilloscope to measure ISR duration
- **Task execution time:** Instrument with cycle counters (DWT_CYCCNT on ARM)
- **CPU utilization:** Use FreeRTOS `vTaskGetRunTimeStats()`
- **Lock contention:** Add instrumentation to track mutex wait times

**2. Zero-Copy Buffers:**
```c
// Avoid
uint8_t temp_buffer[512];
memcpy(temp_buffer, dma_buffer, size);  // Unnecessary copy
process_data(temp_buffer, size);

// Prefer
process_data(dma_buffer, size);  // Direct access, zero-copy
```

**3. Reduce ISR Work:**
- Keep ISRs under 50μs execution time
- Defer heavy processing to worker threads
- Use DMA for bulk data transfers
```c
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi) {
    // Fast: Just signal task and return
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    xTaskNotifyFromISR(sensor_task_handle, 
                       SENSOR_DATA_READY, 
                       eSetBits, 
                       &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
```

**4. Logging Overhead:**
- Use log levels and disable verbose logs in production
- Implement circular log buffer to avoid blocking
- Move formatting to low-priority thread:
```c
// Bad: Formatting in ISR or high-priority task
printf("Sensor: %d, Timestamp: %lu\n", value, timestamp);

// Good: Defer formatting
log_enqueue(LOG_INFO, value, timestamp);  // Fast enqueue
// Low-priority task formats and outputs
```

**Observability Tools:**

**1. Stack Watermarking:**
```c
void monitor_stack_usage(void) {
    UBaseType_t watermark = uxTaskGetStackHighWaterMark(NULL);
    if (watermark < MIN_SAFE_MARGIN) {
        log_warning("Stack margin low: %u bytes", watermark);
    }
}
```

**2. Heap Usage Tracking:**
```c
void monitor_heap_fragmentation(void) {
    size_t free_heap = xPortGetFreeHeapSize();
    size_t min_ever_free = xPortGetMinimumEverFreeHeapSize();
    
    log_info("Heap: %u free, min ever: %u", free_heap, min_ever_free);
}
```

**3. Watchdog Strategy:**
- Use independent hardware watchdog (IWDG on STM32)
- Software watchdog in FreeRTOS for per-task monitoring
- Staged recovery: warning → safe mode → reset

**When Dynamic Allocation is Acceptable:**

1. **System Initialization:** One-time allocations during boot
2. **Variable-Sized Data:** Network packets with unpredictable sizes
3. **Resource-Rich Systems:** Embedded Linux with MMU/MPU protection
4. **Fixed-Block Pools:** Custom allocators that eliminate fragmentation

**Preventing Fragmentation:**
- Allocate during initialization only
- Use memory pools with fixed-size blocks
- Reuse buffers instead of free/alloc cycles
- Align memory to word boundaries
- Profile heap usage to identify fragmentation hotspots

**Key Takeaway:**  
My philosophy is **determinism first, optimization second**. By making memory behavior predictable and visible through instrumentation, I can quickly identify and fix issues before they reach production.

### Q: Explain volatile, atomic, and when you use them.

**Answer:**

**Volatile Keyword:**

`volatile` tells the compiler that a variable can change outside the normal program flow, preventing certain optimizations.

**When to Use Volatile:**
1. **Hardware Registers (Memory-Mapped I/O):**
```c
// STM32 GPIO register access
volatile uint32_t *GPIOA_ODR = (volatile uint32_t*)0x40020014;
*GPIOA_ODR |= (1 << 5);  // Set PA5 high
```

2. **Variables Modified by ISRs:**
```c
volatile uint32_t isr_event_count = 0;

void EXTI0_IRQHandler(void) {
    isr_event_count++;  // Modified in ISR
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_0);
}

// Main code reads count
void main_task(void) {
    uint32_t prev_count = isr_event_count;
    // ...
}
```

**What Volatile Does NOT Do:**
- ❌ Does NOT provide atomicity (multiple instructions can be interrupted)
- ❌ Does NOT provide memory barriers or ordering guarantees
- ❌ Does NOT make operations thread-safe

**Example of Volatile Pitfall:**
```c
volatile uint32_t counter = 0;

// Thread A (or ISR)
counter++;  // NOT atomic! On ARM Cortex-M:
            // 1. LDR r0, [counter]
            // 2. ADD r0, r0, #1     <- Can be interrupted here!
            // 3. STR r0, [counter]

// Thread B
counter++;  // Race condition! Lost updates possible
```

**Atomic Operations:**

For true thread-safety, I use atomics when:
1. Sharing simple data between ISRs and tasks
2. Lock-free algorithms for performance
3. Reading/writing flags or counters from multiple contexts

**C11 Atomics Example:**
```c
#include <stdatomic.h>

atomic_uint event_count = ATOMIC_VAR_INIT(0);

void ISR_Handler(void) {
    // Atomic increment, no race condition
    atomic_fetch_add_explicit(&event_count, 1, memory_order_relaxed);
}

void worker_task(void) {
    // Atomic read and clear
    uint32_t count = atomic_exchange_explicit(&event_count, 0, memory_order_acquire);
    process_events(count);
}
```

**C++ std::atomic:**
```cpp
#include <atomic>

std::atomic<uint32_t> packet_count{0};

void increment_from_isr() {
    packet_count.fetch_add(1, std::memory_order_relaxed);
}

uint32_t read_and_clear() {
    return packet_count.exchange(0, std::memory_order_acquire);
}
```

**Memory Ordering:**
- `memory_order_relaxed`: No synchronization, only atomicity
- `memory_order_acquire`: For loads, ensures subsequent operations see correct data
- `memory_order_release`: For stores, ensures previous operations complete first
- `memory_order_seq_cst`: Full sequential consistency (default, safest but slowest)

**When Atomics Are NOT Available:**

On platforms without atomic support, use critical sections:

**FreeRTOS:**
```c
uint32_t event_count = 0;

void ISR_Handler(void) {
    taskENTER_CRITICAL_FROM_ISR();
    event_count++;
    taskEXIT_CRITICAL_FROM_ISR();
}

void worker_task(void) {
    taskENTER_CRITICAL();
    uint32_t count = event_count;
    event_count = 0;
    taskEXIT_CRITICAL();
}
```

**ARM Cortex-M LDREX/STREX:**
```c
uint32_t atomic_increment(volatile uint32_t *ptr) {
    uint32_t val, res;
    do {
        val = __LDREXW(ptr);     // Load exclusive
        res = __STREXW(val + 1, ptr);  // Store exclusive
    } while (res != 0);          // Retry if interrupted
    return val + 1;
}
```

**Practical ISR Strategy:**

My preferred approach for ISR/task communication:

```c
// Best: Signal via RTOS primitive (no shared data)
static TaskHandle_t worker_task_handle;

void SPI_IRQHandler(void) {
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    
    // Just signal task, no shared variables
    xTaskNotifyFromISR(worker_task_handle, 
                       0x01, 
                       eSetBits, 
                       &xHigherPriorityTaskWoken);
    
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void worker_task(void *params) {
    while (1) {
        // Block until signaled
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        
        // Process data (no race conditions)
        process_spi_data();
    }
}
```

**Example of Bug Caused by Volatile Misuse:**

**Scenario:** Multi-byte counter shared between ISR and main task

```c
// WRONG: Volatile does not provide atomicity for multi-byte values!
volatile uint32_t timestamp_ms = 0;

void SysTick_Handler(void) {
    timestamp_ms++;  // Increment in ISR
}

void main_task(void) {
    uint32_t start_time = timestamp_ms;  // Race condition!
    // On 8-bit or 16-bit systems, this is multiple load instructions
    // Can read partially updated value (torn read)
}
```

**Fix:**
```c
// CORRECT: Use atomic or critical section
atomic_uint timestamp_ms = ATOMIC_VAR_INIT(0);

void SysTick_Handler(void) {
    atomic_fetch_add_explicit(&timestamp_ms, 1, memory_order_relaxed);
}

void main_task(void) {
    uint32_t start_time = atomic_load_explicit(&timestamp_ms, memory_order_relaxed);
    // Safe, guaranteed atomic read
}
```

**Summary Table:**

| Use Case | Solution | Reason |
|----------|----------|--------|
| Hardware register access | `volatile` | Prevents compiler optimization |
| ISR flag (single bit) | `volatile` + critical section | Simple flag with short critical section |
| ISR counter (increment) | Atomics or critical section | Requires atomic read-modify-write |
| Multi-byte data from ISR | RTOS primitives (queues/notifications) | Safer than shared memory |
| Lock-free algorithms | Atomics with memory ordering | Performance-critical path |

**Key Principles:**
1. **Volatile = "don't optimize away"**, not thread-safe
2. **Atomics = thread-safe single operations**
3. **RTOS primitives = preferred for ISR/task communication**
4. **Critical sections = fallback when atomics unavailable**
5. **Always minimize work in ISRs** - signal and defer processing

---

## 3. RTOS: Zephyr or FreeRTOS

### Q: How do you design task/thread architecture for a Wi-Fi plus BLE device?

**Answer:**

Task architecture design requires mapping **data flows, deadlines, and priority assignments** to create a robust, maintainable system.

**Design Principles:**

1. **Separation of Concerns:** Each task has a clear, single responsibility
2. **Bounded Queues:** Explicit backpressure prevents memory exhaustion
3. **Non-blocking Communication:** Tasks communicate via queues/semaphores, not shared mutable state
4. **State Machine Driven:** System behavior modeled as explicit FSM with clear transitions
5. **Instrumented:** Every task reports health metrics and performance counters

**Example Architecture: Wi-Fi + BLE Wearable Device**

**Task Hierarchy:**

```
Priority  Task Name              Period      Purpose
--------  ---------------------  ----------  ----------------------------------
31        Sensor ISR             Event       Hardware interrupt, minimal processing
28        Sensor Sampling        10ms (100Hz) Read sensors, timestamp, enqueue
24        Signal Processing      20ms (50Hz)  Filter, event detection, algorithm
20        BLE Communication      Async       BLE stack, GATT notifications
18        WiFi/MQTT Publisher    1s          Cloud telemetry, command handling
15        Watchdog Monitor       1s          Per-task health checks
10        Logging/Diagnostics    100ms       Structured logging, metrics
5         CLI/Debug Shell        Async       Command line interface
1         Idle/Background        Idle        Power management, cleanup
```

**Data Flow Architecture:**

```
Hardware           Task Boundaries                   Output
--------           ---------------                   ------
IMU Sensor  -->  [Sensor ISR]
                      |
                   DMA Buffer
                      |
                 [Sampling Task]  (timestamp, validate)
                      |
                  Ring Buffer (bounded, 100 samples)
                      |
                 [Processing Task]  (filter, detect events)
                      |
              Message Queue (bounded, 20 messages)
                    /   \
                   /     \
        [BLE Task]       [WiFi Task]
           |                |
    BLE GATT Notify    MQTT Publish
```

**Detailed Task Implementations:**

**1. Sensor Sampling Task (High Priority):**
```c
#define SAMPLE_RATE_HZ      100
#define SAMPLE_PERIOD_MS    (1000 / SAMPLE_RATE_HZ)
#define RING_BUFFER_SIZE    100

static RingBuffer_t sensor_ring_buffer;
static TaskHandle_t sampling_task_handle;

void sensor_sampling_task(void *params) {
    TickType_t last_wake_time = xTaskGetTickCount();
    
    while (1) {
        // Precise periodic execution
        vTaskDelayUntil(&last_wake_time, pdMS_TO_TICKS(SAMPLE_PERIOD_MS));
        
        // Critical: timestamp ASAP
        uint32_t timestamp_us = get_microsecond_timestamp();
        
        // Read sensor (DMA already completed)
        sensor_data_t sample;
        if (sensor_read_dma_buffer(&sample) == OK) {
            sample.timestamp_us = timestamp_us;
            
            // Try to enqueue (non-blocking)
            if (ring_buffer_write(&sensor_ring_buffer, &sample) == BUFFER_FULL) {
                // Handle backpressure
                metrics.sensor_drops++;
                log_warning("Sensor buffer full, dropping sample");
            } else {
                // Signal processing task that data is available
                xTaskNotify(processing_task_handle, 0x01, eSetBits);
            }
        } else {
            metrics.sensor_errors++;
        }
        
        // Monitor timing jitter
        metrics.sampling_jitter_us = calculate_jitter(timestamp_us);
    }
}
```

**2. Processing Task (Medium-High Priority):**
```c
#define EVENT_QUEUE_SIZE  20

static QueueHandle_t event_queue;

void processing_task(void *params) {
    sensor_data_t sample;
    kalman_filter_t filter;
    stride_detector_t detector;
    
    init_kalman_filter(&filter);
    init_stride_detector(&detector);
    
    while (1) {
        // Block until notified by sampling task
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);
        
        // Process all available samples
        while (ring_buffer_read(&sensor_ring_buffer, &sample) == OK) {
            // Apply filtering
            sensor_data_t filtered = kalman_filter_update(&filter, &sample);
            
            // Detect events (stride, fall, activity)
            event_t event;
            if (stride_detect_update(&detector, &filtered, &event)) {
                // Try to enqueue event (with backpressure handling)
                if (xQueueSend(event_queue, &event, 0) != pdTRUE) {
                    metrics.event_drops++;
                    log_warning("Event queue full, dropping event");
                }
            }
        }
        
        // Update performance metrics
        metrics.processing_cpu_us = get_task_runtime_us();
    }
}
```

**3. BLE Communication Task (Medium Priority):**
```c
typedef enum {
    BLE_STATE_DISCONNECTED,
    BLE_STATE_ADVERTISING,
    BLE_STATE_CONNECTED,
    BLE_STATE_ERROR
} ble_state_t;

static ble_state_t ble_state = BLE_STATE_DISCONNECTED;
static uint16_t connection_handle = INVALID_HANDLE;

void ble_task(void *params) {
    event_t event;
    
    while (1) {
        // Non-blocking dequeue with timeout
        if (xQueueReceive(event_queue, &event, pdMS_TO_TICKS(100)) == pdTRUE) {
            
            if (ble_state == BLE_STATE_CONNECTED) {
                // Send GATT notification
                uint8_t data[20];
                size_t len = serialize_event(&event, data, sizeof(data));
                
                if (ble_send_notification(connection_handle, data, len) != OK) {
                    metrics.ble_send_errors++;
                    // Don't drop event, try again later
                    xQueueSendToFront(event_queue, &event, 0);
                }
            } else {
                // Not connected, drop events (or buffer for later)
                metrics.events_dropped_no_connection++;
            }
        }
        
        // Handle BLE state machine
        ble_state_machine_update();
    }
}

void ble_state_machine_update(void) {
    switch (ble_state) {
        case BLE_STATE_DISCONNECTED:
            // Start advertising
            ble_start_advertising();
            ble_state = BLE_STATE_ADVERTISING;
            break;
            
        case BLE_STATE_ADVERTISING:
            // Wait for connection (handled by BLE stack callback)
            break;
            
        case BLE_STATE_CONNECTED:
            // Monitor connection health
            if (connection_health_check() == FAILED) {
                ble_disconnect();
                ble_state = BLE_STATE_DISCONNECTED;
            }
            break;
            
        case BLE_STATE_ERROR:
            // Recovery: reset BLE stack
            ble_reset();
            ble_state = BLE_STATE_DISCONNECTED;
            break;
    }
}
```

**4. WiFi/MQTT Task (Medium Priority):**
```c
typedef enum {
    WIFI_STATE_INIT,
    WIFI_STATE_CONNECTING,
    WIFI_STATE_CONNECTED,
    WIFI_STATE_MQTT_CONNECTING,
    WIFI_STATE_MQTT_CONNECTED,
    WIFI_STATE_ERROR
} wifi_state_t;

static wifi_state_t wifi_state = WIFI_STATE_INIT;
static uint32_t reconnect_delay_ms = 100;  // Exponential backoff

void wifi_mqtt_task(void *params) {
    TickType_t last_publish = xTaskGetTickCount();
    
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(100));  // 10 Hz update rate
        
        // State machine with recovery
        switch (wifi_state) {
            case WIFI_STATE_INIT:
                if (wifi_connect(SSID, PASSWORD) == OK) {
                    wifi_state = WIFI_STATE_CONNECTING;
                    reconnect_delay_ms = 100;  // Reset backoff
                }
                break;
                
            case WIFI_STATE_CONNECTING:
                if (wifi_is_connected()) {
                    log_info("WiFi connected, IP: %s", get_ip_address());
                    wifi_state = WIFI_STATE_CONNECTED;
                } else if (timeout_expired()) {
                    log_error("WiFi connection timeout");
                    wifi_state = WIFI_STATE_ERROR;
                }
                break;
                
            case WIFI_STATE_CONNECTED:
                // Sync time via NTP (required for TLS)
                if (sync_time_ntp() == OK) {
                    mqtt_init(BROKER_URL, CLIENT_ID);
                    wifi_state = WIFI_STATE_MQTT_CONNECTING;
                }
                break;
                
            case WIFI_STATE_MQTT_CONNECTING:
                if (mqtt_connect_tls(cert_chain, client_cert, private_key) == OK) {
                    log_info("MQTT connected");
                    wifi_state = WIFI_STATE_MQTT_CONNECTED;
                    reconnect_delay_ms = 100;  // Reset backoff
                } else {
                    wifi_state = WIFI_STATE_ERROR;
                }
                break;
                
            case WIFI_STATE_MQTT_CONNECTED:
                // Publish telemetry periodically
                if (xTaskGetTickCount() - last_publish > pdMS_TO_TICKS(1000)) {
                    publish_telemetry();
                    last_publish = xTaskGetTickCount();
                }
                
                // Handle commands
                handle_mqtt_commands();
                
                // Monitor connection health
                if (!mqtt_is_connected()) {
                    log_warning("MQTT disconnected");
                    wifi_state = WIFI_STATE_ERROR;
                }
                break;
                
            case WIFI_STATE_ERROR:
                // Exponential backoff with jitter
                vTaskDelay(pdMS_TO_TICKS(reconnect_delay_ms));
                reconnect_delay_ms = MIN(reconnect_delay_ms * 2, 5000);
                reconnect_delay_ms += (rand() % 100);  // Jitter
                
                metrics.wifi_reconnect_attempts++;
                wifi_state = WIFI_STATE_INIT;
                break;
        }
    }
}
```

**5. Watchdog Monitor Task (Low-Medium Priority):**
```c
#define WATCHDOG_TIMEOUT_MS     5000
#define TASK_CHECK_INTERVAL_MS  1000

typedef struct {
    TaskHandle_t handle;
    const char *name;
    uint32_t last_checkin_ms;
    uint32_t max_allowed_silence_ms;
} task_monitor_t;

static task_monitor_t monitored_tasks[] = {
    {sampling_task_handle, "Sensor", 0, 500},
    {processing_task_handle, "Processing", 0, 1000},
    {ble_task_handle, "BLE", 0, 2000},
    {wifi_task_handle, "WiFi", 0, 5000},
};

void watchdog_task(void *params) {
    hardware_watchdog_init(WATCHDOG_TIMEOUT_MS);
    
    while (1) {
        vTaskDelay(pdMS_TO_TICKS(TASK_CHECK_INTERVAL_MS));
        
        // Refresh hardware watchdog
        hardware_watchdog_refresh();
        
        // Check each task
        uint32_t now = xTaskGetTickCount();
        for (int i = 0; i < ARRAY_SIZE(monitored_tasks); i++) {
            uint32_t silence_ms = (now - monitored_tasks[i].last_checkin_ms) * portTICK_PERIOD_MS;
            
            if (silence_ms > monitored_tasks[i].max_allowed_silence_ms) {
                log_error("Task %s unresponsive for %lu ms", 
                         monitored_tasks[i].name, silence_ms);
                
                // Take recovery action
                trigger_system_recovery();
            }
        }
        
        // Publish health metrics
        publish_system_health();
    }
}

// Each task calls this periodically
void task_checkin(void) {
    TaskHandle_t handle = xTaskGetCurrentTaskHandle();
    
    for (int i = 0; i < ARRAY_SIZE(monitored_tasks); i++) {
        if (monitored_tasks[i].handle == handle) {
            monitored_tasks[i].last_checkin_ms = xTaskGetTickCount();
            break;
        }
    }
}
```

**Choosing Task Priorities:**

I use **Rate Monotonic Analysis (RMA)** as a starting point:
- Shortest period (highest frequency) → Highest priority
- Longer period (lower frequency) → Lower priority

**Priority Assignment Strategy:**

```
High Priority (25-31):
- ISR handlers and critical timing tasks
- Sensor sampling with tight deadlines
- Tasks that must respond immediately to hardware events

Medium Priority (15-24):
- Application logic (processing, algorithms)
- Protocol stacks (BLE, TCP/IP)
- Tasks with soft real-time requirements

Low Priority (5-14):
- Background services (logging, health monitoring)
- Non-critical diagnostics
- Command-line interface

Idle Priority (1):
- Power management
- Memory cleanup
```

**Preventing Network Code from Blocking Real-Time Tasks:**

**1. Task Separation:**
- Network tasks run at lower priority than real-time sampling
- RTOS scheduler preempts network code when high-priority task is ready

**2. Non-Blocking I/O:**
```c
// Bad: Blocking socket call
int bytes = recv(socket, buffer, size, 0);  // Can block indefinitely!

// Good: Non-blocking with timeout
fcntl(socket, F_SETFL, O_NONBLOCK);
int bytes = recv(socket, buffer, size, 0);
if (bytes < 0 && errno == EWOULDBLOCK) {
    // No data available, yield CPU
}
```

**3. Async/Await Pattern (Zephyr):**
```c
// Rust-style async in Zephyr
async fn send_mqtt_data(data: &[u8]) -> Result<(), Error> {
    let socket = TcpSocket::connect(broker_addr).await?;
    socket.write_all(data).await?;
    Ok(())
}
```

**4. DMA Offloading:**
```c
// Use DMA for network transfers to free CPU
esp_err_t ret = spi_device_queue_trans(spi, &trans, portMAX_DELAY);
// DMA transfers in background, CPU free for real-time tasks
```

**5. Resource Isolation:**
- Dedicated SPI bus for sensor (no contention with network)
- Separate I2C bus for sensor vs. peripheral communication
- Non-blocking mutexes with short critical sections

**Bounded Queues and Backpressure:**

**Explicit Backpressure Handling:**
```c
// Queue with finite size
#define SENSOR_QUEUE_SIZE 100
static QueueHandle_t sensor_queue;

// Producer (high-priority task)
void sensor_task(void) {
    sensor_data_t data;
    read_sensor(&data);
    
    if (xQueueSend(sensor_queue, &data, 0) != pdTRUE) {
        // Queue full - explicit backpressure decision
        metrics.drops_due_to_backpressure++;
        
        // Option 1: Drop oldest (decimation)
        // Option 2: Drop current sample
        // Option 3: Signal upstream to slow down
    }
}

// Consumer (lower-priority task)
void processing_task(void) {
    sensor_data_t data;
    
    // Non-blocking receive with timeout
    if (xQueueReceive(sensor_queue, &data, pdMS_TO_TICKS(100)) == pdTRUE) {
        process_data(&data);
    }
}
```

**Key Architectural Benefits:**

1. **Testability:** Each task can be tested independently with mock inputs
2. **Observability:** Instrumented at every stage with metrics
3. **Graceful Degradation:** Backpressure prevents cascading failures
4. **Recovery:** Explicit state machines enable controlled recovery
5. **Maintainability:** Clear boundaries and responsibilities

**Summary:**

My task architecture philosophy:
- **Separate concerns** with single-responsibility tasks
- **Prioritize by deadline**, not by importance
- **Use queues**, not shared mutable state
- **Implement backpressure** explicitly to prevent memory exhaustion
- **Model behavior** as explicit state machines
- **Instrument everything** for field diagnosis

### Q: What causes priority inversion and how do you handle it?

**Answer:**

**Priority Inversion Definition:**

Priority inversion occurs when a high-priority task is blocked waiting for a resource held by a low-priority task, while a medium-priority task preempts the low-priority task, causing the high-priority task to wait longer than if it had run before the medium-priority task.

**Classic Example:**

```
Tasks:
- Task H (High Priority 30): Needs Mutex M
- Task M (Medium Priority 20): Does NOT need Mutex M
- Task L (Low Priority 10): Holds Mutex M

Timeline:
1. Task L acquires Mutex M
2. Task H preempts Task L, tries to acquire Mutex M → BLOCKED
3. Task M preempts Task L (higher priority than L)
4. Task M runs for a long time
5. Finally Task L resumes and releases Mutex M
6. Task H can now acquire Mutex M

Result: Task H (highest priority) waited for Task M (medium priority) to complete!
```

**Root Causes:**

1. **Resource Contention:** Multiple tasks share mutexes/semaphores
2. **Unbounded Blocking:** No limit on how long low-priority task holds resource
3. **Preemption:** Medium-priority tasks prevent low-priority task from releasing resource

**Solutions:**

**1. Priority Inheritance (Preferred):**

When a high-priority task blocks on a mutex held by a low-priority task, temporarily boost the low-priority task's priority to match the high-priority task.

**FreeRTOS Example:**
```c
// Create mutex with priority inheritance
static SemaphoreHandle_t mutex;
static StaticSemaphore_t mutex_buffer;

void init_mutex(void) {
    // FreeRTOS automatically implements priority inheritance for mutexes
    mutex = xSemaphoreCreateMutexStatic(&mutex_buffer);
}

void low_priority_task(void) {
    xSemaphoreTake(mutex, portMAX_DELAY);
    // If high-priority task tries to take mutex, THIS task's
    // priority temporarily raised to match high-priority task
    
    critical_section_work();
    
    xSemaphoreGive(mutex);
    // Priority restored to original
}
```

**Zephyr Example:**
```c
static struct k_mutex my_mutex;

k_mutex_init(&my_mutex);  // Priority inheritance enabled by default

void task_low_priority(void) {
    k_mutex_lock(&my_mutex, K_FOREVER);
    // Priority inheritance automatic
    critical_section();
    k_mutex_unlock(&my_mutex);
}
```

**2. Priority Ceiling Protocol:**

Assign each resource a priority ceiling equal to the highest priority of any task that uses it. Any task holding the resource runs at that ceiling priority.

```c
// Manual implementation
#define SENSOR_MUTEX_CEILING_PRIORITY  30

void low_priority_task(void) {
    UBaseType_t original_priority = uxTaskPriorityGet(NULL);
    
    // Raise priority to ceiling before acquiring mutex
    vTaskPrioritySet(NULL, SENSOR_MUTEX_CEILING_PRIORITY);
    
    taskENTER_CRITICAL();
    // Critical section
    taskEXIT_CRITICAL();
    
    // Restore original priority
    vTaskPrioritySet(NULL, original_priority);
}
```

**3. Architectural Solutions (Most Effective):**

**A. Message Passing (Preferred over Mutexes):**
```c
// Instead of shared state with mutex
static sensor_data_t shared_sensor_data;
static SemaphoreHandle_t sensor_mutex;

void bad_design_sensor_task(void) {
    xSemaphoreTake(sensor_mutex, portMAX_DELAY);
    shared_sensor_data = read_sensor();
    xSemaphoreGive(sensor_mutex);
}

void bad_design_processing_task(void) {
    xSemaphoreTake(sensor_mutex, portMAX_DELAY);  // Priority inversion risk!
    process(shared_sensor_data);
    xSemaphoreGive(sensor_mutex);
}

// BETTER: Message passing, no shared mutex
static QueueHandle_t sensor_queue;

void good_design_sensor_task(void) {
    sensor_data_t data = read_sensor();
    xQueueSend(sensor_queue, &data, 0);  // No blocking, no mutex
}

void good_design_processing_task(void) {
    sensor_data_t data;
    xQueueReceive(sensor_queue, &data, portMAX_DELAY);
    process(data);
}
```

**B. Split Locks (Reduce Contention):**
```c
// Bad: Single coarse-grained lock
static SemaphoreHandle_t device_mutex;
static device_state_t device;

void update_config(void) {
    xSemaphoreTake(device_mutex, portMAX_DELAY);  // Locks everything
    device.config = new_config;
    xSemaphoreGive(device_mutex);
}

void update_telemetry(void) {
    xSemaphoreTake(device_mutex, portMAX_DELAY);  // Contention!
    device.telemetry = read_telemetry();
    xSemaphoreGive(device_mutex);
}

// Good: Fine-grained locks
static SemaphoreHandle_t config_mutex;
static SemaphoreHandle_t telemetry_mutex;

void update_config(void) {
    xSemaphoreTake(config_mutex, portMAX_DELAY);  // Independent
    device.config = new_config;
    xSemaphoreGive(config_mutex);
}

void update_telemetry(void) {
    xSemaphoreTake(telemetry_mutex, portMAX_DELAY);  // No contention
    device.telemetry = read_telemetry();
    xSemaphoreGive(telemetry_mutex);
}
```

**C. Keep Critical Sections Short:**
```c
// Bad: Long critical section
void process_sensor_data(void) {
    xSemaphoreTake(sensor_mutex, portMAX_DELAY);
    
    sensor_data_t raw = read_sensor();        // I/O inside lock!
    sensor_data_t filtered = apply_filter(raw);  // Heavy compute inside lock!
    log_data(filtered);                       // Logging inside lock!
    
    xSemaphoreGive(sensor_mutex);
}

// Good: Minimal critical section
void process_sensor_data(void) {
    sensor_data_t raw;
    
    xSemaphoreTake(sensor_mutex, portMAX_DELAY);
    raw = read_sensor_register();  // Fast: Just copy register value
    xSemaphoreGive(sensor_mutex);
    
    // Heavy work OUTSIDE lock
    sensor_data_t filtered = apply_filter(raw);
    log_data(filtered);
}
```

**Diagnosis Tools:**

**1. FreeRTOS Tracing:**
```c
#define configUSE_TRACE_FACILITY  1
#define configUSE_STATS_FORMATTING_FUNCTIONS  1

void diagnose_priority_inversion(void) {
    char stats_buffer[1024];
    
    // Get task statistics
    vTaskGetRunTimeStats(stats_buffer);
    log_info("Task stats:\n%s", stats_buffer);
    
    // Check for blocked tasks
    TaskStatus_t task_status[10];
    UBaseType_t num_tasks = uxTaskGetSystemState(task_status, 10, NULL);
    
    for (int i = 0; i < num_tasks; i++) {
        if (task_status[i].eCurrentState == eBlocked) {
            log_warning("Task %s blocked (priority %d)", 
                       task_status[i].pcTaskName,
                       task_status[i].uxCurrentPriority);
        }
    }
}
```

**2. Instrumented Mutex:**
```c
typedef struct {
    SemaphoreHandle_t semaphore;
    const char *name;
    uint32_t max_wait_time_ms;
    uint32_t total_wait_time_ms;
    uint32_t acquisition_count;
} instrumented_mutex_t;

bool instrumented_mutex_take(instrumented_mutex_t *mutex, uint32_t timeout_ms) {
    uint32_t start_time = xTaskGetTickCount();
    
    bool acquired = (xSemaphoreTake(mutex->semaphore, pdMS_TO_TICKS(timeout_ms)) == pdTRUE);
    
    if (acquired) {
        uint32_t wait_time_ms = (xTaskGetTickCount() - start_time) * portTICK_PERIOD_MS;
        
        mutex->total_wait_time_ms += wait_time_ms;
        mutex->acquisition_count++;
        
        if (wait_time_ms > mutex->max_wait_time_ms) {
            mutex->max_wait_time_ms = wait_time_ms;
            log_warning("Mutex %s: long wait %lu ms", mutex->name, wait_time_ms);
        }
    }
    
    return acquired;
}
```

**3. Lock Order Validation (Deadlock Prevention):**
```c
// Define lock hierarchy (acquire in ascending order only)
enum lock_order {
    LOCK_TELEMETRY = 1,
    LOCK_CONFIG = 2,
    LOCK_NETWORK = 3,
};

// Runtime validation
static uint32_t current_lock_order = 0;

void acquire_lock(uint32_t lock_id, SemaphoreHandle_t mutex) {
    if (lock_id <= current_lock_order) {
        log_error("Lock order violation! Current: %lu, Requesting: %lu",
                 current_lock_order, lock_id);
        assert(0);  // Catch during development
    }
    
    xSemaphoreTake(mutex, portMAX_DELAY);
    current_lock_order = lock_id;
}
```

**Real-World Example I Fixed:**

**Scenario:** Smart shoe with sensor sampling at 100Hz and BLE notifications. High-priority sensor task shared a mutex with low-priority logging task. When logging was active, sensor sampling experienced jitter.

**Root Cause:**
```c
// Shared resource
static SemaphoreHandle_t log_buffer_mutex;

// High-priority sensor task
void sensor_task(void) {
    sensor_data_t data = read_sensor();
    
    xSemaphoreTake(log_buffer_mutex, portMAX_DELAY);  // BLOCKED HERE!
    log_sensor_data(data);
    xSemaphoreGive(log_buffer_mutex);
}

// Low-priority logging task (flushing to flash)
void logging_task(void) {
    xSemaphoreTake(log_buffer_mutex, portMAX_DELAY);
    flush_logs_to_flash();  // Slow! 10-20ms
    xSemaphoreGive(log_buffer_mutex);
}
```

**Solution:** Restructured to use lock-free ring buffer with deferred formatting:
```c
// Lock-free ring buffer for sensor logging
static lock_free_ring_buffer_t sensor_log_buffer;

// High-priority sensor task (NO LOCKING)
void sensor_task(void) {
    sensor_data_t data = read_sensor();
    
    // Fast: just enqueue raw data, no formatting
    if (!ring_buffer_write(&sensor_log_buffer, &data)) {
        metrics.log_drops++;
    }
}

// Low-priority logging task (independent)
void logging_task(void) {
    sensor_data_t data;
    
    while (ring_buffer_read(&sensor_log_buffer, &data)) {
        // Format and write OUTSIDE critical path
        char formatted[128];
        snprintf(formatted, sizeof(formatted), "Sensor: %d,%d,%d", 
                data.x, data.y, data.z);
        write_to_flash(formatted);
    }
}
```

**Measured Impact:**
- Before: Sensor jitter up to 8ms (80 samples at 100Hz)
- After: Sensor jitter <100μs (deterministic)
- Priority inversion eliminated

**Summary:**

**Best Practices to Avoid Priority Inversion:**
1. ✅ **Prefer message passing** over shared mutable state
2. ✅ **Use mutexes with priority inheritance** (FreeRTOS/Zephyr default)
3. ✅ **Keep critical sections minimal** (<100μs)
4. ✅ **Separate time-critical and non-critical code** into different tasks
5. ✅ **Split coarse-grained locks** into fine-grained locks
6. ✅ **Instrument locks** to measure wait times
7. ✅ **Use lock-free data structures** where appropriate

**Diagnosis Checklist:**
- Enable RTOS tracing and analyze blocked tasks
- Measure mutex acquisition times
- Review architecture: are locks really necessary?
- Consider replacing locks with queues/notifications

---

## 4. Low-Level Interfaces and Bring-up

### Q: Walk me through bringing up an I2C sensor that sometimes returns garbage values.

**Answer:**

Intermittent garbage from I2C sensors is a common issue. My systematic approach covers **hardware validation, firmware verification, and runtime resilience**.

**Step 1: Electrical and Signal Integrity Validation**

**A. Check Pull-Up Resistors:**
```
Typical I2C requires 4.7kΩ pull-ups on SDA and SCL
- Too weak (>10kΩ): Slow rise times, signal integrity issues
- Too strong (<1kΩ): Excessive current, may damage sensor
- Multiple devices: Effective resistance = 1/(1/R1 + 1/R2 + ...)

Measurement: Use oscilloscope to check rise time
- Standard mode (100 kHz): Rise time < 1μs
- Fast mode (400 kHz): Rise time < 300ns
```

**B. Verify Bus Speed:**
```c
// Start conservatively
i2c_config_t config = {
    .mode = I2C_MODE_MASTER,
    .sda_io_num = GPIO_SDA,
    .scl_io_num = GPIO_SCL,
    .sda_pullup_en = GPIO_PULLUP_ENABLE,
    .scl_pullup_en = GPIO_PULLUP_ENABLE,
    .master.clk_speed = 100000,  // Start at 100 kHz standard mode
};
i2c_param_config(I2C_NUM_0, &config);

// After validation, try faster speeds
// config.master.clk_speed = 400000;  // Fast mode
```

**C. Scope/Logic Analyzer Analysis:**

Using a logic analyzer, check for:
1. **ACK/NACK conditions:** Every transmitted byte should receive ACK (0) from slave
2. **Clock stretching:** Sensor pulling SCL low to request more time
3. **Bus contention:** Multiple drivers fighting for control
4. **Glitches:** Short spikes indicating noise or capacitance issues

```
Logic analyzer capture:
START | ADDR(0x68) + W | ACK | REG(0x3B) | ACK | REPEATED_START | ADDR(0x68) + R | ACK | DATA | NAK | STOP
  ↓         ↓            ↓        ↓         ↓          ↓              ↓              ↓     ↓     ↓     ↓
Valid    Device Addr    OK    Register    OK     Switch to        Device Addr     OK   Read  Done  End
         Acknowledged        to read             Read Mode       Acknowledged
```

**D. Power Supply Noise:**
```c
// Add delays after power-on and reset
void sensor_power_on_sequence(void) {
    gpio_set_level(SENSOR_POWER_EN, 1);
    vTaskDelay(pdMS_TO_TICKS(10));  // Wait for power stabilization
    
    gpio_set_level(SENSOR_RESET, 0);
    vTaskDelay(pdMS_TO_TICKS(1));
    gpio_set_level(SENSOR_RESET, 1);
    vTaskDelay(pdMS_TO_TICKS(100));  // Wait for sensor boot (per datasheet)
}
```

Use multimeter to measure:
- VDD voltage (should be stable, within ±5% of nominal)
- Current spikes during I2C transactions (indicates power supply issues)
- Ripple on VDD (<50mV)

**Step 2: Firmware Validation**

**A. Verify Device Presence (WHO_AM_I Check):**
```c
#define ICM42688_I2C_ADDR       0x68
#define ICM42688_WHO_AM_I_REG   0x75
#define ICM42688_WHO_AM_I_VAL   0x47

esp_err_t icm42688_init(void) {
    uint8_t who_am_i;
    
    // Read WHO_AM_I register
    esp_err_t ret = i2c_master_read_reg(ICM42688_I2C_ADDR, 
                                        ICM42688_WHO_AM_I_REG, 
                                        &who_am_i, 
                                        1);
    
    if (ret != ESP_OK) {
        log_error("I2C read failed: %s", esp_err_to_name(ret));
        return ret;
    }
    
    if (who_am_i != ICM42688_WHO_AM_I_VAL) {
        log_error("WHO_AM_I mismatch: expected 0x%02X, got 0x%02X", 
                 ICM42688_WHO_AM_I_VAL, who_am_i);
        return ESP_ERR_NOT_FOUND;
    }
    
    log_info("ICM-42688 detected (WHO_AM_I = 0x%02X)", who_am_i);
    return ESP_OK;
}
```

**B. Validate Register Map and Endianness:**
```c
// Common error: incorrect endianness
// ICM-42688 stores 16-bit values in big-endian (MSB first)

int16_t icm42688_read_accel_x(void) {
    uint8_t data[2];
    
    i2c_master_read_reg(ICM42688_I2C_ADDR, ICM42688_ACCEL_XOUT_H, data, 2);
    
    // WRONG: Little-endian interpretation
    // int16_t accel_x = (data[1] << 8) | data[0];  // Garbage!
    
    // CORRECT: Big-endian (MSB first)
    int16_t accel_x_raw = (data[0] << 8) | data[1];
    
    // Apply scaling factor (per datasheet: ±16g range = 2048 LSB/g)
    float accel_x_g = accel_x_raw / 2048.0f;
    
    return accel_x_raw;
}
```

**C. Respect Initialization Sequence:**
```c
// ICM-42688 requires specific init sequence
esp_err_t icm42688_configure(void) {
    // 1. Software reset
    i2c_master_write_reg(ICM42688_I2C_ADDR, ICM42688_REG_DEVICE_CONFIG, 0x01);
    vTaskDelay(pdMS_TO_TICKS(10));  // Wait for reset to complete
    
    // 2. Set power mode (wake up accelerometer and gyro)
    i2c_master_write_reg(ICM42688_I2C_ADDR, ICM42688_REG_PWR_MGMT0, 0x0F);
    vTaskDelay(pdMS_TO_TICKS(1));  // Stabilization delay
    
    // 3. Configure accelerometer: ±16g, ODR 100Hz, LPF enabled
    i2c_master_write_reg(ICM42688_I2C_ADDR, ICM42688_REG_ACCEL_CONFIG0, 0x06);
    
    // 4. Configure gyroscope: ±2000dps, ODR 100Hz
    i2c_master_write_reg(ICM42688_I2C_ADDR, ICM42688_REG_GYRO_CONFIG0, 0x06);
    
    // 5. Verify configuration
    uint8_t accel_config, gyro_config;
    i2c_master_read_reg(ICM42688_I2C_ADDR, ICM42688_REG_ACCEL_CONFIG0, &accel_config, 1);
    i2c_master_read_reg(ICM42688_I2C_ADDR, ICM42688_REG_GYRO_CONFIG0, &gyro_config, 1);
    
    log_info("Config: Accel=0x%02X, Gyro=0x%02X", accel_config, gyro_config);
    
    return ESP_OK;
}
```

**D. Handle Repeated Start Conditions:**
```c
// Many sensors require REPEATED START (not STOP + START)
esp_err_t i2c_master_read_reg(uint8_t dev_addr, uint8_t reg_addr, 
                              uint8_t *data, size_t len) {
    i2c_cmd_handle_t cmd = i2c_cmd_link_create();
    
    // Write phase: Send register address
    i2c_master_start(cmd);
    i2c_master_write_byte(cmd, (dev_addr << 1) | I2C_MASTER_WRITE, true);
    i2c_master_write_byte(cmd, reg_addr, true);
    
    // CRITICAL: Repeated start (not stop!)
    i2c_master_start(cmd);  // REPEATED START
    
    // Read phase
    i2c_master_write_byte(cmd, (dev_addr << 1) | I2C_MASTER_READ, true);
    i2c_master_read(cmd, data, len, I2C_MASTER_LAST_NACK);
    i2c_master_stop(cmd);
    
    esp_err_t ret = i2c_master_cmd_begin(I2C_NUM_0, cmd, pdMS_TO_TICKS(1000));
    i2c_cmd_link_delete(cmd);
    
    return ret;
}
```

**Step 3: Defensive Firmware Strategies**

**A. Range Validation:**
```c
typedef struct {
    int16_t accel_x, accel_y, accel_z;
    int16_t gyro_x, gyro_y, gyro_z;
    bool valid;
} imu_data_t;

imu_data_t icm42688_read_with_validation(void) {
    imu_data_t data;
    uint8_t raw[12];
    
    i2c_master_read_reg(ICM42688_I2C_ADDR, ICM42688_ACCEL_XOUT_H, raw, 12);
    
    // Parse
    data.accel_x = (raw[0] << 8) | raw[1];
    data.accel_y = (raw[2] << 8) | raw[3];
    data.accel_z = (raw[4] << 8) | raw[5];
    data.gyro_x = (raw[6] << 8) | raw[7];
    data.gyro_y = (raw[8] << 8) | raw[9];
    data.gyro_z = (raw[10] << 8) | raw[11];
    
    // Sanity checks (±16g = ±32768 LSB)
    data.valid = true;
    
    // Check for impossible values (all zeros = sensor not ready or failed)
    if (data.accel_x == 0 && data.accel_y == 0 && data.accel_z == 0) {
        log_warning("IMU: All-zero accel reading");
        data.valid = false;
        metrics.imu_zero_readings++;
    }
    
    // Check for saturation (±32767 indicates clipping)
    if (abs(data.accel_x) > 32000 || abs(data.accel_y) > 32000 || abs(data.accel_z) > 32000) {
        log_warning("IMU: Accel saturation detected");
        metrics.imu_saturation++;
        data.valid = false;
    }
    
    // Check for physically impossible values (>16g without impact)
    float accel_magnitude = sqrtf(data.accel_x * data.accel_x + 
                                   data.accel_y * data.accel_y + 
                                   data.accel_z * data.accel_z) / 2048.0f;
    if (accel_magnitude > 20.0f) {  // >20g sustained is unlikely
        log_warning("IMU: Impossible accel magnitude: %.2f g", accel_magnitude);
        metrics.imu_invalid_magnitude++;
        data.valid = false;
    }
    
    return data;
}
```

**B. CRC Validation (if supported):**
```c
// Some sensors (e.g., SHT31, BME680) support CRC
uint8_t calculate_crc8(uint8_t *data, size_t len) {
    uint8_t crc = 0xFF;
    for (size_t i = 0; i < len; i++) {
        crc ^= data[i];
        for (int bit = 8; bit > 0; --bit) {
            if (crc & 0x80) {
                crc = (crc << 1) ^ 0x31;  // Polynomial: x^8 + x^5 + x^4 + 1
            } else {
                crc <<= 1;
            }
        }
    }
    return crc;
}

bool read_sensor_with_crc(uint8_t *data, uint8_t *crc_received) {
    i2c_master_read(I2C_NUM_0, dev_addr, data, 2);
    i2c_master_read(I2C_NUM_0, dev_addr, crc_received, 1);
    
    uint8_t crc_calculated = calculate_crc8(data, 2);
    
    if (crc_calculated != *crc_received) {
        log_error("CRC mismatch: calc=0x%02X, recv=0x%02X", 
                 crc_calculated, *crc_received);
        metrics.crc_errors++;
        return false;
    }
    
    return true;
}
```

**Step 4: Runtime Resilience and Recovery**

**A. Retry Strategy:**
```c
#define MAX_I2C_RETRIES  3
#define RETRY_DELAY_MS   10

esp_err_t i2c_read_with_retry(uint8_t dev_addr, uint8_t reg_addr, 
                              uint8_t *data, size_t len) {
    esp_err_t ret;
    
    for (int attempt = 0; attempt < MAX_I2C_RETRIES; attempt++) {
        ret = i2c_master_read_reg(dev_addr, reg_addr, data, len);
        
        if (ret == ESP_OK) {
            if (attempt > 0) {
                log_info("I2C read succeeded on attempt %d", attempt + 1);
            }
            return ESP_OK;
        }
        
        log_warning("I2C read failed (attempt %d/%d): %s", 
                   attempt + 1, MAX_I2C_RETRIES, esp_err_to_name(ret));
        
        metrics.i2c_retry_count++;
        vTaskDelay(pdMS_TO_TICKS(RETRY_DELAY_MS));
    }
    
    log_error("I2C read failed after %d attempts", MAX_I2C_RETRIES);
    metrics.i2c_failures++;
    return ret;
}
```

**B. Bus Recovery (Clock Wiggling):**
```c
// If I2C bus is stuck (SDA held low by slave), manually toggle SCL
void i2c_bus_recovery(void) {
    log_warning("I2C bus recovery initiated");
    
    // 1. Disable I2C peripheral
    i2c_driver_delete(I2C_NUM_0);
    
    // 2. Configure SCL as GPIO output
    gpio_config_t io_conf = {
        .mode = GPIO_MODE_OUTPUT,
        .pin_bit_mask = (1ULL << GPIO_SCL),
    };
    gpio_config(&io_conf);
    
    // 3. Toggle SCL 9 times to complete any partial byte
    for (int i = 0; i < 9; i++) {
        gpio_set_level(GPIO_SCL, 0);
        vTaskDelay(pdMS_TO_TICKS(1));
        gpio_set_level(GPIO_SCL, 1);
        vTaskDelay(pdMS_TO_TICKS(1));
    }
    
    // 4. Generate STOP condition
    gpio_set_level(GPIO_SDA, 0);
    vTaskDelay(pdMS_TO_TICKS(1));
    gpio_set_level(GPIO_SCL, 1);
    vTaskDelay(pdMS_TO_TICKS(1));
    gpio_set_level(GPIO_SDA, 1);
    
    // 5. Re-initialize I2C peripheral
    i2c_driver_install(I2C_NUM_0, I2C_MODE_MASTER, 0, 0, 0);
    
    log_info("I2C bus recovery completed");
    metrics.i2c_recoveries++;
}
```

**C. Telemetry and Diagnostics:**
```c
typedef struct {
    uint32_t successful_reads;
    uint32_t failed_reads;
    uint32_t retry_count;
    uint32_t crc_errors;
    uint32_t invalid_data_count;
    uint32_t bus_recoveries;
    uint32_t last_error_code;
} i2c_sensor_metrics_t;

void log_i2c_diagnostics(void) {
    log_info("I2C Sensor Metrics:");
    log_info("  Success: %lu, Failures: %lu", 
            metrics.successful_reads, metrics.failed_reads);
    log_info("  Retry rate: %.2f%%", 
            100.0f * metrics.retry_count / (metrics.successful_reads + metrics.failed_reads));
    log_info("  CRC errors: %lu, Invalid data: %lu", 
            metrics.crc_errors, metrics.invalid_data_count);
    log_info("  Bus recoveries: %lu", metrics.bus_recoveries);
    log_info("  Last error: 0x%04X", metrics.last_error_code);
}
```

**Decision Tree for Diagnosis:**

```
Symptom: Garbage values from I2C sensor
│
├─ WHO_AM_I fails?
│  ├─ YES → Check wiring, power, I2C address
│  └─ NO  → Sensor is detected, continue...
│
├─ Logic analyzer shows NACKs?
│  ├─ YES → Incorrect register address or timing violation
│  └─ NO  → Continue...
│
├─ Data always 0x00 or 0xFF?
│  ├─ YES → Check pull-ups, bus contention, or sensor not ready
│  └─ NO  → Continue...
│
├─ Intermittent garbage?
│  ├─ Check signal integrity (scope: rise time, noise, glitches)
│  ├─ Check power supply ripple/noise
│  ├─ Verify timing (delays after reset/power-on)
│  └─ Test with slower I2C clock speed
│
└─ Data out of expected range?
   ├─ Verify endianness (MSB vs LSB first)
   ├─ Check scaling factors from datasheet
   └─ Validate init sequence and configuration registers
```

**Field Logging for Diagnosis:**

```c
void log_i2c_transaction(uint8_t dev_addr, uint8_t reg_addr, 
                        uint8_t *data, size_t len, esp_err_t result) {
    if (result != ESP_OK) {
        // Log failed transactions for later analysis
        char hex_data[64];
        for (size_t i = 0; i < len && i < 16; i++) {
            snprintf(hex_data + i*3, 4, "%02X ", data[i]);
        }
        
        log_error("I2C[0x%02X, 0x%02X]: %s | Data: %s", 
                 dev_addr, reg_addr, esp_err_to_name(result), hex_data);
    }
}
```

**Summary:**

My I2C debugging workflow:
1. ✅ **Hardware validation first:** Pull-ups, signal integrity, power
2. ✅ **Firmware verification:** WHO_AM_I, endianness, init sequence
3. ✅ **Defensive coding:** Range checks, CRC, retry logic
4. ✅ **Recovery mechanisms:** Bus recovery, graceful degradation
5. ✅ **Instrumentation:** Metrics and logging for field diagnosis

This systematic approach typically isolates the root cause within 30 minutes.

### Q: SPI vs I2C: how do you decide which one to use?

**Answer:**

The choice between SPI and I2C depends on **bandwidth requirements, pin availability, robustness, and system-level trade-offs**.

**Quick Comparison Table:**

| Aspect | SPI | I2C |
|--------|-----|-----|
| **Speed** | 10-100 MHz typical | 100-400 kHz (standard/fast mode) |
| **Pins Required** | 4+ (MISO, MOSI, SCK, CS per device) | 2 (SDA, SCL) + pull-ups |
| **Multi-Device** | One CS per device (pin-intensive) | Address-based (up to 127 devices) |
| **Full-Duplex** | Yes | No (half-duplex) |
| **Robustness** | More robust (differential possible) | Sensitive to bus capacitance |
| **Complexity** | Simple, no arbitration | More complex (arbitration, clock stretching) |
| **Typical Use** | High-speed: displays, flash, ADCs | Low-speed: sensors, RTCs, EEPROMs |

**Decision Factors:**

**1. Bandwidth Requirements:**

**Use SPI when:**
- High data rates needed (>1 Mbps)
- Streaming data (IMU at 1 kHz, displays, camera sensors)
- Full-duplex communication required

**Example: ICM-42688 IMU**
```
Configuration:
- Sampling rate: 100 Hz
- Data per sample: 12 bytes (accel + gyro)
- Bandwidth: 100 Hz × 12 bytes × 8 bits = 9.6 kbps

I2C: 100 kHz is sufficient
SPI: Can use 1 MHz (overkill, but faster reads)

Decision: I used SPI at 8 MHz for the ICM-42688 because:
1. DMA support reduced CPU load
2. Sensor supports up to 24 MHz SPI
3. Freed up I2C bus for other sensors
```

**Use I2C when:**
- Low data rates (<100 kbps)
- Infrequent polling (temperature sensor every second)
- Pin count constrained

**Example: MS5637 Pressure Sensor**
```
Configuration:
- Sampling rate: 10 Hz
- Data per sample: 3 bytes (pressure)
- Bandwidth: 10 Hz × 3 bytes × 8 bits = 240 bps

Decision: I2C at 100 kHz is more than adequate
```

**2. Pin Availability:**

**SPI Pin Requirements:**
```
Single device:  4 pins (MISO, MOSI, SCK, CS)
Multiple devices: 3 + N pins (shared MISO/MOSI/SCK, one CS per device)

Example: 5 SPI sensors = 3 shared + 5 CS = 8 GPIO pins
```

**I2C Pin Requirements:**
```
Any number of devices: 2 pins (SDA, SCL) + external pull-ups

Example: 5 I2C sensors = 2 GPIO pins total
```

**Pin-Constrained Design Example:**
```
Requirement: ESP32-C3 (limited GPIOs) with 4 sensors

Option A (all SPI): 3 + 4 = 7 GPIO pins
Option B (all I2C): 2 GPIO pins
Option C (hybrid): SPI for IMU (high-speed), I2C for 3 low-speed sensors = 4 + 2 = 6 GPIO pins

Decision: Option C (hybrid) balances performance and GPIO usage
```

**3. Robustness and EMI:**

**SPI Advantages:**
- Differential signaling possible (not standard, but LVDS variants exist)
- Point-to-point connections less susceptible to noise
- Higher drive strength options

**I2C Sensitivity:**
- Open-drain bus requires pull-ups (slower rise times)
- More susceptible to capacitive loading
- Longer traces → signal integrity issues

**Example: Noisy Industrial Environment**
```
Problem: 10 cm I2C trace next to high-current motor driver

Symptoms:
- Intermittent NACKs
- Bus lockups
- CRC errors

Fix Options:
1. Switch to SPI (more robust for this distance)
2. Add RC filter on I2C lines (increases rise time, limits to 100 kHz)
3. Shielded twisted pair for SDA/SCL
4. Use I2C buffer IC (PCA9515) for bus isolation

Decision: Switched IMU to SPI, kept slower sensors on I2C with buffer IC
```

**4. Multi-Drop Topology:**

**I2C Strength:**
- Natural multi-drop with addressing
- Easy to add/remove devices
- Bus arbitration built-in

**Example: Modular Sensor Board**
```
Requirement: Support 1-8 sensor modules, hot-swappable

I2C: Perfect fit
- Each module has unique address
- Simple 2-wire connector
- Auto-detection via address scan

SPI: Would require:
- 8 CS lines (one per slot)
- Multiplexing logic
- Complex hot-swap handling
```

**SPI Multi-Drop:**
```c
// SPI requires manual chip-select management
void spi_write_to_device(uint8_t device_id, uint8_t *data, size_t len) {
    // Assert CS for target device
    gpio_set_level(cs_pins[device_id], 0);
    
    spi_device_transmit(spi_handle, &trans);
    
    // De-assert CS
    gpio_set_level(cs_pins[device_id], 1);
}
```

**I2C Multi-Drop:**
```c
// I2C: Just use different addresses
i2c_master_write_to_device(I2C_NUM_0, SENSOR_ADDR_1, data, len, timeout);
i2c_master_write_to_device(I2C_NUM_0, SENSOR_ADDR_2, data, len, timeout);
```

**5. Board Routing Constraints:**

**I2C:**
- Simpler routing (2 traces)
- Can snake around board
- Length limits: <1m for standard mode, <30cm for fast mode

**SPI:**
- More complex routing (4+ traces)
- Need to match trace lengths for high-speed (>10 MHz)
- Less sensitive to trace length (<5ns skew acceptable up to 20 MHz)

**6. System-Level Example:**

**Smart Shoe Design:**
```
Sensors Required:
1. ICM-42688 IMU (high-speed, 100 Hz)
2. MS5637 Pressure/Altitude (low-speed, 10 Hz)
3. SHT40 Humidity/Temp (low-speed, 1 Hz)
4. External flash (high-speed, firmware storage)

SPI Bus (8 MHz):
├─ ICM-42688 IMU (CS1)
└─ W25Q128 Flash (CS2)

I2C Bus (100 kHz):
├─ MS5637 Pressure (0x76)
├─ SHT40 Humidity (0x44)
└─ (Reserved for future sensors)

Rationale:
- IMU on SPI: High sample rate benefits from DMA, low latency
- Flash on SPI: Fast firmware updates (>1 MB/s)
- Slow sensors on I2C: Saves GPIO pins, adequate bandwidth
- I2C bus available for expansion
```

**7. Testing and Debugging:**

**I2C Advantages:**
- Logic analyzers easily decode I2C (start/stop conditions, addresses)
- Built-in diagnostics (ACK/NACK visible)
- Can probe mid-transaction (open-drain bus)

**SPI Challenges:**
- Chip-select timing critical
- No standard packet structure (device-specific)
- Harder to probe without disrupting signal

**Test Example:**
```bash
# I2C: Scan for devices (easy)
i2cdetect -y 1
     0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f
00:          -- -- -- -- -- -- -- -- -- -- -- -- -- 
10: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
20: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
30: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
40: -- -- -- -- 44 -- -- -- -- -- -- -- -- -- -- -- 
50: -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- -- 
60: -- -- -- -- -- -- -- -- 68 -- -- -- -- -- -- -- 
70: -- -- -- -- -- -- 76 --

# SPI: Need custom test code per device
```

**Common Failure Modes:**

**I2C:**
- Bus lockup (SDA stuck low) → Requires clock wiggling recovery
- Address conflict → Need to change device address or use mux (TCA9548A)
- Slow rise time → Reduce bus capacitance or use faster pull-ups

**SPI:**
- Chip-select conflict → Check CS polarity and timing
- Phase/polarity mismatch → Verify CPOL/CPHA settings
- DMA issues → Check buffer alignment and size

**Summary Decision Matrix:**

```
Choose SPI if:
✅ High bandwidth (>1 Mbps)
✅ Full-duplex needed
✅ GPIO pins available
✅ Point-to-point connection preferred
✅ Low latency critical

Choose I2C if:
✅ Low/moderate bandwidth (<400 kbps)
✅ GPIO constrained
✅ Multi-drop topology
✅ Simple 2-wire connection preferred
✅ Easy hot-swap/expansion needed

Hybrid Approach:
✅ Use SPI for high-speed sensors (IMU, camera)
✅ Use I2C for low-speed sensors (temp, humidity)
✅ Reserve one SPI for flash/display
✅ Keep I2C for debug/expansion
```

**Production Considerations:**

1. **Testability:** I2C bus scan simplifies manufacturing test
2. **EMI Compliance:** SPI may have better EMI performance at high speeds
3. **Cost:** I2C saves GPIO pins (smaller MCU possible)
4. **Failure Recovery:** I2C bus stuck? Need recovery mechanism. SPI failed CS? Simpler to isolate.

**My Typical Choice:**
In most wearable/IoT designs, I use **SPI for IMU** (high-speed, DMA) and **I2C for slow sensors** (temp, pressure, RTC) to balance performance, GPIO usage, and simplicity.

---

[*Continued in next response due to length...*]
