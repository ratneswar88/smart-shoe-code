/**
 * ESP32 BLE Interview Questions & Answers
 * ========================================
 * 
 * Comprehensive guide covering:
 * - BLE Fundamentals
 * - ESP32 BLE Architecture
 * - Practical Implementation
 * - Common Issues and Solutions
 * - Performance Optimization
 * 
 * For: Senior Embedded Engineer Interview Preparation
 */

// ============================================================================
// SECTION 1: BLE FUNDAMENTALS
// ============================================================================

/**
 * Q1: What is BLE and how is it different from Classic Bluetooth?
 * ================================================================
 */

ANSWER:
BLE (Bluetooth Low Energy) is a wireless protocol designed for low-power applications.

Key Differences from Classic Bluetooth:

| Feature              | Classic BT        | BLE               |
|---------------------|-------------------|-------------------|
| Power Consumption   | ~1 mA continuous  | ~15 µA average    |
| Data Rate           | 1-3 Mbps          | 1 Mbps            |
| Range               | ~10 m             | ~50-100 m         |
| Pairing Time        | ~6 seconds        | ~6 ms             |
| Peak Current        | ~30 mA            | ~15 mA            |
| Use Case            | Audio streaming   | Sensors, IoT      |
| Connection Model    | Point-to-point    | Star topology     |

BLE Architecture:
- GAP (Generic Access Profile): Connection management, advertising
- GATT (Generic Attribute Profile): Data structure and transfer
- ATT (Attribute Protocol): Data representation
- SMP (Security Manager Protocol): Pairing and encryption

/**
 * Q2: Explain BLE roles: Central, Peripheral, Broadcaster, Observer.
 * ==================================================================
 */

ANSWER:

1. PERIPHERAL (Server/Slave):
   - Advertises its presence
   - Accepts connections
   - Provides services and characteristics
   - Example: Heart rate monitor, temperature sensor
   - ESP32: Most sensor applications

2. CENTRAL (Client/Master):
   - Scans for peripherals
   - Initiates connections
   - Reads/writes characteristics
   - Example: Smartphone, gateway
   - ESP32: Data collector, hub

3. BROADCASTER:
   - Only advertises, does not accept connections
   - Example: Beacon (iBeacon, Eddystone)
   - ESP32: Asset tracking, proximity detection

4. OBSERVER:
   - Only scans, does not connect
   - Example: BLE sniffer, passive scanner
   - ESP32: Data logger, monitoring system

Note: ESP32 can operate in multiple roles simultaneously (e.g., peripheral + central).

/**
 * Q3: What are GATT Services and Characteristics?
 * ===============================================
 */

ANSWER:

GATT Hierarchy:
Profile → Service → Characteristic → Descriptor

SERVICE:
- Collection of related characteristics
- Identified by UUID (16-bit or 128-bit)
- Example: Heart Rate Service (0x180D)

CHARACTERISTIC:
- Single data point
- Has properties: Read, Write, Notify, Indicate
- Has value (actual data)
- Example: Heart Rate Measurement (0x2A37)

DESCRIPTOR:
- Metadata about characteristic
- Example: Client Characteristic Configuration (CCCD) for notifications

Example Structure:
Service: "Environmental Sensing" (0x181A)
  ├─ Characteristic: "Temperature" (0x2A6E)
  │    ├─ Properties: Read, Notify
  │    ├─ Value: 25.3°C
  │    └─ Descriptor: CCCD (enable/disable notifications)
  │
  └─ Characteristic: "Humidity" (0x2A6F)
       ├─ Properties: Read, Notify
       └─ Value: 60%

/**
 * Q4: What is advertising in BLE? What data can be advertised?
 * ============================================================
 */

ANSWER:

Advertising is how peripherals announce their presence without connection.

ADVERTISING PACKET STRUCTURE (31 bytes max):
- Flags (3 bytes): BR/EDR support, discoverability
- UUID (2-16 bytes): Services available
- Device Name (up to 20 bytes)
- Manufacturer Data (up to 27 bytes): Custom data
- TX Power Level (3 bytes)
- Service Data (variable)

Advertising Types:
1. ADV_IND: Connectable, scannable
2. ADV_DIRECT_IND: Directed to specific device
3. ADV_NONCONN_IND: Non-connectable (broadcast only)
4. ADV_SCAN_IND: Scannable but non-connectable

Advertising Intervals:
- Fast: 20-30 ms (high power, quick discovery)
- Standard: 100-1000 ms
- Slow: 1-10 seconds (low power, slow discovery)

Trade-off: Faster = More discoverable BUT higher power consumption

ESP32 Example:
```cpp
BLEAdvertising* pAdvertising = BLEDevice::getAdvertising();
pAdvertising->addServiceUUID(SERVICE_UUID);
pAdvertising->setMinInterval(0x20);  // 20 ms
pAdvertising->setMaxInterval(0x40);  // 40 ms
BLEDevice::startAdvertising();
```

/**
 * Q5: Explain BLE connection parameters and their impact.
 * =======================================================
 */

ANSWER:

Connection Parameters (negotiated during connection):

1. CONNECTION INTERVAL (CI):
   - Time between connection events
   - Range: 7.5 ms - 4 seconds
   - ESP32 typical: 50-100 ms
   - Trade-off: Shorter = faster but higher power

2. SLAVE LATENCY (SL):
   - Number of connection events peripheral can skip
   - Range: 0-499
   - Allows peripheral to sleep
   - Example: Latency=3 means can skip 3 events

3. SUPERVISION TIMEOUT (ST):
   - Maximum time without communication before disconnect
   - Range: 100 ms - 32 seconds
   - Must satisfy: ST > (1 + SL) × CI × 2

4. MTU (Maximum Transmission Unit):
   - Maximum data per packet
   - Default: 23 bytes (20 bytes payload)
   - ESP32 supports up to 517 bytes
   - Negotiated via MTU exchange

Impact Example:
```
Configuration 1 (Fast, High Power):
CI = 15 ms, SL = 0, ST = 1000 ms
Power: ~1 mA, Latency: 15 ms

Configuration 2 (Slow, Low Power):
CI = 100 ms, SL = 4, ST = 2000 ms
Power: ~50 µA, Latency: 500 ms (can skip 4 intervals)
```

// ============================================================================
// SECTION 2: ESP32 BLE ARCHITECTURE
// ============================================================================

/**
 * Q6: Explain ESP32 BLE architecture (Controller vs Host).
 * ========================================================
 */

ANSWER:

ESP32 BLE Stack Architecture:

APPLICATION
    ↓
HOST (ESP32 CPU - FreeRTOS tasks)
├─ GAP (Generic Access Profile)
├─ GATT (Generic Attribute Profile)
├─ SMP (Security Manager)
├─ L2CAP (Logical Link Control)
└─ HCI (Host Controller Interface)
    ↓ (HCI UART or VHCI)
CONTROLLER (Dedicated BLE hardware)
├─ Link Layer (LL)
├─ Baseband
└─ Radio (2.4 GHz PHY)

ESP32 Advantages:
1. Integrated controller - no external BLE chip needed
2. Dual-mode: BLE + Classic Bluetooth
3. Hardware encryption (AES-128)
4. 9 dBm TX power (up to 100m range)
5. -97 dBm sensitivity

Memory Usage:
- BLE stack: ~65 KB RAM (when active)
- GATT database: Depends on services (~2-10 KB)
- Connection buffers: ~5 KB per connection

ESP32 vs ESP32-C3 vs ESP32-S3:
- ESP32: Dual-mode (BLE + Classic)
- ESP32-C3: BLE 5.0 only (smaller, cheaper)
- ESP32-S3: BLE 5.0 + more memory

/**
 * Q7: What are the main ESP32 BLE libraries? NimBLE vs Bluedroid?
 * ===============================================================
 */

ANSWER:

Two BLE stacks available for ESP32:

1. BLUEDROID (Default):
   - Full-featured
   - Larger code size (~500 KB flash)
   - Higher RAM usage (~65 KB)
   - Supports BLE + Classic Bluetooth
   - More stable, battle-tested
   - Arduino BLE library uses this

2. NIMBLE (Apache MyNewt):
   - Lightweight
   - Smaller code size (~250 KB flash)
   - Lower RAM usage (~40 KB)
   - BLE only (no Classic Bluetooth)
   - More flexible, better for custom protocols
   - Better for multi-connection scenarios

Comparison:

| Feature           | Bluedroid  | NimBLE    |
|------------------|------------|-----------|
| Flash Size       | ~500 KB    | ~250 KB   |
| RAM Usage        | ~65 KB     | ~40 KB    |
| Classic BT       | Yes        | No        |
| Concurrent Conn  | 3-4        | 9         |
| Custom Services  | Harder     | Easier    |
| Community        | Larger     | Growing   |

When to use:
- Bluedroid: Arduino, need Classic BT, want stability
- NimBLE: Custom firmware, need multiple connections, tight memory

/**
 * Q8: How does ESP32 BLE coexist with WiFi?
 * ==========================================
 */

ANSWER:

ESP32 shares 2.4 GHz radio between WiFi and BLE using time-slicing.

COEXISTENCE MECHANISM:
- Time Division Multiplexing (TDM)
- Hardware arbiter switches between WiFi and BLE
- BLE gets time slots between WiFi activity

Impact:
1. BLE connection intervals may increase
2. Occasional packet loss
3. Slightly higher power consumption
4. Not a problem for typical sensor applications

Optimization:
```cpp
// Enable coexistence
esp_wifi_set_ps(WIFI_PS_MIN_MODEM);  // Modem sleep

// Configure BLE priority
esp_coex_preference_set(ESP_COEX_PREFER_BT);

// Use longer BLE connection intervals when WiFi active
// CI = 50-100 ms works well with WiFi
```

Performance Impact:
- BLE alone: ~15 mA active, ~1 ms latency
- BLE + WiFi: ~80 mA active, ~5-10 ms latency
- Still usable for most applications!

Real-world example (your smart shoe):
- BLE for sensor data streaming
- WiFi for cloud uploads
- Works well with proper interval tuning

// ============================================================================
// SECTION 3: PRACTICAL IMPLEMENTATION
// ============================================================================

/**
 * Q9: How do you implement a BLE peripheral on ESP32?
 * ===================================================
 */

ANSWER:

Complete BLE Peripheral Implementation:

```cpp
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

// UUIDs (use online generator for production)
#define SERVICE_UUID        "4fafc201-1fb5-459e-8fcc-c5c9c331914b"
#define CHARACTERISTIC_UUID "beb5483e-36e1-4688-b7f5-ea07361b26a8"

BLEServer* pServer = nullptr;
BLECharacteristic* pCharacteristic = nullptr;
bool deviceConnected = false;

// Server callbacks
class MyServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer) {
        deviceConnected = true;
        Serial.println("Device connected");
    }
    
    void onDisconnect(BLEServer* pServer) {
        deviceConnected = false;
        Serial.println("Device disconnected");
        // Restart advertising
        BLEDevice::startAdvertising();
    }
};

// Characteristic callbacks
class MyCallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
        std::string value = pCharacteristic->getValue();
        if (value.length() > 0) {
            Serial.print("Received: ");
            for (int i = 0; i < value.length(); i++)
                Serial.print(value[i]);
            Serial.println();
        }
    }
};

void setup() {
    Serial.begin(115200);
    
    // Initialize BLE
    BLEDevice::init("ESP32_Sensor");
    
    // Create BLE Server
    pServer = BLEDevice::createServer();
    pServer->setCallbacks(new MyServerCallbacks());
    
    // Create BLE Service
    BLEService *pService = pServer->createService(SERVICE_UUID);
    
    // Create BLE Characteristic
    pCharacteristic = pService->createCharacteristic(
        CHARACTERISTIC_UUID,
        BLECharacteristic::PROPERTY_READ |
        BLECharacteristic::PROPERTY_WRITE |
        BLECharacteristic::PROPERTY_NOTIFY
    );
    
    // Add descriptor for notifications
    pCharacteristic->addDescriptor(new BLE2902());
    pCharacteristic->setCallbacks(new MyCallbacks());
    
    // Start service
    pService->start();
    
    // Start advertising
    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(SERVICE_UUID);
    pAdvertising->setScanResponse(true);
    pAdvertising->setMinPreferred(0x06);  // iPhone connection issues
    pAdvertising->setMaxPreferred(0x12);
    BLEDevice::startAdvertising();
    
    Serial.println("BLE Peripheral ready!");
}

void loop() {
    if (deviceConnected) {
        // Send data via notification
        uint8_t value = random(0, 100);
        pCharacteristic->setValue(&value, 1);
        pCharacteristic->notify();
        
        delay(1000);
    }
}
```

Key Points:
1. UUIDs identify services/characteristics
2. Properties define what client can do
3. Callbacks handle events
4. Notifications push data to client
5. Must restart advertising after disconnect

/**
 * Q10: How do you implement BLE notifications efficiently?
 * ========================================================
 */

ANSWER:

Notifications are the most efficient way to push data from peripheral to central.

NOTIFICATION vs INDICATION:
- Notification: No acknowledgment (faster, less reliable)
- Indication: Acknowledged (slower, more reliable)

Efficient Notification Implementation:

```cpp
// 1. Design efficient data structure
struct __attribute__((packed)) SensorData {
    uint16_t timestamp;  // 2 bytes
    int16_t accelX;      // 2 bytes
    int16_t accelY;      // 2 bytes
    int16_t accelZ;      // 2 bytes
    uint8_t battery;     // 1 byte
};  // Total: 9 bytes per packet

// 2. Use RTOS task for notifications
void notificationTask(void* parameter) {
    SensorData data;
    TickType_t xLastWakeTime = xTaskGetTickCount();
    
    while (1) {
        if (deviceConnected) {
            // Prepare data
            data.timestamp = millis() & 0xFFFF;
            data.accelX = readAccelX();
            data.accelY = readAccelY();
            data.accelZ = readAccelZ();
            data.battery = readBattery();
            
            // Send notification
            pCharacteristic->setValue((uint8_t*)&data, sizeof(data));
            pCharacteristic->notify();
        }
        
        // 100 Hz sampling
        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(10));
    }
}

void setup() {
    // ... BLE setup ...
    
    // Create notification task
    xTaskCreate(
        notificationTask,
        "NotifyTask",
        2048,
        NULL,
        1,
        NULL
    );
}
```

Optimization Tips:
1. Pack data tightly (use packed structs)
2. Use fixed-size integers (int16_t vs float saves 2 bytes)
3. Batch multiple samples if latency allows
4. Increase MTU for larger packets (up to 512 bytes)
5. Use connection interval matching sample rate

Throughput Example:
- MTU = 512 bytes
- Connection Interval = 15 ms
- Theoretical: 512 bytes / 15 ms = 34 KB/s
- Practical: ~20-25 KB/s (overhead, retransmissions)

/**
 * Q11: How do you handle BLE security and pairing?
 * ================================================
 */

ANSWER:

BLE Security Levels:

1. NO SECURITY:
   - Open connection
   - Use for: Public beacons, non-sensitive data

2. UNAUTHENTICATED PAIRING:
   - Just Works method
   - No PIN/passkey
   - Use for: Consumer IoT

3. AUTHENTICATED PAIRING:
   - PIN code or passkey
   - User confirmation
   - Use for: Medical devices, payment

4. AUTHENTICATED + ENCRYPTION:
   - Encrypted link
   - Man-in-the-middle protection
   - Use for: Sensitive data

ESP32 Implementation:

```cpp
// Enable security
BLESecurity *pSecurity = new BLESecurity();

// Set authentication mode
pSecurity->setAuthenticationMode(ESP_LE_AUTH_REQ_SC_MITM_BOND);

// Set I/O capabilities
pSecurity->setCapability(ESP_IO_CAP_OUT);  // Display only
// ESP_IO_CAP_IN: Keyboard only
// ESP_IO_CAP_IO: Display + keyboard
// ESP_IO_CAP_NONE: No input/output

// Enable encryption
pSecurity->setInitEncryptionKey(ESP_BLE_ENC_KEY_MASK | ESP_BLE_ID_KEY_MASK);

// Bonding (store keys for reconnection)
pSecurity->setStaticPIN(123456);  // Fixed PIN
```

Security Callbacks:

```cpp
class SecurityCallbacks : public BLESecurityCallbacks {
    uint32_t onPassKeyRequest() {
        Serial.println("PassKey requested");
        return 123456;
    }
    
    void onPassKeyNotify(uint32_t pass_key) {
        Serial.printf("PassKey: %d\n", pass_key);
    }
    
    bool onSecurityRequest() {
        Serial.println("Security request");
        return true;
    }
    
    bool onConfirmPIN(uint32_t pass_key) {
        Serial.printf("Confirm PIN: %d\n", pass_key);
        return true;
    }
    
    void onAuthenticationComplete(esp_ble_auth_cmpl_t auth_cmpl) {
        if (auth_cmpl.success) {
            Serial.println("Pairing successful");
        } else {
            Serial.println("Pairing failed");
        }
    }
};

pServer->setCallbacks(new SecurityCallbacks());
```

Best Practices:
1. Use bonding for devices that reconnect frequently
2. Store bonding info in NVS (survives reboot)
3. Implement re-pairing mechanism
4. Consider battery impact (encryption uses power)

// ============================================================================
// SECTION 4: COMMON ISSUES AND DEBUGGING
// ============================================================================

/**
 * Q12: What are common ESP32 BLE connection issues?
 * =================================================
 */

ANSWER:

Common Problems and Solutions:

1. CANNOT DISCOVER DEVICE:
   Problem: Device not showing in scan
   Causes:
   - Not advertising
   - Wrong advertising type
   - Device name too long
   - Insufficient TX power
   
   Solution:
   ```cpp
   // Check advertising is started
   BLEDevice::startAdvertising();
   
   // Increase TX power
   esp_ble_tx_power_set(ESP_BLE_PWR_TYPE_ADV, ESP_PWR_LVL_P9);
   
   // Set proper advertising type
   pAdvertising->setAdvertisementType(ADV_TYPE_IND);
   
   // Shorter device name (<20 chars)
   BLEDevice::init("ESP32");
   ```

2. CONNECTION DROPS FREQUENTLY:
   Problem: Disconnects after few seconds
   Causes:
   - Supervision timeout too short
   - Poor signal strength
   - Connection interval mismatch
   - Insufficient buffers
   
   Solution:
   ```cpp
   // Increase supervision timeout
   esp_ble_conn_update_params_t params;
   params.latency = 0;
   params.min_int = 0x10;  // 20 ms
   params.max_int = 0x20;  // 40 ms
   params.timeout = 400;   // 4 seconds
   esp_ble_gap_update_conn_params(&params);
   
   // Increase BLE task priority
   esp_ble_controller_config_t bt_cfg = BT_CONTROLLER_INIT_CONFIG_DEFAULT();
   bt_cfg.controller_task_prio = 23;  // Higher priority
   ```

3. SLOW DATA TRANSFER:
   Problem: Low throughput
   Causes:
   - Small MTU (23 bytes default)
   - Long connection interval
   - Not using notifications
   
   Solution:
   ```cpp
   // Request larger MTU
   pServer->updateConnParams(addr, 0x06, 0x10, 0, 400);
   uint16_t mtu = 512;
   esp_ble_gatt_set_local_mtu(mtu);
   
   // Use notifications, not reads
   pCharacteristic->notify();  // Not getValue()
   
   // Optimize connection interval
   // For high throughput: 15-30 ms
   ```

4. HIGH POWER CONSUMPTION:
   Problem: Battery drains quickly
   Causes:
   - Continuous advertising
   - Short connection intervals
   - No sleep between connections
   
   Solution:
   ```cpp
   // Slow down advertising
   pAdvertising->setMinInterval(1600);  // 1 second
   pAdvertising->setMaxInterval(1920);  // 1.2 seconds
   
   // Use slave latency
   params.latency = 4;  // Skip 4 connection events
   
   // Enable light sleep
   esp_pm_config_esp32_t pm_config = {
       .max_freq_mhz = 160,
       .min_freq_mhz = 80,
       .light_sleep_enable = true
   };
   esp_pm_configure(&pm_config);
   ```

5. CANNOT PAIR/BOND:
   Problem: Pairing fails
   Causes:
   - Security settings mismatch
   - NVS full
   - Already bonded to max devices
   
   Solution:
   ```cpp
   // Clear bonding information
   esp_ble_remove_bond_device(remote_bd_addr);
   
   // Check NVS space
   nvs_stats_t nvs_stats;
   nvs_get_stats(NULL, &nvs_stats);
   
   // Reduce security requirements
   pSecurity->setAuthenticationMode(ESP_LE_AUTH_BOND);
   ```

/**
 * Q13: How do you debug BLE issues on ESP32?
 * ==========================================
 */

ANSWER:

BLE Debugging Techniques:

1. ENABLE BLE LOGS:
```cpp
// In sdkconfig or platformio.ini
CONFIG_LOG_DEFAULT_LEVEL_DEBUG=y
CONFIG_BT_LOG_HCI_TRACE_LEVEL_DEBUG=y

// In code
esp_log_level_set("*", ESP_LOG_DEBUG);
esp_log_level_set("BLE", ESP_LOG_VERBOSE);
```

2. MONITOR BLE STATE:
```cpp
void printBLEState() {
    Serial.printf("Devices connected: %d\n", pServer->getConnectedCount());
    Serial.printf("MTU: %d\n", pServer->getPeerMTU(connId));
    Serial.printf("Free heap: %d\n", ESP.getFreeHeap());
}
```

3. USE BLE SNIFFER:
- nRF Sniffer (Nordic)
- Ellisys Bluetooth Analyzer
- Wireshark with Ubertooth
- Shows all packets, connection parameters, errors

4. MOBILE APPS:
- nRF Connect (Android/iOS): Best for testing
- LightBlue (iOS): Good UI
- BLE Scanner (Android): Detailed info

5. CHECK CONNECTION PARAMETERS:
```cpp
esp_ble_conn_update_params_t conn_params;
esp_ble_get_current_conn_params(addr, &conn_params);
Serial.printf("Interval: %d ms\n", conn_params.min_int * 1.25);
Serial.printf("Latency: %d\n", conn_params.latency);
Serial.printf("Timeout: %d ms\n", conn_params.timeout * 10);
```

6. COMMON LOG PATTERNS:
```
Good connection:
"BLE: Connected to XX:XX:XX:XX:XX:XX"
"BLE: MTU exchanged: 512"
"BLE: Conn params: int=20ms, lat=0, to=2000ms"

Connection issues:
"BLE: Connection timeout"
"BLE: Link loss"
"BLE: GATT server error"
```

// ============================================================================
// SECTION 5: PERFORMANCE OPTIMIZATION
// ============================================================================

/**
 * Q14: How do you optimize BLE throughput on ESP32?
 * =================================================
 */

ANSWER:

Maximize BLE Data Rate:

1. INCREASE MTU:
```cpp
// Server side
esp_ble_gatt_set_local_mtu(512);

// Client requests MTU
esp_ble_gattc_send_mtu_req(gattc_if, conn_id);
```

2. OPTIMIZE CONNECTION INTERVAL:
```cpp
// For max throughput: shorter interval
esp_ble_conn_update_params_t params = {
    .latency = 0,
    .min_int = 6,   // 7.5 ms
    .max_int = 12,  // 15 ms
    .timeout = 400  // 4 seconds
};
esp_ble_gap_update_conn_params(&params);
```

3. USE DATA LENGTH EXTENSION (DLE):
```cpp
// Increases packet size from 27 to 251 bytes
esp_ble_gap_set_prefer_conn_params(addr, 6, 12, 0, 400);
```

4. EFFICIENT DATA PACKING:
```cpp
// Bad: 4 characteristics × 4 bytes = 16 bytes + overhead
float accelX, accelY, accelZ, gyroZ;

// Good: 1 characteristic with packed struct = 8 bytes + overhead
struct __attribute__((packed)) IMUData {
    int16_t accelX, accelY, accelZ;
    int16_t gyroZ;
} imuData;
```

5. BATCH NOTIFICATIONS:
```cpp
// Instead of notifying every sample
for (int i = 0; i < 10; i++) {
    buffer[i] = readSensor();
}
pCharacteristic->setValue(buffer, 10);
pCharacteristic->notify();  // Send 10 samples at once
```

Achieved Throughput:
- MTU = 512, CI = 7.5 ms: ~100 KB/s
- MTU = 512, CI = 15 ms: ~50 KB/s
- MTU = 23, CI = 30 ms: ~1.5 KB/s

Real Example (Smart Shoe):
- 9-axis IMU @ 100 Hz
- Data: 18 bytes per sample (6 int16_t)
- Required: 1.8 KB/s
- Solution: MTU=128, CI=30ms, batch 3 samples
- Achieved: ~3 KB/s with margin

/**
 * Q15: How do you minimize BLE power consumption?
 * ===============================================
 */

ANSWER:

Power Optimization Strategies:

1. ADVERTISING OPTIMIZATION:
```cpp
// Slow advertising when not critical
pAdvertising->setMinInterval(1600);  // 1 second
pAdvertising->setMaxInterval(3200);  // 2 seconds

// Stop advertising when connected
void onConnect() {
    BLEDevice::stopAdvertising();
}

// Reduce TX power
esp_ble_tx_power_set(ESP_BLE_PWR_TYPE_ADV, ESP_PWR_LVL_N3);  // -3 dBm
```

2. CONNECTION INTERVAL OPTIMIZATION:
```cpp
// Use slave latency
params.latency = 10;  // Skip 10 connection events
params.min_int = 80;  // 100 ms
params.max_int = 120; // 150 ms

// ESP32 can sleep between connection events!
```

3. ENABLE MODEM SLEEP:
```cpp
esp_pm_config_esp32_t pm_config = {
    .max_freq_mhz = 160,
    .min_freq_mhz = 80,  // Lower freq when idle
    .light_sleep_enable = true
};
esp_pm_configure(&pm_config);
```

4. DISCONNECT WHEN IDLE:
```cpp
// Disconnect if no data for 30 seconds
if (millis() - lastActivity > 30000) {
    esp_ble_gap_disconnect(remote_bda);
}
```

5. USE DEEP SLEEP:
```cpp
// For battery-powered sensors
void enterDeepSleep() {
    // Store state in RTC memory
    // Configure wakeup (timer, GPIO, touch)
    esp_sleep_enable_timer_wakeup(60 * 1000000);  // 60 sec
    esp_deep_sleep_start();
}
```

Power Consumption Comparison:
- Continuous advertising (20ms): ~20 mA
- Connected (CI=15ms, SL=0): ~15 mA
- Connected (CI=100ms, SL=4): ~2 mA
- Light sleep between events: ~0.8 mA
- Deep sleep: ~10 µA

Battery Life Example (1000 mAh battery):
- Continuous: 50 hours
- Optimized connection: 500 hours (20 days)
- With deep sleep (1% duty): 5000 hours (7 months)

/**
 * Q16: How do you handle multiple BLE connections on ESP32?
 * =========================================================
 */

ANSWER:

ESP32 supports up to 3-4 simultaneous connections (Bluedroid) or 9 (NimBLE).

Multi-Connection Implementation:

```cpp
#define MAX_CONNECTIONS 3

struct ClientConnection {
    uint16_t conn_id;
    esp_bd_addr_t remote_bda;
    bool connected;
    uint16_t mtu;
};

ClientConnection clients[MAX_CONNECTIONS];
int connectedCount = 0;

class MultiServerCallbacks: public BLEServerCallbacks {
    void onConnect(BLEServer* pServer, esp_ble_gatts_cb_param_t *param) {
        if (connectedCount < MAX_CONNECTIONS) {
            clients[connectedCount].conn_id = param->connect.conn_id;
            memcpy(clients[connectedCount].remote_bda, 
                   param->connect.remote_bda, 6);
            clients[connectedCount].connected = true;
            connectedCount++;
            
            Serial.printf("Client %d connected\n", connectedCount);
            
            // Continue advertising if not full
            if (connectedCount < MAX_CONNECTIONS) {
                BLEDevice::startAdvertising();
            }
        }
    }
    
    void onDisconnect(BLEServer* pServer) {
        connectedCount--;
        // Find and remove client
        // Restart advertising
        BLEDevice::startAdvertising();
    }
};

// Send notification to all connected clients
void notifyAllClients(uint8_t* data, size_t len) {
    for (int i = 0; i < MAX_CONNECTIONS; i++) {
        if (clients[i].connected) {
            pCharacteristic->setValue(data, len);
            pCharacteristic->notify();
        }
    }
}
```

Considerations:
1. Each connection uses ~5 KB RAM
2. CPU load increases linearly
3. Throughput is shared (each gets 1/N bandwidth)
4. Connection intervals must be compatible

Use Cases:
- One-to-many sensor data broadcast
- Multiple phone connections (family members)
- Gateway collecting from multiple sensors

// ============================================================================
// SECTION 6: PRACTICAL SCENARIOS
// ============================================================================

/**
 * Q17: Design a BLE-based fitness tracker (heart rate + steps).
 * =============================================================
 */

ANSWER:

Complete Fitness Tracker Design:

Services:
1. Heart Rate Service (0x180D) - Standard
2. Custom Steps Service (custom UUID)
3. Battery Service (0x180F) - Standard

```cpp
// 1. Define services
#define HEART_RATE_SERVICE_UUID   "0x180D"
#define HEART_RATE_CHAR_UUID      "0x2A37"
#define STEPS_SERVICE_UUID        "12345678-1234-1234-1234-123456789012"
#define STEPS_CHAR_UUID           "12345678-1234-1234-1234-123456789013"

// 2. Data structures
struct __attribute__((packed)) HeartRateData {
    uint8_t flags;      // Heart rate format
    uint8_t bpm;        // Beats per minute
    uint16_t energy;    // Energy expended
};

// 3. Implementation
void setupFitnessTracker() {
    BLEDevice::init("FitTracker");
    BLEServer *pServer = BLEDevice::createServer();
    
    // Heart Rate Service
    BLEService *pHRService = pServer->createService(HEART_RATE_SERVICE_UUID);
    BLECharacteristic *pHRChar = pHRService->createCharacteristic(
        HEART_RATE_CHAR_UUID,
        BLECharacteristic::PROPERTY_NOTIFY
    );
    pHRChar->addDescriptor(new BLE2902());
    pHRService->start();
    
    // Steps Service
    BLEService *pStepsService = pServer->createService(STEPS_SERVICE_UUID);
    BLECharacteristic *pStepsChar = pStepsService->createCharacteristic(
        STEPS_CHAR_UUID,
        BLECharacteristic::PROPERTY_READ | 
        BLECharacteristic::PROPERTY_NOTIFY
    );
    pStepsChar->addDescriptor(new BLE2902());
    pStepsService->start();
    
    // Start advertising
    BLEAdvertising *pAdvertising = BLEDevice::getAdvertising();
    pAdvertising->addServiceUUID(HEART_RATE_SERVICE_UUID);
    pAdvertising->addServiceUUID(STEPS_SERVICE_UUID);
    BLEDevice::startAdvertising();
}

// 4. Update task
void sensorTask(void* param) {
    HeartRateData hrData;
    uint32_t steps = 0;
    
    while (1) {
        // Read heart rate from sensor
        hrData.bpm = readHeartRate();
        hrData.flags = 0x00;  // 8-bit format
        hrData.energy = calculateEnergy();
        
        // Read steps from accelerometer
        steps = countSteps();
        
        // Update characteristics
        if (deviceConnected) {
            pHRChar->setValue((uint8_t*)&hrData, sizeof(hrData));
            pHRChar->notify();
            
            pStepsChar->setValue((uint8_t*)&steps, sizeof(steps));
            pStepsChar->notify();
        }
        
        vTaskDelay(pdMS_TO_TICKS(1000));  // 1 Hz update
    }
}
```

Power Optimization:
- Heart rate: 1 Hz sampling
- Steps: Update on significant change
- Connection interval: 100 ms
- Slave latency: 4
- Expected battery life: 5-7 days (200 mAh)

/**
 * Q18: How would you implement OTA updates over BLE?
 * ==================================================
 */

ANSWER:

BLE OTA Update Implementation:

```cpp
// Custom OTA Service
#define OTA_SERVICE_UUID      "8ec90001-f315-4f60-9fb8-838830daea50"
#define OTA_CONTROL_UUID      "8ec90002-f315-4f60-9fb8-838830daea50"
#define OTA_DATA_UUID         "8ec90003-f315-4f60-9fb8-838830daea50"

class OTACallbacks: public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *pCharacteristic) {
        std::string rxValue = pCharacteristic->getValue();
        
        if (pCharacteristic->getUUID().toString() == OTA_CONTROL_UUID) {
            // Control commands: START, END, ABORT
            if (rxValue == "START") {
                Update.begin(UPDATE_SIZE_UNKNOWN);
                Serial.println("OTA Started");
            }
            else if (rxValue == "END") {
                if (Update.end(true)) {
                    Serial.println("OTA Success");
                    ESP.restart();
                }
            }
        }
        else if (pCharacteristic->getUUID().toString() == OTA_DATA_UUID) {
            // Write firmware data
            if (Update.write((uint8_t*)rxValue.c_str(), rxValue.length())) {
                Serial.printf("Written: %d bytes\n", rxValue.length());
            }
        }
    }
};

void setupOTA() {
    BLEService *pOTAService = pServer->createService(OTA_SERVICE_UUID);
    
    // Control characteristic
    BLECharacteristic *pControl = pOTAService->createCharacteristic(
        OTA_CONTROL_UUID,
        BLECharacteristic::PROPERTY_WRITE
    );
    pControl->setCallbacks(new OTACallbacks());
    
    // Data characteristic (with large MTU)
    BLECharacteristic *pData = pOTAService->createCharacteristic(
        OTA_DATA_UUID,
        BLECharacteristic::PROPERTY_WRITE_NR  // No response = faster
    );
    pData->setCallbacks(new OTACallbacks());
    
    pOTAService->start();
}
```

Protocol:
1. Client sends "START" to control
2. Client sends firmware chunks to data characteristic
3. ESP32 writes to flash partition
4. Client sends "END" to control
5. ESP32 verifies and reboots

Considerations:
- Max MTU (512 bytes) for fastest transfer
- 512 KB firmware @ 50 KB/s = ~10 seconds
- Add CRC for integrity
- Handle disconnection gracefully
- Show progress to user

/**
 * KEY TAKEAWAYS FOR INTERVIEW
 * ===========================
 * 
 * 1. Know the fundamentals: GAP, GATT, Services, Characteristics
 * 2. Understand ESP32 architecture: Controller vs Host, Bluedroid vs NimBLE
 * 3. Can implement: Peripheral, Central, notifications, security
 * 4. Know common issues: Connection drops, throughput, power
 * 5. Optimization: MTU, connection intervals, batching, power management
 * 6. Real-world: Your smart shoe project demonstrates practical BLE skills
 * 
 * Your Experience to Highlight:
 * - ESP32-S3 smart shoe with BLE
 * - Real-time gait data streaming
 * - Power optimization for battery life
 * - Mobile app integration
 * - Handled connection management, data throughput
 */
