# INTERVIEW DAY QUICK REFERENCE
## Mountain View, CA - Embedded Firmware Engineer

---

## 🎯 YOUR ELEVATOR PITCH (30 SECONDS)

"I'm an embedded firmware engineer with 12 years building production-ready IoT devices, wearables, and industrial products. Core strengths: C/C++ firmware, FreeRTOS, device drivers, and manufacturing test automation. At Made Plus, I recently designed an ESP32 smart shoe with IMU sensor fusion, BLE connectivity, and power optimization that extended battery life 3x. I'm excited to transition to automotive embedded systems and have been studying ISO 26262 and the NXP S32 platform to prepare for safety-critical development."

---

## ⚠️ CRITICAL GAPS & YOUR BRIDGE STRATEGY

### Automotive Experience (NXP S32G/S32K, ARM Cortex-M7)
**Bridge:** "While I haven't worked specifically with S32G/S32K, I have extensive ARM Cortex-M experience (ESP32-S3, STM32 M4) and understand multi-core sync, DMA, interrupts, peripheral drivers. I've been studying the S32 reference manual and am excited to apply my embedded skills to automotive."

### CAN Bus & UDS
**Bridge:** "I have strong experience with SPI/I2C/UART and understand protocol state machines and error handling. I've studied CAN FD and UDS in preparation and can ramp quickly with hands-on practice."

### ISO 26262 & Functional Safety
**Bridge:** "My medical device work at Novatec exposed me to similar safety-critical principles: redundancy, fault detection, fail-safe modes, extensive testing. I understand the importance of traceability and deterministic behavior. I'm actively studying ISO 26262 Part 6 to prepare for this transition."

---

## 💪 YOUR STRONGEST STORIES (MEMORIZE THESE)

### 1. Smart Shoe EOL Testing (Manufacturing)
**Problem:** Needed complete EOL test framework for factory production
**Action:**
- Defined 4 test categories: POST, parametric, functional, boundary
- Wrote Python automation: 3-minute test cycle, pass/fail logging
- Collaborated with HW: added test points, UART boot mode, visual indicators
**Result:** Caught 12% defect rate in first production, improved yield 82% → 96%

### 2. IMU Driver Development (Device Driver)
**Problem:** Integrate GY-86 (3 sensors) via I2C for 100Hz gait analysis
**Action:**
- Designed 3-layer architecture: HAL, sensor, application
- Implemented DMA circular buffer with mutex protection
- Debugged I2C bus contention with oscilloscope
**Result:** Reliable 100Hz sampling, <2% packet loss over 72-hour test

### 3. Power Optimization (Resource-Constrained)
**Problem:** Battery life only 5 hours, needed 15+ hours
**Action:**
- Profiled current: found BLE advertising not stopping, IMU in active mode
- Implemented adaptive power management: Active/Idle/Sleep modes
- Added load switches for peripheral power control
**Result:** Extended battery life from 5 hours to 16 hours (3x improvement)

### 4. Manufacturing Yield Issue (Problem Solving)
**Problem:** 12% IMU initialization failures in production
**Investigation:** Flew to factory, found cold solder joints from marginal reflow profile
**Solutions:**
- Immediate: Added stress test (1000 I2C cycles) to catch failures
- Long-term: Adjusted reflow profile with factory (+8°C peak, longer dwell)
- Firmware: Added IMU retry logic (3 attempts)
**Result:** Failure rate dropped to 2.1%, field returns reduced 3% → 0.4%

---

## 🔧 TECHNICAL RAPID-FIRE ANSWERS

**Q: Stack overflow causes?**
A: Excessive locals, deep recursion, undersized stack. Use configCHECK_FOR_STACK_OVERFLOW=2 and uxTaskGetStackHighWaterMark() to measure actual usage.

**Q: Priority inversion?**
A: Low-priority task holds mutex, high-priority task blocked. Medium-priority task preempts low-priority. Solution: Priority inheritance (FreeRTOS mutexes).

**Q: Debug hard fault?**
A: Check CFSR/HFSR registers, examine stack frame (PC, LR, R0-R3). Common causes: NULL pointer, misaligned access, stack overflow.

**Q: DMA vs Interrupt?**
A: DMA for high-throughput periodic transfers (ADC sampling), interrupts for event-driven low-frequency. Used DMA for 100Hz IMU sampling to free CPU.

**Q: SPI debug checklist?**
1. Clock polarity/phase (CPOL/CPHA)
2. CS timing (setup/hold from datasheet)
3. Clock frequency within slave range
4. Logic analyzer to decode
5. Bus contention on MISO

**Q: I2C pull-up calculation?**
t_rise = 2.2 × R × C. Fast Mode (400kHz) requires t_rise < 300ns. Example: 2.2kΩ × 80pF = 387ns (too slow!) → reduce to 1.5kΩ.

---

## 📊 YOUR KEY NUMBERS (USE THESE)

- **12 years** embedded systems experience
- **100Hz** IMU sampling rate (Smart Shoe)
- **3x** battery life improvement (5h → 16h)
- **12% → 2.1%** failure rate reduction (manufacturing)
- **82% → 96%** first-pass yield improvement
- **3% → 0.4%** field return reduction
- **<2%** packet loss rate (sensor fusion)
- **ESP32-S3, STM32, PIC** platforms
- **FreeRTOS** task design and optimization

---

## 🎤 QUESTIONS TO ASK THEM

### Technical Depth
1. "What safety mechanisms are in your firmware—watchdogs, memory protection, redundancy?"
2. "How is code structured for ASIL compliance—segregated safety/non-safety partitions?"
3. "What's your testing pyramid—unit test coverage, HIL, vehicle integration?"

### Product & Team
4. "Which autonomous vehicle platform is this targeting—specific sensors/compute?"
5. "Firmware team size and structure? Collaboration with perception/planning?"
6. "Typical development cycle from prototype to vehicle deployment?"

### Growth
7. "Training/certification support for ISO 26262 and functional safety?"
8. "How do firmware engineers stay current with AV technology evolution?"

---

## ✅ BODY LANGUAGE & DELIVERY

- [ ] Maintain eye contact (not staring, natural)
- [ ] Smile genuinely when greeting
- [ ] Firm handshake (not crushing)
- [ ] Sit upright but relaxed
- [ ] Hand gestures when explaining (controlled, not distracting)
- [ ] Pause before answering complex questions (shows thoughtfulness)
- [ ] Speak clearly and at moderate pace
- [ ] Show enthusiasm for autonomous vehicles

---

## 🚫 RED FLAGS TO AVOID

1. ❌ Don't fake knowledge of automotive standards
2. ❌ Don't criticize previous employers
3. ❌ Don't give vague answers—use specific examples with numbers
4. ❌ Don't say "I don't know" without "but here's how I'd learn/approach it"
5. ❌ Don't monopolize—let them ask follow-ups

---

## 📝 INTERVIEW DAY CHECKLIST

**Materials:**
- [ ] 3 copies of resume (printed)
- [ ] Notebook + pen
- [ ] Portfolio/laptop (if you have Smart Shoe demo videos)
- [ ] Business cards (if you have them)

**Logistics:**
- [ ] Confirm interview time & location (call day before)
- [ ] Plan route, arrive 15 minutes early
- [ ] Phone on silent (not vibrate)
- [ ] Breath mints, water bottle

**Mental Prep:**
- [ ] Review this sheet morning-of
- [ ] Practice elevator pitch 3x
- [ ] Visualize successful interview
- [ ] Remember: They want you to succeed

---

## 💬 CLOSING STATEMENT

"Thank you for your time today. This conversation reinforced my excitement about this role. The combination of embedded firmware challenges and safety-critical automotive systems aligns perfectly with my skills and career goals. I'm confident my experience building production-ready devices, optimizing resource-constrained systems, and supporting manufacturing would make me a strong contributor to your team. I look forward to hearing from you."

---

## 📧 FOLLOW-UP EMAIL TEMPLATE

Subject: Thank you - Embedded Firmware Engineer Interview

Hi [Interviewer Name],

Thank you for taking the time to meet with me today. I enjoyed learning about [specific topic they discussed—e.g., your firmware architecture for safety-critical systems] and discussing how my experience with [specific relevant experience—e.g., device driver development and manufacturing test automation] aligns with your needs.

Our conversation about [specific challenge they mentioned] particularly resonated with me. My work on [your relevant project—e.g., Smart Shoe power optimization] demonstrates similar problem-solving approaches that I believe would be valuable to your team.

I'm very excited about the opportunity to contribute to [Company]'s autonomous vehicle development and continue growing my expertise in safety-critical embedded systems.

Please let me know if you need any additional information. I look forward to hearing about next steps.

Best regards,
Roy

---

## 🧠 MENTAL RESET PHRASES

If you get stuck or nervous:
- "Let me think about that for a moment..." (pause 3 seconds)
- "That's a great question. To make sure I understand..." (clarify)
- "I haven't encountered that specific scenario, but here's how I'd approach it..."
- "Can you give me an example to make sure we're aligned?"

**Remember: They're evaluating your THINKING PROCESS, not expecting you to know everything.**

---

## 🎯 FINAL CONFIDENCE BOOST

**You Have:**
✅ 12 years solid embedded experience
✅ Recent hands-on project (Smart Shoe)
✅ Manufacturing test expertise
✅ Device driver development skills
✅ Cross-functional collaboration
✅ Strong fundamentals (C/C++, RTOS, hardware)

**You Need:**
📚 Automotive domain knowledge (learnable)
📚 ISO 26262 exposure (trainable)

**The Gap Is Bridgeable. Your Fundamentals Are Exactly What They Need.**

**Trust your preparation. You've got this!**

---

**🔴 CRITICAL REMINDERS:**
1. Use SPECIFIC NUMBERS in every story
2. Frame gaps as "excited to learn" not "lacking experience"
3. Emphasize TRANSFERABLE SKILLS from medical/IoT to automotive
4. Show ENTHUSIASM for autonomous vehicles
5. Ask THOUGHTFUL QUESTIONS about their technology

**Good luck, Roy! 🚀**
