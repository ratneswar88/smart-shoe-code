# Technical Deep-Dive: Critical Interview Topics
## Focus Areas: EOL Testing, Device Drivers, PCB Schematics

---

## 1. EOL TESTING & MANUFACTURING SUPPORT

### YOUR RESUME STRENGTHENING STRATEGY

**Current Resume Weakness:** Generic mentions of "EOL testing" without specifics.

**Enhanced Narrative You Should Prepare:**

#### Smart Shoe EOL Test Framework (Made Plus)

**Context Setup:**
"At Made Plus, I was responsible for defining and implementing the complete end-of-line testing framework for our Smart Shoe product. This involved close collaboration with hardware engineers, factory teams, and quality assurance."

**Test Specification Development:**

```
TEST CATEGORIES I DEFINED:

1. POWER-ON SELF-TEST (POST)
   - MCU initialization sequence verification
   - Flash memory integrity check (CRC32 over firmware image)
   - IMU sensor presence detection (I2C bus scan)
   - BLE stack initialization (Nordic SoftDevice version check)
   - Battery voltage validation (3.0V - 4.2V range)
   
2. PARAMETRIC TESTS
   - Current consumption:
     * Active mode: 75-85mA (BLE connected, IMU sampling at 100Hz)
     * Idle mode: 12-18mA (BLE disconnected, 10Hz sampling)
     * Sleep mode: <15µA (deep sleep, accelerometer wake-on-motion)
   - BLE radio performance:
     * RSSI threshold: > -70 dBm at 1 meter
     * Connection time: < 2 seconds
     * Data throughput: > 5KB/s
   - IMU accuracy:
     * Accelerometer offset: ±0.05g
     * Gyroscope offset: ±2 deg/s
   
3. FUNCTIONAL TESTS
   - Step detection accuracy: Compare against reference (treadmill test)
     * Target: ±5% error over 100 steps
   - Force sensor linearity: Apply known loads (50g, 100g, 200g)
     * Expected: R² > 0.98 across calibration range
   - Gait parameter extraction:
     * Cadence: Validate against metronome
     * Stance time ratio: Cross-check with video analysis
   
4. BOUNDARY CONDITION TESTS
   - Temperature extremes: -10°C to +60°C operation
   - Battery voltage range: 3.0V (low battery warning) to 4.2V (full charge)
   - Mechanical shock: Simulate drop from 1.2 meters
   - EMI susceptibility: Test near high-power motor (pump test)
```

**Test Code Development:**

```python
# AUTOMATED EOL TEST SCRIPT ARCHITECTURE

import serial
import time
import csv
import datetime

class SmartShoeEOL:
    def __init__(self, com_port, log_file):
        self.ser = serial.Serial(com_port, 115200, timeout=5)
        self.log = open(log_file, 'w', newline='')
        self.writer = csv.writer(self.log)
        self.test_results = {}
        
    def run_test_sequence(self, serial_number):
        """Execute complete EOL test sequence"""
        print(f"Testing unit: {serial_number}")
        self.test_results['serial'] = serial_number
        self.test_results['timestamp'] = datetime.datetime.now()
        
        # 1. POST Tests
        if not self.test_post():
            return self.fail_unit("POST failed")
            
        # 2. Parametric Tests
        if not self.test_current_consumption():
            return self.fail_unit("Current draw out of spec")
            
        # 3. Functional Tests
        if not self.test_imu_calibration():
            return self.fail_unit("IMU calibration failed")
            
        # 4. BLE Tests
        if not self.test_ble_connectivity():
            return self.fail_unit("BLE connection failed")
            
        # 5. Store calibration data
        self.store_calibration(serial_number)
        
        return self.pass_unit()
    
    def test_post(self):
        """Power-On Self-Test"""
        self.send_command("POST")
        response = self.read_response(timeout=3)
        
        # Expected response format:
        # POST:OK,FW:v1.2.3,HW:v2.0,IMU:OK,BLE:OK
        if "POST:OK" not in response:
            self.log_error(f"POST failed: {response}")
            return False
            
        # Parse individual component status
        components = response.split(',')
        for comp in components:
            if ":FAIL" in comp:
                self.log_error(f"Component failure: {comp}")
                return False
                
        return True
    
    def test_current_consumption(self):
        """Measure current in different power modes"""
        # Requires external power supply with current measurement
        # Example using Keysight N6705B via SCPI
        
        self.send_command("SET_MODE ACTIVE")
        time.sleep(1)  # Stabilization time
        i_active = self.measure_current()
        
        if not (75 <= i_active <= 85):  # mA
            self.log_error(f"Active current out of spec: {i_active}mA")
            return False
            
        self.send_command("SET_MODE SLEEP")
        time.sleep(1)
        i_sleep = self.measure_current()
        
        if i_sleep > 0.015:  # mA (15µA)
            self.log_error(f"Sleep current out of spec: {i_sleep}mA")
            return False
            
        self.test_results['current_active'] = i_active
        self.test_results['current_sleep'] = i_sleep
        return True
    
    def test_imu_calibration(self):
        """Verify IMU calibration and accuracy"""
        # Place unit on precision rotation platform
        # Test known orientations (0°, 90°, 180°, 270°)
        
        expected_orientations = [
            (0, 0, 0),      # Flat
            (90, 0, 0),     # Tilt forward
            (0, 90, 0),     # Tilt right
            (0, 0, 90)      # Rotate clockwise
        ]
        
        for expected_roll, expected_pitch, expected_yaw in expected_orientations:
            self.send_command(f"READ_ORIENTATION")
            response = self.read_response()
            
            # Parse: "ORIENT:R=1.2,P=-0.5,Y=89.8"
            roll, pitch, yaw = self.parse_orientation(response)
            
            # Allow ±3° tolerance
            if abs(roll - expected_roll) > 3 or \
               abs(pitch - expected_pitch) > 3 or \
               abs(yaw - expected_yaw) > 3:
                self.log_error(f"Orientation error: Expected {expected_roll},{expected_pitch},{expected_yaw}, Got {roll},{pitch},{yaw}")
                return False
                
        return True
    
    def test_ble_connectivity(self):
        """Test BLE stack and connectivity"""
        self.send_command("BLE_ADVERTISE")
        
        # External BLE scanner (nRF Connect app or automation script)
        # Verify device appears in scan within 2 seconds
        # Attempt connection and verify GATT services
        
        # This would typically interface with external BLE test equipment
        # For now, verify firmware reports success
        response = self.read_response(timeout=5)
        
        if "BLE:CONNECTED" not in response:
            self.log_error("BLE connection failed")
            return False
            
        # Test data throughput
        self.send_command("BLE_STREAM_TEST 5000")  # 5KB test
        start_time = time.time()
        response = self.read_response(timeout=3)
        elapsed = time.time() - start_time
        
        throughput = 5000 / elapsed  # bytes/sec
        if throughput < 5000:  # 5KB/s minimum
            self.log_error(f"BLE throughput too low: {throughput:.0f} B/s")
            return False
            
        self.test_results['ble_throughput'] = throughput
        return True
    
    def store_calibration(self, serial_number):
        """Store calibration data in NVS flash"""
        # Calibration coefficients determined during test
        cal_data = {
            'accel_offset_x': self.test_results.get('accel_offset_x', 0),
            'accel_offset_y': self.test_results.get('accel_offset_y', 0),
            'accel_offset_z': self.test_results.get('accel_offset_z', 0),
            'force_sensor_slope': self.test_results.get('force_slope', 1.0),
            'force_sensor_offset': self.test_results.get('force_offset', 0),
            'serial_number': serial_number,
            'calibration_date': datetime.datetime.now().isoformat()
        }
        
        # Send calibration command
        cal_string = ','.join([f"{k}={v}" for k, v in cal_data.items()])
        self.send_command(f"STORE_CAL {cal_string}")
        
        response = self.read_response()
        if "CAL:STORED" not in response:
            self.log_error("Failed to store calibration")
            return False
            
        return True
    
    def pass_unit(self):
        """Mark unit as passed, log results"""
        self.test_results['status'] = 'PASS'
        self.writer.writerow(self.test_results.values())
        self.log.flush()
        
        # Trigger green LED on test fixture
        self.send_command("TEST_RESULT PASS")
        print(f"✓ Unit {self.test_results['serial']} PASSED")
        return True
    
    def fail_unit(self, reason):
        """Mark unit as failed, log failure reason"""
        self.test_results['status'] = 'FAIL'
        self.test_results['failure_reason'] = reason
        self.writer.writerow(self.test_results.values())
        self.log.flush()
        
        # Trigger red LED on test fixture
        self.send_command("TEST_RESULT FAIL")
        print(f"✗ Unit {self.test_results['serial']} FAILED: {reason}")
        return False

# USAGE
if __name__ == "__main__":
    tester = SmartShoeEOL('COM5', 'eol_test_log.csv')
    
    # Batch test loop
    while True:
        serial_number = input("Scan serial number (or 'quit'): ")
        if serial_number.lower() == 'quit':
            break
            
        tester.run_test_sequence(serial_number)
```

**Hardware Collaboration Story:**

"During development, I worked closely with our hardware engineer to implement design-for-test (DFT) features:

1. **Test Points:** I specified we needed UART TX/RX test points accessible via pogo pins in the test fixture. This eliminated the need for manual cable connection and reduced test time by 45 seconds per unit.

2. **Boot Mode Selection:** I requested a GPIO pin with pull-up resistor to enable 'factory mode' on power-up. When held low, the firmware enters a special test mode that disables normal operation and responds to factory test commands over UART.

3. **Visual Indicators:** I added firmware support for RGB LED sequences during testing:
   - Slow blue pulse: Test in progress
   - Solid green: PASS
   - Rapid red flash: FAIL
   This gave factory technicians immediate visual feedback.

4. **Calibration Storage:** I defined the NVS partition layout to store per-unit calibration data (IMU offsets, force sensor coefficients, unique serial number). This data is written during EOL test and read by firmware at runtime."

**Manufacturing Issue Resolution Story:**

"Three weeks into production, we saw a 12% failure rate on IMU initialization during POST. I flew to the factory to investigate:

**Root Cause Analysis:**
1. Reviewed test logs: Failures were sporadic, not correlated with serial number or time of day
2. Observed assembly process: Noticed reflow oven temperature profile varied by ±5°C
3. Examined failed units under microscope: Found cold solder joints on IMU pins
4. Hypothesis: Borderline reflow temperature causing intermittent poor solder joints

**Solution:**
1. **Immediate:** Updated test specification to include IMU communication stress test (1000 rapid read/write cycles) to catch marginal solder joints
2. **Long-term:** Worked with factory to adjust reflow profile (increased peak temperature by 8°C, extended dwell time)
3. **Firmware:** Added IMU initialization retry logic (3 attempts with 100ms delay) to handle transient failures

**Results:**
- Failure rate dropped to 2.1% within 2 weeks
- Field return rate decreased from 3% to 0.4%
- Developed expertise in reading reflow profiles and understanding PCB manufacturing constraints"

---

## 2. DEVICE DRIVER DEVELOPMENT

### COMPREHENSIVE DRIVER DEVELOPMENT EXAMPLE

**Scenario: Custom SPI ADC Driver for High-Speed Data Acquisition**

**Context:**
"At Novatec, I developed a device driver for the ADS8688 8-channel 16-bit ADC to interface with our STM32F4-based biomedical sensor. The application required simultaneous sampling of 8 analog signals at 10kHz per channel with sub-microsecond synchronization."

#### Phase 1: Requirements & Datasheet Analysis

```c
/* ADS8688 KEY SPECIFICATIONS (from datasheet):
 * 
 * Timing Constraints:
 * - SPI clock: Max 20 MHz
 * - CS setup time: Min 10ns
 * - CS hold time: Min 10ns
 * - Data readout time: 32 SCLK cycles
 * 
 * Register Map:
 * - 0x00: Sequence control (channel selection)
 * - 0x01: Auto-sequence enable
 * - 0x02-0x09: Input range per channel
 * - 0x0A: Power down mode
 * 
 * Conversion Timing:
 * - Conversion time: 1.5 µs typical
 * - Multi-channel sequential: 12 µs for 8 channels
 */

// DESIGN DECISIONS:
// 1. Use SPI with DMA for zero-copy data transfer
// 2. Double-buffering to avoid data loss during processing
// 3. Hardware timer trigger for precise sampling intervals
// 4. Interrupt-driven callback for new data ready
```

#### Phase 2: HAL Layer Implementation

```c
/******************************************************************************
 * FILE: ads8688_hal.c
 * DESCRIPTION: Hardware Abstraction Layer for ADS8688 SPI ADC
 ******************************************************************************/

#include "ads8688_hal.h"
#include "stm32f4xx_hal.h"

/* SPI Configuration */
static SPI_HandleTypeDef hspi2;
static DMA_HandleTypeDef hdma_spi2_tx;
static DMA_HandleTypeDef hdma_spi2_rx;

/* GPIO Definitions */
#define ADC_CS_PIN       GPIO_PIN_12
#define ADC_CS_PORT      GPIOB
#define ADC_CS_LOW()     HAL_GPIO_WritePin(ADC_CS_PORT, ADC_CS_PIN, GPIO_PIN_RESET)
#define ADC_CS_HIGH()    HAL_GPIO_WritePin(ADC_CS_PORT, ADC_CS_PIN, GPIO_PIN_SET)

/* DMA Buffer Management */
#define BUFFER_SIZE      16  // 8 channels * 2 bytes per sample
static uint8_t dma_buffer_a[BUFFER_SIZE];
static uint8_t dma_buffer_b[BUFFER_SIZE];
static uint8_t *active_buffer = dma_buffer_a;
static uint8_t *processing_buffer = dma_buffer_b;

/* Callback function pointer */
static void (*data_ready_callback)(uint16_t *samples) = NULL;

/******************************************************************************
 * FUNCTION: ADS8688_HAL_Init
 * DESCRIPTION: Initialize SPI peripheral and DMA
 ******************************************************************************/
HAL_StatusTypeDef ADS8688_HAL_Init(void)
{
    /* Configure SPI2 */
    hspi2.Instance = SPI2;
    hspi2.Init.Mode = SPI_MODE_MASTER;
    hspi2.Init.Direction = SPI_DIRECTION_2LINES;
    hspi2.Init.DataSize = SPI_DATASIZE_8BIT;
    hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;    // CPOL = 0
    hspi2.Init.CLKPhase = SPI_PHASE_2EDGE;        // CPHA = 1
    hspi2.Init.NSS = SPI_NSS_SOFT;
    hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;  // 84MHz/8 = 10.5MHz
    hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
    hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
    hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
    
    if (HAL_SPI_Init(&hspi2) != HAL_OK) {
        return HAL_ERROR;
    }
    
    /* Configure DMA for SPI RX */
    hdma_spi2_rx.Instance = DMA1_Stream3;
    hdma_spi2_rx.Init.Channel = DMA_CHANNEL_0;
    hdma_spi2_rx.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_spi2_rx.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_spi2_rx.Init.MemInc = DMA_MINC_ENABLE;
    hdma_spi2_rx.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_spi2_rx.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_spi2_rx.Init.Mode = DMA_CIRCULAR;  // Continuous acquisition
    hdma_spi2_rx.Init.Priority = DMA_PRIORITY_HIGH;
    hdma_spi2_rx.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    
    if (HAL_DMA_Init(&hdma_spi2_rx) != HAL_OK) {
        return HAL_ERROR;
    }
    
    __HAL_LINKDMA(&hspi2, hdmarx, hdma_spi2_rx);
    
    /* Enable DMA interrupts */
    HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 5, 0);
    HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
    
    /* Configure CS pin as output */
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin = ADC_CS_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(ADC_CS_PORT, &GPIO_InitStruct);
    
    ADC_CS_HIGH();  // Idle state
    
    return HAL_OK;
}

/******************************************************************************
 * FUNCTION: ADS8688_WriteRegister
 * DESCRIPTION: Write to device register via SPI
 ******************************************************************************/
HAL_StatusTypeDef ADS8688_WriteRegister(uint8_t reg_addr, uint8_t value)
{
    uint8_t tx_data[2];
    
    tx_data[0] = reg_addr | 0x80;  // Bit 7 = 1 for write
    tx_data[1] = value;
    
    ADC_CS_LOW();
    
    HAL_StatusTypeDef status = HAL_SPI_Transmit(&hspi2, tx_data, 2, 100);
    
    ADC_CS_HIGH();
    
    return status;
}

/******************************************************************************
 * FUNCTION: ADS8688_ReadRegister
 * DESCRIPTION: Read from device register via SPI
 ******************************************************************************/
HAL_StatusTypeDef ADS8688_ReadRegister(uint8_t reg_addr, uint8_t *value)
{
    uint8_t tx_data[2] = {reg_addr & 0x7F, 0x00};  // Bit 7 = 0 for read
    uint8_t rx_data[2];
    
    ADC_CS_LOW();
    
    HAL_StatusTypeDef status = HAL_SPI_TransmitReceive(&hspi2, tx_data, rx_data, 2, 100);
    
    ADC_CS_HIGH();
    
    if (status == HAL_OK) {
        *value = rx_data[1];
    }
    
    return status;
}

/******************************************************************************
 * FUNCTION: ADS8688_StartAcquisition
 * DESCRIPTION: Start DMA-based continuous data acquisition
 ******************************************************************************/
HAL_StatusTypeDef ADS8688_StartAcquisition(void (*callback)(uint16_t *))
{
    data_ready_callback = callback;
    
    /* Configure auto-sequence mode for all 8 channels */
    ADS8688_WriteRegister(0x01, 0xFF);  // Enable all channels
    
    /* Start DMA circular transfer */
    ADC_CS_LOW();
    HAL_StatusTypeDef status = HAL_SPI_Receive_DMA(&hspi2, active_buffer, BUFFER_SIZE);
    
    return status;
}

/******************************************************************************
 * FUNCTION: HAL_SPI_RxCpltCallback
 * DESCRIPTION: DMA transfer complete callback (called from IRQ)
 ******************************************************************************/
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi)
{
    if (hspi == &hspi2) {
        /* Swap buffers */
        uint8_t *temp = active_buffer;
        active_buffer = processing_buffer;
        processing_buffer = temp;
        
        /* Convert raw bytes to 16-bit samples */
        uint16_t samples[8];
        for (int i = 0; i < 8; i++) {
            samples[i] = (processing_buffer[i*2] << 8) | processing_buffer[i*2 + 1];
        }
        
        /* Notify application via callback */
        if (data_ready_callback) {
            data_ready_callback(samples);
        }
    }
}

/******************************************************************************
 * FUNCTION: DMA1_Stream3_IRQHandler
 * DESCRIPTION: DMA interrupt handler
 ******************************************************************************/
void DMA1_Stream3_IRQHandler(void)
{
    HAL_DMA_IRQHandler(&hdma_spi2_rx);
}
```

#### Phase 3: Driver API Layer

```c
/******************************************************************************
 * FILE: ads8688_driver.c
 * DESCRIPTION: High-level driver API for ADS8688
 ******************************************************************************/

#include "ads8688_driver.h"
#include "ads8688_hal.h"
#include <string.h>

/* Driver state */
typedef struct {
    bool initialized;
    bool acquiring;
    uint16_t sample_buffer[8][1024];  // Circular buffer per channel
    uint16_t buffer_head;
    ADS8688_Config_t config;
    ADS8688_ErrorCallback_t error_callback;
} ADS8688_Driver_t;

static ADS8688_Driver_t driver = {0};

/******************************************************************************
 * FUNCTION: ADS8688_Init
 * DESCRIPTION: Initialize driver with configuration
 ******************************************************************************/
ADS8688_Status_t ADS8688_Init(const ADS8688_Config_t *config)
{
    if (driver.initialized) {
        return ADS8688_ERROR_ALREADY_INITIALIZED;
    }
    
    /* Initialize HAL layer */
    if (ADS8688_HAL_Init() != HAL_OK) {
        return ADS8688_ERROR_HAL_INIT;
    }
    
    /* Store configuration */
    memcpy(&driver.config, config, sizeof(ADS8688_Config_t));
    
    /* Configure input ranges per channel */
    for (int ch = 0; ch < 8; ch++) {
        uint8_t range_reg = 0x02 + ch;
        ADS8688_WriteRegister(range_reg, driver.config.input_ranges[ch]);
    }
    
    /* Reset device */
    ADS8688_WriteRegister(0x00, 0x01);  // Software reset
    HAL_Delay(10);
    
    /* Verify communication */
    uint8_t device_id;
    if (ADS8688_ReadRegister(0x00, &device_id) != HAL_OK) {
        return ADS8688_ERROR_COMMUNICATION;
    }
    
    driver.initialized = true;
    driver.buffer_head = 0;
    
    return ADS8688_OK;
}

/******************************************************************************
 * FUNCTION: ADS8688_Start
 * DESCRIPTION: Start data acquisition
 ******************************************************************************/
ADS8688_Status_t ADS8688_Start(void)
{
    if (!driver.initialized) {
        return ADS8688_ERROR_NOT_INITIALIZED;
    }
    
    if (driver.acquiring) {
        return ADS8688_ERROR_ALREADY_RUNNING;
    }
    
    /* Start acquisition with internal callback */
    if (ADS8688_StartAcquisition(ADS8688_DataReadyCallback) != HAL_OK) {
        return ADS8688_ERROR_HAL;
    }
    
    driver.acquiring = true;
    return ADS8688_OK;
}

/******************************************************************************
 * FUNCTION: ADS8688_DataReadyCallback
 * DESCRIPTION: Internal callback for new data (called from HAL layer)
 ******************************************************************************/
static void ADS8688_DataReadyCallback(uint16_t *samples)
{
    /* Store samples in circular buffer */
    for (int ch = 0; ch < 8; ch++) {
        driver.sample_buffer[ch][driver.buffer_head] = samples[ch];
    }
    
    driver.buffer_head = (driver.buffer_head + 1) % 1024;
    
    /* Check for overrun */
    if (driver.buffer_head == 0) {
        if (driver.error_callback) {
            driver.error_callback(ADS8688_ERROR_BUFFER_OVERRUN);
        }
    }
}

/******************************************************************************
 * FUNCTION: ADS8688_GetSamples
 * DESCRIPTION: Retrieve samples from buffer (thread-safe)
 ******************************************************************************/
ADS8688_Status_t ADS8688_GetSamples(uint8_t channel, uint16_t *dest, uint16_t count)
{
    if (channel >= 8) {
        return ADS8688_ERROR_INVALID_CHANNEL;
    }
    
    if (count > 1024) {
        return ADS8688_ERROR_INVALID_SIZE;
    }
    
    /* Critical section to prevent buffer corruption */
    __disable_irq();
    
    uint16_t read_head = (driver.buffer_head >= count) ? 
                         (driver.buffer_head - count) : 
                         (1024 + driver.buffer_head - count);
    
    for (uint16_t i = 0; i < count; i++) {
        dest[i] = driver.sample_buffer[channel][read_head];
        read_head = (read_head + 1) % 1024;
    }
    
    __enable_irq();
    
    return ADS8688_OK;
}
```

#### Debugging Story You Can Tell

**"During initial testing, I encountered intermittent SPI communication failures—about 1 in every 500 transactions would fail with garbage data. Here's how I debugged it:

1. **Oscilloscope Analysis:**
   - Probed CS, CLK, MISO, MOSI signals
   - Noticed occasional glitch on MISO line (brief high-impedance state)
   - Measured CS timing: setup time was 8ns (datasheet requires min 10ns)

2. **Root Cause:**
   - STM32 GPIO switching from high to low takes ~5ns
   - SPI peripheral starts clocking immediately after CS assertion
   - Violated tSETUP specification by 2ns

3. **Solution:**
   - Added `__NOP()` instruction (2 CPU cycles @ 168MHz = 12ns) between CS assertion and SPI transaction
   - Updated timing to meet spec with margin

4. **Verification:**
   - Ran 1 million transaction stress test: zero failures
   - Validated timing on oscilloscope: 15ns CS setup time"**

---

## 3. PCB SCHEMATICS REVIEW & COLLABORATION

### SCHEMATIC READING CHECKLIST

When reviewing a PCB schematic for firmware implications:

```
POWER SUPPLY SECTION:
□ Input voltage range matches firmware ADC monitoring
□ Load switches have firmware control pins
□ Enable sequencing order documented (e.g., 3.3V before 1.8V)
□ Power-good signals connected to GPIO for detection
□ Brownout voltage threshold matches firmware BOD configuration

MICROCONTROLLER:
□ Boot mode pins (BOOT0, BOOT1) accessible for factory programming
□ Debug port (SWD/JTAG) exposed with proper pull-ups/pull-downs
□ External crystal frequency matches clock tree configuration
□ Load capacitors correct for crystal ESR (typically 10-20pF)
□ NRST pin has proper RC reset circuit (10kΩ + 100nF typical)

PERIPHERAL INTERFACES:
□ I2C pull-up resistors sized correctly (2.2kΩ-4.7kΩ for 3.3V, 400kHz)
□ SPI chip-select lines have pull-up to prevent spurious selection
□ UART TX/RX crossed correctly (MCU TX → peripheral RX)
□ CAN transceiver termination resistor (120Ω) present
□ Series resistors on high-speed signals (22Ω-47Ω for impedance matching)

SENSORS:
□ Sensor I2C address matches firmware driver (check A0/A1 pins)
□ Sensor power can be controlled by firmware (enable pin)
□ Interrupt pins connected with proper pull-up/pull-down
□ Analog sensor signals have RC filtering (prevent aliasing)

INDICATORS:
□ LED current limiting resistors calculated correctly
□ GPIO drive strength sufficient for LED current (typically 2-8mA)
□ Active-high vs active-low LED configuration documented

TEST POINTS:
□ UART TX/RX accessible for factory programming
□ Voltage rails have test points for power measurement
□ Critical signals have test points for debugging (I2C SCL/SDA, SPI CLK/MISO/MOSI)
```

### HARDWARE COLLABORATION EXAMPLES

#### Example 1: Power Sequencing Issue

**Situation:**
"During Smart Shoe bring-up, IMU initialization failed randomly on power-up. Hardware engineer confirmed 3.3V rail was stable, but I suspected power sequencing issue."

**Investigation:**
- Reviewed schematic: Found separate LDOs for MCU (3.3V) and IMU (3.3V)
- MCU LDO: Enable tied to VBAT (always on)
- IMU LDO: Enable controlled by GPIO
- **Problem:** Firmware tried to initialize IMU before LDO stabilized (need 2ms)

**Solution:**
- Added 5ms delay after asserting IMU_EN pin
- Requested hardware change: Add RC delay circuit (10kΩ + 1µF = 10ms) on IMU enable to guarantee sequencing without firmware delay

**Result:**
- Zero IMU initialization failures in subsequent builds
- Learned importance of power sequencing timing margins

#### Example 2: I2C Pull-Up Resistor Selection

**Situation:**
"Hardware engineer asked me to review I2C bus design. Schematic showed 2.2kΩ pull-ups."

**Analysis:**
```
I2C bus characteristics:
- Bus voltage: 3.3V
- Clock frequency: 400kHz (Fast Mode)
- Total capacitance: 3 devices × 10pF + PCB trace (est. 50pF) = 80pF

Rise time calculation:
t_rise = 2.2 × R_pull × C_bus
t_rise = 2.2 × 2200Ω × 80pF = 387ns

Fast Mode I2C spec: t_rise(max) = 300ns + 0.1 × C_bus
= 300ns + 0.1 × 80pF = 308ns

PROBLEM: Rise time too slow (387ns > 308ns)
```

**Recommendation:**
- Reduce pull-up to 1.5kΩ: t_rise = 2.2 × 1500 × 80pF = 264ns ✓
- Verify current consumption acceptable: I_pull = 3.3V / 1500Ω = 2.2mA (acceptable)

**Collaboration:**
- Discussed trade-off: Lower resistor = faster rise time but higher power
- Agreed on 1.8kΩ as compromise (t_rise = 316ns, marginal but acceptable)
- Tested on prototype: I2C communication reliable up to 400kHz

#### Example 3: Firmware-Driven Hardware Requirements

**Situation:**
"Designing power management for Smart Shoe. Hardware engineer asked how firmware would handle power modes."

**Firmware Requirements I Provided:**

```
POWER MODE DEFINITION:

1. ACTIVE MODE (Motion Detected, BLE Connected)
   - IMU: 100Hz sampling
   - Force sensors: 50Hz sampling
   - BLE: Continuous connection
   - MCU: Run mode @ 80MHz
   - Expected current: ~75mA
   
2. IDLE MODE (No Motion, BLE Connected)
   - IMU: 10Hz sampling (accelerometer only)
   - Force sensors: OFF
   - BLE: Connection maintained with extended interval
   - MCU: Run mode @ 20MHz
   - Expected current: ~15mA
   
3. SLEEP MODE (No Motion, No BLE)
   - IMU: Accelerometer wake-on-motion interrupt
   - Force sensors: OFF
   - BLE: Advertising only (1Hz)
   - MCU: Deep sleep, wake on interrupt
   - Expected current: <20µA

HARDWARE REQUIREMENTS:
□ Load switch on IMU power rail (firmware-controlled)
□ Load switch on force sensor excitation voltage
□ BLE module with hardware sleep mode
□ MCU can enter deep sleep while maintaining RTC
□ Accelerometer interrupt pin connected to wake-capable GPIO
```

**Hardware Implementation:**
- Added TPS22916 load switches (0.5Ω Ron, <1µA leakage)
- Connected IMU INT pin to EXTI-capable GPIO
- Used Nordic nRF52 with automatic power management

---

## INTERVIEW QUESTION PRACTICE

### Q1: "Walk me through your process for developing a device driver from scratch."

**Your Answer:**

"My device driver development follows a structured 6-step process:

**Step 1: Requirements & Datasheet Analysis (1-2 days)**
- Read device datasheet cover-to-cover, focusing on:
  * Electrical characteristics (voltage levels, current draw)
  * Timing diagrams (setup/hold times, clock constraints)
  * Register map (configuration, status, data registers)
  * Communication protocol specifics (I2C address, SPI mode)
- Identify critical constraints (e.g., CS setup time, conversion delay)

**Step 2: Architecture Design (1 day)**
- Define driver layers:
  * HAL: Raw register read/write, pin control
  * Driver: State machine, error handling, data processing
  * API: Application-facing functions
- Choose communication method: Polling, interrupt, or DMA
- Design buffer management strategy (single, double-buffer, circular)

**Step 3: HAL Implementation (2-3 days)**
- Write low-level functions: Initialize peripheral, read/write registers
- Test each function in isolation with oscilloscope/logic analyzer
- Verify timing constraints meet datasheet specifications

**Step 4: Driver Layer (3-5 days)**
- Implement configuration, start/stop, data acquisition
- Add error detection: timeout, CRC check, bounds validation
- Write unit tests for edge cases

**Step 5: Integration & Testing (2-3 days)**
- Integrate with RTOS (if applicable)
- Stress testing: continuous operation, power cycling, error injection
- Performance profiling: CPU usage, memory footprint, latency

**Step 6: Documentation (1 day)**
- API reference with usage examples
- Known limitations and workarounds
- Integration guide for other developers

**Example from my experience:** For the ADS8688 ADC driver at Novatec, this process took about 2 weeks from datasheet to production-ready code. The key was spending extra time in Step 1—catching a CS timing violation early saved days of debugging later."

### Q2: "How do you collaborate with hardware engineers when there's a hardware-firmware interface issue?"

**Your Answer:**

"Effective hardware-firmware collaboration requires:

**1. Joint Debugging Sessions:**
When issues arise, I schedule real-time debugging with the hardware engineer. For example, during Smart Shoe development, we had intermittent IMU failures. Rather than exchanging emails, we spent 2 hours together:
- I probed firmware behavior (I2C transactions, error logs)
- HW engineer measured signals (oscilloscope, power rails)
- Together we found voltage sag during force sensor activation

**2. Shared Language:**
I make effort to understand hardware terminology:
- Can read schematics and identify components (LDO, load switch, pull-up)
- Understand signal integrity concepts (rise time, loading, impedance)
- Speak in hardware terms: "I need 10ns CS setup time" vs "CS isn't working"

**3. Clear Requirements Documentation:**
Before hardware design, I provide firmware requirements document:
- GPIO assignments and electrical requirements (push-pull vs open-drain)
- Timing constraints (SPI clock frequency, interrupt latency)
- Power consumption targets for each mode
- Testability features (UART boot mode, test points)

**4. Early Prototype Testing:**
I work with initial prototypes (even hand-soldered) to validate interfaces early:
- Catch design issues before PCB fab (e.g., wrong I2C pull-up value)
- Provide feedback on layout (test point accessibility, signal routing)

**5. Respectful Collaboration:**
I recognize hardware and firmware are interdependent:
- Avoid blaming: 'The hardware is wrong'
- Instead: 'I noticed the rise time is 350ns. I2C spec requires <300ns. Can we reduce pull-up to 1.5kΩ?'
- Acknowledge trade-offs and work toward compromise

This approach has made me an effective bridge between hardware and firmware teams throughout my career."

---

## FINAL PREPARATION CHECKLIST

**Manufacturing/EOL Testing:**
- [ ] Memorize your Smart Shoe EOL test categories
- [ ] Prepare the "12% failure rate" story with specific numbers
- [ ] Have the test code architecture ready to explain

**Device Drivers:**
- [ ] Can you draw the ADS8688 driver architecture on whiteboard?
- [ ] Practice explaining DMA buffer swapping without notes
- [ ] Have the "CS timing violation" debugging story ready

**PCB Schematics:**
- [ ] Review your Smart Shoe schematic (if you have it)
- [ ] Can you explain I2C pull-up calculation?
- [ ] Have power sequencing story ready

**Communication:**
- [ ] Practice saying "I haven't worked with X, but I understand the principles and here's how I'd approach it"
- [ ] Use numbers: "12% failure rate reduced to 2.1%", "battery life improved 3x"
- [ ] STAR method (Situation, Task, Action, Result) for all stories

**You're ready. These are your strongest areas—lean into them confidently.**
