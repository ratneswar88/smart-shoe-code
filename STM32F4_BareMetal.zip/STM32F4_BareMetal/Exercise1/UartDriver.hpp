/**
 * @file UartDriver.hpp
 * @brief Bare Metal UART Driver with Detailed Explanations
 * 
 * =============================================================================
 * WHAT IS BARE METAL?
 * =============================================================================
 * Bare metal means programming the microcontroller without an operating system.
 * You directly control hardware registers and handle interrupts yourself.
 * 
 * ADVANTAGES:
 * - Full control over hardware
 * - Deterministic timing
 * - Minimal code size and RAM usage
 * - No RTOS overhead
 * 
 * CHALLENGES:
 * - Must manage everything yourself (no task scheduler)
 * - Interrupt handling requires care
 * - Resource management is manual
 * 
 * =============================================================================
 * UART COMMUNICATION
 * =============================================================================
 * UART sends data serially (one bit at a time) over two wires:
 * - TX (Transmit): Sends data from this device
 * - RX (Receive): Receives data from another device
 * 
 * NO CLOCK WIRE: Both devices must agree on baud rate (bits/second)
 * 
 * DATA FRAME (8N1 - most common):
 *    Start  D0  D1  D2  D3  D4  D5  D6  D7  Stop
 *    ──┐  ┌───────────────────────────┐  ┌────
 *      └──┘                           └──┘
 * 
 * - Start bit: Logic 0 (signals start of byte)
 * - 8 data bits: LSB first
 * - Stop bit: Logic 1 (signals end of byte)
 * - No parity bit (that's the "N" in 8N1)
 * 
 * =============================================================================
 * STM32F4 UART HARDWARE
 * =============================================================================
 * The USART peripheral handles all the bit timing automatically!
 * We just:
 * 1. Configure the peripheral (baud rate, format)
 * 2. Write bytes to DR register to transmit
 * 3. Read bytes from DR register when received
 * 4. Use flags in SR register to know when ready
 * 
 * KEY REGISTERS:
 * - SR (Status Register): Flags for TX/RX status
 * - DR (Data Register): Write to send, read to receive
 * - BRR (Baud Rate Register): Sets communication speed
 * - CR1/CR2/CR3 (Control Registers): Configuration
 */

#ifndef UART_DRIVER_HPP
#define UART_DRIVER_HPP

#include <cstdint>
#include <cstring>

/**
 * =============================================================================
 * MEMORY-MAPPED REGISTERS
 * =============================================================================
 * In microcontrollers, peripherals are controlled by "registers" - special
 * memory locations that control hardware behavior.
 * 
 * When you write to these addresses, you're directly controlling hardware!
 * 
 * Example: Writing 0x41 ('A') to USART2->DR at address 0x40004404
 * causes the UART hardware to transmit the byte 'A' on the TX pin.
 * 
 * The "volatile" keyword tells the compiler:
 * "This value can change unexpectedly (by hardware), so don't optimize it away!"
 */

// USART2 Register Structure at address 0x40004400
struct USART_Registers {
    volatile uint32_t SR;   // 0x00: Status Register - read hardware status
    volatile uint32_t DR;   // 0x04: Data Register - write to send, read to receive
    volatile uint32_t BRR;  // 0x08: Baud Rate Register - sets communication speed
    volatile uint32_t CR1;  // 0x0C: Control Register 1 - main configuration
    volatile uint32_t CR2;  // 0x10: Control Register 2 - additional config
    volatile uint32_t CR3;  // 0x14: Control Register 3 - flow control
    volatile uint32_t GTPR; // 0x18: Guard time and prescaler
};

// Cast memory address to pointer - now we can access USART2 registers!
#define USART2 ((USART_Registers*)0x40004400)

// Status Register (SR) bit definitions
#define USART_SR_TXE    (1U << 7)  // Transmit Data Register Empty
#define USART_SR_TC     (1U << 6)  // Transmission Complete
#define USART_SR_RXNE   (1U << 5)  // Read Data Register Not Empty

// Control Register 1 (CR1) bit definitions
#define USART_CR1_UE    (1U << 13) // USART Enable
#define USART_CR1_TE    (1U << 3)  // Transmitter Enable
#define USART_CR1_RE    (1U << 2)  // Receiver Enable
#define USART_CR1_RXNEIE (1U << 5) // RXNE Interrupt Enable

// RCC (Reset and Clock Control) - controls peripheral clocks
struct RCC_Registers {
    volatile uint32_t CR;
    volatile uint32_t PLLCFGR;
    volatile uint32_t CFGR;
    volatile uint32_t CIR;
    volatile uint32_t AHB1RSTR;
    volatile uint32_t AHB2RSTR;
    volatile uint32_t AHB3RSTR;
    volatile uint32_t RESERVED0;
    volatile uint32_t APB1RSTR;
    volatile uint32_t APB2RSTR;
    volatile uint32_t RESERVED1[2];
    volatile uint32_t AHB1ENR;   // AHB1 peripheral clock enable
    volatile uint32_t AHB2ENR;
    volatile uint32_t AHB3ENR;
    volatile uint32_t RESERVED2;
    volatile uint32_t APB1ENR;   // APB1 peripheral clock enable
};

#define RCC ((RCC_Registers*)0x40023800)
#define RCC_AHB1ENR_GPIOAEN  (1U << 0)  // Enable GPIOA clock
#define RCC_APB1ENR_USART2EN (1U << 17) // Enable USART2 clock

// GPIO Register Structure
struct GPIO_Registers {
    volatile uint32_t MODER;   // Mode register
    volatile uint32_t OTYPER;  // Output type
    volatile uint32_t OSPEEDR; // Output speed
    volatile uint32_t PUPDR;   // Pull-up/pull-down
    volatile uint32_t IDR;     // Input data
    volatile uint32_t ODR;     // Output data
    volatile uint32_t BSRR;    // Bit set/reset
    volatile uint32_t LCKR;    // Lock
    volatile uint32_t AFR[2];  // Alternate function
};

#define GPIOA ((GPIO_Registers*)0x40020000)

/**
 * =============================================================================
 * CIRCULAR BUFFER EXPLANATION
 * =============================================================================
 * A circular buffer (ring buffer) is perfect for UART reception because:
 * 
 * 1. FIXED SIZE: No dynamic allocation - safe for embedded
 * 2. CONTINUOUS OPERATION: Never "fills up" - old data wraps around
 * 3. INTERRUPT-SAFE: Producer (ISR) and consumer (main) don't interfere
 * 
 * HOW IT WORKS:
 *    ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
 *    │  A  │  B  │  C  │     │     │     │     │     │  Buffer
 *    └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘
 *       ↑                 ↑
 *      tail             head
 * 
 * - head: Where next byte will be written (by interrupt)
 * - tail: Where next byte will be read (by main code)
 * - Empty when head == tail
 * - Full when (head + 1) % SIZE == tail
 * 
 * THREAD SAFETY:
 * - Only ISR modifies head
 * - Only main code modifies tail
 * - No race conditions!
 */

class UartDriver {
public:
    /**
     * Constructor - DOESN'T initialize hardware yet
     * 
     * RAII (Resource Acquisition Is Initialization):
     * The constructor just saves parameters. Hardware init happens in init().
     * 
     * WHY?
     * - Construction might happen before clock is initialized
     * - Allows explicit control of initialization order
     * - Can check init() return value for errors
     */
    explicit UartDriver()
        : rx_head_(0)
        , rx_tail_(0)
    {
        // Initialize buffer to zeros
        std::memset(rx_buffer_, 0, RX_BUFFER_SIZE);
    }
    
    /**
     * Initialize UART hardware
     * 
     * INITIALIZATION SEQUENCE (ORDER MATTERS!):
     * 1. Enable peripheral clocks (USART and GPIO)
     * 2. Configure GPIO pins for UART alternate function
     * 3. Calculate and set baud rate
     * 4. Configure UART (8N1 format)
     * 5. Enable transmitter and receiver
     * 6. Enable UART peripheral
     * 7. Enable receive interrupt
     */
    void init(uint32_t baudrate = 115200) {
        // =====================================================================
        // STEP 1: Enable clocks
        // =====================================================================
        // CRITICAL: Peripherals are clock-gated by default to save power!
        // You MUST enable clock before accessing peripheral registers!
        
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;  // Enable GPIOA clock
        RCC->APB1ENR |= RCC_APB1ENR_USART2EN; // Enable USART2 clock
        
        // Small delay to ensure clock is stable
        volatile uint32_t dummy = RCC->APB1ENR;
        (void)dummy;
        
        // =====================================================================
        // STEP 2: Configure GPIO pins for UART
        // =====================================================================
        /**
         * USART2 pins on STM32F407:
         * - PA2: USART2_TX (Alternate Function 7)
         * - PA3: USART2_RX (Alternate Function 7)
         * 
         * GPIO configuration involves multiple registers:
         * 
         * MODER (Mode Register) - 2 bits per pin:
         *   00 = Input
         *   01 = Output
         *   10 = Alternate Function ← We need this
         *   11 = Analog
         * 
         * For pin 2: bits [5:4]
         * For pin 3: bits [7:6]
         */
        
        // PA2 and PA3 to Alternate Function mode
        GPIOA->MODER &= ~((0b11 << (2*2)) | (0b11 << (3*2))); // Clear bits
        GPIOA->MODER |=  ((0b10 << (2*2)) | (0b10 << (3*2))); // Set to AF
        
        /**
         * OSPEEDR (Output Speed Register) - 2 bits per pin:
         *   00 = Low speed (2 MHz)
         *   01 = Medium speed (25 MHz)
         *   10 = Fast speed (50 MHz)
         *   11 = High speed (100 MHz)
         * 
         * For UART, medium speed is sufficient
         */
        GPIOA->OSPEEDR &= ~((0b11 << (2*2)) | (0b11 << (3*2)));
        GPIOA->OSPEEDR |=  ((0b01 << (2*2)) | (0b01 << (3*2)));
        
        /**
         * PUPDR (Pull-up/Pull-down Register) - 2 bits per pin:
         *   00 = No pull-up/down
         *   01 = Pull-up
         *   10 = Pull-down
         * 
         * RX should have pull-up to keep line high when idle
         */
        GPIOA->PUPDR &= ~((0b11 << (2*2)) | (0b11 << (3*2)));
        GPIOA->PUPDR |=  (0b01 << (3*2)); // Pull-up on PA3 (RX)
        
        /**
         * AFR (Alternate Function Register) - 4 bits per pin:
         * AFR[0] (AFRL) controls pins 0-7
         * AFR[1] (AFRH) controls pins 8-15
         * 
         * Pin 2 uses bits [11:8] in AFR[0]
         * Pin 3 uses bits [15:12] in AFR[0]
         * 
         * AF7 = USART1/2/3
         */
        GPIOA->AFR[0] &= ~((0xF << (2*4)) | (0xF << (3*4))); // Clear
        GPIOA->AFR[0] |=  ((7 << (2*4)) | (7 << (3*4)));    // Set AF7
        
        // =====================================================================
        // STEP 3: Calculate and set baud rate
        // =====================================================================
        /**
         * BAUD RATE CALCULATION:
         * 
         * The BRR register determines baud rate:
         * Baud Rate = f_PCLK / (16 * BRR_value)
         * 
         * Therefore:
         * BRR_value = f_PCLK / (16 * Baud Rate)
         * 
         * For USART2 on APB1 @ 42 MHz, Baud = 115200:
         * BRR = 42,000,000 / (16 * 115,200) = 22.786
         * 
         * BRR register format:
         * [15:4] = Mantissa (integer part)
         * [3:0]  = Fraction (1/16ths)
         * 
         * 22.786 = 22 + 0.786
         * Fraction = 0.786 * 16 = 12.58 ≈ 13
         * 
         * BRR = (22 << 4) | 13 = 0x016D
         */
        
        uint32_t apb1_clock = 42000000;  // 42 MHz (typical for APB1)
        uint32_t brr_value = (apb1_clock + (baudrate * 8)) / (baudrate * 16);
        USART2->BRR = brr_value;
        
        // =====================================================================
        // STEP 4: Configure UART format (8N1)
        // =====================================================================
        /**
         * CR1 (Control Register 1):
         * 
         * Bit 13 (UE): USART Enable
         * Bit 12 (M): Word length (0 = 8 bits, 1 = 9 bits)
         * Bit 10 (PCE): Parity control (0 = disabled)
         * Bit 3 (TE): Transmitter enable
         * Bit 2 (RE): Receiver enable
         * Bit 5 (RXNEIE): RXNE interrupt enable
         * 
         * We want: 8 bits, no parity, TX/RX enabled, RX interrupt enabled
         */
        
        USART2->CR1 = 0;  // Clear all bits first
        USART2->CR1 |= USART_CR1_TE;      // Enable transmitter
        USART2->CR1 |= USART_CR1_RE;      // Enable receiver
        USART2->CR1 |= USART_CR1_RXNEIE;  // Enable RX interrupt
        
        /**
         * CR2 (Control Register 2):
         * Bits [13:12] STOP: Stop bits
         *   00 = 1 stop bit ← We want this
         *   01 = 0.5 stop bits
         *   10 = 2 stop bits
         *   11 = 1.5 stop bits
         */
        USART2->CR2 = 0;  // 1 stop bit (default)
        
        // CR3: No hardware flow control
        USART2->CR3 = 0;
        
        // =====================================================================
        // STEP 5: Enable USART
        // =====================================================================
        USART2->CR1 |= USART_CR1_UE;  // Enable USART
        
        // =====================================================================
        // STEP 6: Enable USART2 interrupt in NVIC
        // =====================================================================
        /**
         * NVIC (Nested Vectored Interrupt Controller):
         * Manages all interrupts in ARM Cortex-M4
         * 
         * Each interrupt has an "IRQ number"
         * USART2 = IRQ 38
         * 
         * NVIC_ISER (Interrupt Set-Enable Register):
         * There are multiple ISER registers (ISER[0], ISER[1], etc.)
         * Each register controls 32 interrupts
         * 
         * IRQ 38 is in ISER[1] (because 38 >= 32)
         * Bit position = 38 - 32 = 6
         */
        volatile uint32_t* NVIC_ISER1 = (uint32_t*)0xE000E104;
        *NVIC_ISER1 |= (1U << 6);  // Enable USART2 interrupt (IRQ 38)
    }
    
    /**
     * Transmit a byte
     * 
     * POLLING METHOD (simpler but blocks):
     * 1. Wait for TXE (Transmit Data Register Empty) flag
     * 2. Write byte to DR
     * 3. Hardware automatically:
     *    - Clears TXE flag
     *    - Sends start bit, 8 data bits, stop bit
     *    - Sets TXE flag when done
     */
    void write(uint8_t data) const {
        // Wait for transmit data register to be empty
        // TXE = 1 means "ready to accept new data"
        while (!(USART2->SR & USART_SR_TXE)) {
            // Busy-wait loop
            // In production, add timeout to prevent infinite loop!
        }
        
        // Write data to data register
        // Hardware takes over from here
        USART2->DR = data;
    }
    
    /**
     * Transmit a string
     */
    void writeString(const char* str) const {
        while (*str) {
            write(*str++);
        }
    }
    
    /**
     * Check if received data is available
     * 
     * INTERRUPT-DRIVEN RECEPTION:
     * - When byte arrives, hardware sets RXNE flag
     * - RXNE interrupt fires
     * - ISR reads DR and stores in circular buffer
     * - Main code calls available() to check buffer
     */
    bool available() const {
        return (rx_head_ != rx_tail_);
    }
    
    /**
     * Read a byte from circular buffer
     * 
     * THREAD SAFETY:
     * - Only main code modifies rx_tail_
     * - Only ISR modifies rx_head_
     * - No race condition!
     */
    uint8_t read() {
        if (!available()) {
            return 0;
        }
        
        uint8_t data = rx_buffer_[rx_tail_];
        rx_tail_ = (rx_tail_ + 1) % RX_BUFFER_SIZE;
        return data;
    }
    
    /**
     * Called by interrupt handler when byte received
     * 
     * CRITICAL: This runs in interrupt context!
     * - Keep it SHORT and FAST
     * - Don't call blocking functions
     * - Don't do complex processing
     */
    void rxInterruptHandler() {
        // Read data register (this clears RXNE flag)
        uint8_t data = USART2->DR & 0xFF;
        
        // Calculate next head position
        uint16_t next_head = (rx_head_ + 1) % RX_BUFFER_SIZE;
        
        // Check if buffer is full
        if (next_head != rx_tail_) {
            // Store byte in buffer
            rx_buffer_[rx_head_] = data;
            rx_head_ = next_head;
        }
        // else: buffer full, drop byte (or handle error)
    }
    
    // Make instance accessible to ISR
    static UartDriver* instance_;
    
private:
    static constexpr uint16_t RX_BUFFER_SIZE = 256;
    uint8_t rx_buffer_[RX_BUFFER_SIZE];
    volatile uint16_t rx_head_;  // Modified by ISR
    volatile uint16_t rx_tail_;  // Modified by main code
};

// Static instance pointer for ISR
UartDriver* UartDriver::instance_ = nullptr;

/**
 * =============================================================================
 * INTERRUPT HANDLER
 * =============================================================================
 * 
 * This function is called automatically by hardware when USART2 receives data.
 * 
 * FUNCTION NAME IS CRITICAL!
 * It must match the name in the vector table (startup code).
 * 
 * extern "C" is required because:
 * - C++ mangles function names for overloading
 * - The vector table expects C-style names
 * - extern "C" prevents name mangling
 */
extern "C" void USART2_IRQHandler() {
    if (UartDriver::instance_) {
        UartDriver::instance_->rxInterruptHandler();
    }
}

#endif // UART_DRIVER_HPP
