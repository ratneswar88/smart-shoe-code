#ifndef STM32F4_REGS_HPP
#define STM32F4_REGS_HPP

#include <cstdint>

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * STM32F4 BARE METAL REGISTER DEFINITIONS
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * WHAT IS "BARE METAL"?
 * ---------------------
 * Bare metal means programming directly to hardware without an operating system
 * or HAL (Hardware Abstraction Layer). You control EVERYTHING:
 * - Configure clocks manually
 * - Set up peripherals bit-by-bit
 * - Handle interrupts yourself
 * - Manage timing and delays
 * 
 * WHY BARE METAL?
 * ---------------
 * ✓ Maximum control and efficiency
 * ✓ Minimal code size and memory
 * ✓ Deterministic behavior (no RTOS overhead)
 * ✓ Learn how hardware REALLY works
 * ✓ Essential for deeply embedded systems
 * 
 * MEMORY-MAPPED I/O
 * -----------------
 * In microcontrollers, peripherals are controlled via "registers" - special
 * memory locations that connect directly to hardware.
 * 
 * When you write to address 0x40020014, you're not writing to RAM!
 * You're controlling GPIO hardware to turn an LED on/off.
 * 
 * Example:
 * *(volatile uint32_t*)0x40020014 = 0x1000;  // Turn on LED on PD12
 * 
 * VOLATILE KEYWORD
 * ----------------
 * "volatile" tells compiler: "This value can change unexpectedly!"
 * - Hardware can modify register values
 * - Interrupts can change variables
 * - Prevents compiler optimizations that would break hardware access
 * 
 * Without volatile, compiler might optimize away register reads!
 */

// ═════════════════════════════════════════════════════════════════════════════
// MEMORY MAP (STM32F407VG)
// ═════════════════════════════════════════════════════════════════════════════
/**
 * STM32F4 Memory Organization:
 * 
 * 0x0000 0000 ├─────────────────────┐
 *             │   Flash Memory      │ Program code, constants
 *             │   (1 MB)            │
 * 0x0800 0000 ├─────────────────────┤
 *             │   Reserved          │
 * 0x2000 0000 ├─────────────────────┤
 *             │   SRAM (128 KB)     │ Variables, stack, heap
 * 0x2002 0000 ├─────────────────────┤
 *             │   Reserved          │
 * 0x4000 0000 ├─────────────────────┤
 *             │   APB1 Peripherals  │ USART2, I2C1, TIM2-7, etc.
 * 0x4001 0000 ├─────────────────────┤
 *             │   APB2 Peripherals  │ USART1, SPI1, TIM1, ADC, etc.
 * 0x4002 0000 ├─────────────────────┤
 *             │   AHB1 Peripherals  │ GPIO, DMA, RCC, etc.
 * 0x5000 0000 ├─────────────────────┤
 *             │   AHB2 Peripherals  │ USB OTG, DCMI, etc.
 * 0xE000 0000 ├─────────────────────┤
 *             │   Cortex-M4 Core    │ NVIC, SysTick, Debug
 * 0xE010 0000 └─────────────────────┘
 */

// ═════════════════════════════════════════════════════════════════════════════
// RCC (RESET AND CLOCK CONTROL)
// ═════════════════════════════════════════════════════════════════════════════
/**
 * RCC controls ALL clocks in the STM32!
 * 
 * WHY CLOCK CONTROL?
 * ------------------
 * Every peripheral needs a clock to operate. By default, all peripheral clocks
 * are DISABLED to save power. Before using ANY peripheral, you MUST enable its
 * clock in RCC.
 * 
 * CLOCK TREE (simplified):
 * 
 *   HSE (8MHz)
 *       ↓
 *     PLL  →  SYSCLK (168 MHz)  →  AHB (168 MHz)  →  CPU, DMA
 *                                        ↓
 *                                   ┌────┴────┐
 *                                   ↓         ↓
 *                              APB1 (42)  APB2 (84)
 *                                   ↓         ↓
 *                            USART2,I2C   USART1,SPI
 * 
 * Registers at base address: 0x40023800
 */
struct RCC_Registers {
    volatile uint32_t CR;          // 0x00: Clock control (enables HSE, PLL)
    volatile uint32_t PLLCFGR;     // 0x04: PLL configuration
    volatile uint32_t CFGR;        // 0x08: Clock config (prescalers, mux)
    volatile uint32_t CIR;         // 0x0C: Clock interrupt
    volatile uint32_t AHB1RSTR;    // 0x10: AHB1 peripheral reset
    volatile uint32_t AHB2RSTR;    // 0x14: AHB2 peripheral reset
    volatile uint32_t AHB3RSTR;    // 0x18: AHB3 peripheral reset
    volatile uint32_t RESERVED0;   // 0x1C: Reserved
    volatile uint32_t APB1RSTR;    // 0x20: APB1 peripheral reset
    volatile uint32_t APB2RSTR;    // 0x24: APB2 peripheral reset
    volatile uint32_t RESERVED1[2];// 0x28-0x2C: Reserved
    volatile uint32_t AHB1ENR;     // 0x30: AHB1 peripheral clock enable ← IMPORTANT!
    volatile uint32_t AHB2ENR;     // 0x34: AHB2 peripheral clock enable
    volatile uint32_t AHB3ENR;     // 0x38: AHB3 peripheral clock enable
    volatile uint32_t RESERVED2;   // 0x3C: Reserved
    volatile uint32_t APB1ENR;     // 0x40: APB1 peripheral clock enable ← IMPORTANT!
    volatile uint32_t APB2ENR;     // 0x44: APB2 peripheral clock enable ← IMPORTANT!
};

#define RCC ((RCC_Registers*)0x40023800)

// RCC_AHB1ENR bits (GPIO clocks)
#define RCC_AHB1ENR_GPIOAEN  (1U << 0)   // Bit 0: Enable GPIOA clock
#define RCC_AHB1ENR_GPIOBEN  (1U << 1)   // Bit 1: Enable GPIOB clock
#define RCC_AHB1ENR_GPIOCEN  (1U << 2)   // Bit 2: Enable GPIOC clock
#define RCC_AHB1ENR_GPIODEN  (1U << 3)   // Bit 3: Enable GPIOD clock

// RCC_APB1ENR bits (slower peripherals)
#define RCC_APB1ENR_USART2EN (1U << 17)  // Bit 17: Enable USART2 clock
#define RCC_APB1ENR_I2C1EN   (1U << 21)  // Bit 21: Enable I2C1 clock
#define RCC_APB1ENR_I2C2EN   (1U << 22)  // Bit 22: Enable I2C2 clock

// RCC_APB2ENR bits (faster peripherals)
#define RCC_APB2ENR_USART1EN (1U << 4)   // Bit 4: Enable USART1 clock
#define RCC_APB2ENR_SPI1EN   (1U << 12)  // Bit 12: Enable SPI1 clock

// ═════════════════════════════════════════════════════════════════════════════
// GPIO (GENERAL PURPOSE INPUT/OUTPUT)
// ═════════════════════════════════════════════════════════════════════════════
/**
 * GPIO controls the physical pins on the microcontroller.
 * 
 * EACH PIN CAN BE:
 * ----------------
 * • INPUT: Read digital signals (button, sensor)
 * • OUTPUT: Drive digital signals (LED, relay)
 * • ALTERNATE FUNCTION: Used by peripherals (UART TX/RX, I2C SDA/SCL)
 * • ANALOG: Connected to ADC
 * 
 * PIN NAMING:
 * -----------
 * PA0 = Port A, Pin 0
 * PD12 = Port D, Pin 12 (green LED on Discovery board)
 * 
 * CONFIGURATION REGISTERS:
 * ------------------------
 * Most registers use 2 bits per pin (16 pins × 2 bits = 32 bits)
 * 
 * Base addresses:
 * GPIOA: 0x40020000
 * GPIOB: 0x40020400
 * GPIOC: 0x40020800
 * GPIOD: 0x40020C00
 */
struct GPIO_Registers {
    volatile uint32_t MODER;    // 0x00: Mode register (input/output/AF/analog)
    volatile uint32_t OTYPER;   // 0x04: Output type (push-pull/open-drain)
    volatile uint32_t OSPEEDR;  // 0x08: Output speed (low/medium/fast/high)
    volatile uint32_t PUPDR;    // 0x0C: Pull-up/pull-down
    volatile uint32_t IDR;      // 0x10: Input data register (READ ONLY)
    volatile uint32_t ODR;      // 0x14: Output data register
    volatile uint32_t BSRR;     // 0x18: Bit set/reset register (atomic!)
    volatile uint32_t LCKR;     // 0x1C: Configuration lock register
    volatile uint32_t AFR[2];   // 0x20-0x24: Alternate function registers
};

#define GPIOA ((GPIO_Registers*)0x40020000)
#define GPIOB ((GPIO_Registers*)0x40020400)
#define GPIOC ((GPIO_Registers*)0x40020800)
#define GPIOD ((GPIO_Registers*)0x40020C00)

/**
 * MODER (Mode Register) - 2 bits per pin
 * ----------------------------------------
 * Bits [1:0] control pin 0, bits [3:2] control pin 1, etc.
 * 
 * Values:
 * 00 = Input mode
 * 01 = Output mode
 * 10 = Alternate function mode (UART, I2C, SPI, etc.)
 * 11 = Analog mode (ADC input)
 * 
 * Example: Configure PA5 as output
 * GPIOA->MODER &= ~(0b11 << (5*2));  // Clear bits [11:10]
 * GPIOA->MODER |=  (0b01 << (5*2));  // Set to output mode
 */

/**
 * OTYPER (Output Type Register) - 1 bit per pin
 * -----------------------------------------------
 * Bit n controls pin n
 * 
 * 0 = Push-pull (can drive HIGH and LOW)
 *     ────┐     ┌──── 
 *         └─────┘     Can source AND sink current
 * 
 * 1 = Open-drain (can only pull LOW, needs external pull-up)
 *     ────┐
 *         └─────────  Can only sink current
 */

/**
 * OSPEEDR (Output Speed Register) - 2 bits per pin
 * --------------------------------------------------
 * Controls slew rate (how fast signal transitions)
 * 
 * 00 = Low speed (2 MHz) - reduces EMI
 * 01 = Medium speed (25 MHz)
 * 10 = Fast speed (50 MHz)
 * 11 = High speed (100 MHz) - increases EMI
 * 
 * Higher speed = faster transitions = more EMI (electromagnetic interference)
 * Use lowest speed that meets requirements!
 */

/**
 * PUPDR (Pull-Up/Pull-Down Register) - 2 bits per pin
 * -----------------------------------------------------
 * Internal resistors (~40kΩ) to pull pin to known state
 * 
 * 00 = No pull-up/down (floating - bad for inputs!)
 * 01 = Pull-up (weak connection to 3.3V)
 * 10 = Pull-down (weak connection to GND)
 * 
 * WHY USE PULL-UP/DOWN?
 * Prevents floating inputs which can cause:
 * - Random readings
 * - Increased power consumption
 * - Oscillation between states
 */

/**
 * IDR (Input Data Register) - READ ONLY
 * --------------------------------------
 * Bit n reflects voltage on pin n
 * 0 = Low voltage (< ~1.5V)
 * 1 = High voltage (> ~1.8V)
 * 
 * Reading: if (GPIOA->IDR & (1 << 5)) { // PA5 is high }
 */

/**
 * ODR (Output Data Register)
 * ---------------------------
 * Bit n controls output of pin n (in output mode)
 * 
 * Writing: GPIOA->ODR |= (1 << 5);   // Set PA5 high
 *         GPIOA->ODR &= ~(1 << 5);  // Set PA5 low
 * 
 * PROBLEM: Read-modify-write is NOT atomic!
 * If interrupt occurs between read and write, can corrupt other pins.
 */

/**
 * BSRR (Bit Set/Reset Register) - ATOMIC WRITE
 * ----------------------------------------------
 * This is THE BEST way to control GPIO outputs!
 * 
 * Lower 16 bits [15:0]: SET bits (write 1 to set pin HIGH)
 * Upper 16 bits [31:16]: RESET bits (write 1 to set pin LOW)
 * 
 * Examples:
 * GPIOD->BSRR = (1 << 12);       // Set PD12 high (turn on LED)
 * GPIOD->BSRR = (1 << (12+16));  // Set PD12 low (turn off LED)
 * 
 * ADVANTAGES:
 * ✓ Atomic - no race conditions
 * ✓ Fast - single write operation
 * ✓ Can set and clear different pins simultaneously
 * 
 * Example: Toggle two LEDs at once
 * GPIOD->BSRR = (1<<12) | (1<<(13+16));  // PD12=HIGH, PD13=LOW
 */

/**
 * AFR (Alternate Function Register) - 4 bits per pin
 * ----------------------------------------------------
 * Selects which peripheral controls the pin
 * 
 * AFR[0] (AFRL): Controls pins 0-7
 * AFR[1] (AFRH): Controls pins 8-15
 * 
 * Each pin gets 4 bits, allowing 16 alternate functions (AF0-AF15)
 * 
 * Common alternate functions for STM32F407:
 * AF0  = System (JTAG, SWD debug)
 * AF1  = TIM1, TIM2
 * AF2  = TIM3, TIM4, TIM5
 * AF4  = I2C1, I2C2, I2C3
 * AF5  = SPI1, SPI2
 * AF7  = USART1, USART2, USART3
 * AF9  = CAN1, CAN2, TIM12-14
 * AF10 = USB OTG FS
 * 
 * Example: Configure PA2 for USART2_TX (AF7)
 * Pin 2 uses bits [11:8] in AFR[0]
 * GPIOA->AFR[0] &= ~(0xF << (2*4));   // Clear bits [11:8]
 * GPIOA->AFR[0] |=  (7 << (2*4));     // Set AF7
 */

// ═════════════════════════════════════════════════════════════════════════════
// USART (UNIVERSAL SYNCHRONOUS/ASYNCHRONOUS RECEIVER/TRANSMITTER)
// ═════════════════════════════════════════════════════════════════════════════
/**
 * USART sends data serially (one bit at a time).
 * 
 * UART FRAME (8N1 - most common):
 *    Idle   Start   D0  D1  D2  D3  D4  D5  D6  D7   Stop   Idle
 *    ─────┐      ┌───────────────────────────────┐      ┌─────
 *         └──────┘                               └──────┘
 *         1 bit   ← 8 data bits (LSB first) →   1 bit
 * 
 * 8N1 means: 8 data bits, No parity, 1 stop bit
 * 
 * BAUD RATE = bits per second (common: 9600, 115200)
 * Both devices must use SAME baud rate (no clock wire!)
 * 
 * Base addresses:
 * USART1: 0x40011000 (APB2 - 84 MHz)
 * USART2: 0x40004400 (APB1 - 42 MHz)
 */
struct USART_Registers {
    volatile uint32_t SR;       // 0x00: Status register (flags)
    volatile uint32_t DR;       // 0x04: Data register (read/write data)
    volatile uint32_t BRR;      // 0x08: Baud rate register
    volatile uint32_t CR1;      // 0x0C: Control register 1
    volatile uint32_t CR2;      // 0x10: Control register 2
    volatile uint32_t CR3;      // 0x14: Control register 3
    volatile uint32_t GTPR;     // 0x18: Guard time and prescaler
};

#define USART1 ((USART_Registers*)0x40011000)
#define USART2 ((USART_Registers*)0x40004400)

// SR (Status Register) - read-only flags
#define USART_SR_TXE     (1U << 7)  // Transmit data register empty
#define USART_SR_TC      (1U << 6)  // Transmission complete
#define USART_SR_RXNE    (1U << 5)  // Read data register not empty
#define USART_SR_IDLE    (1U << 4)  // IDLE line detected
#define USART_SR_ORE     (1U << 3)  // Overrun error
#define USART_SR_NE      (1U << 2)  // Noise error
#define USART_SR_FE      (1U << 1)  // Framing error
#define USART_SR_PE      (1U << 0)  // Parity error

// CR1 (Control Register 1)
#define USART_CR1_UE     (1U << 13) // USART enable
#define USART_CR1_M      (1U << 12) // Word length (0=8bit, 1=9bit)
#define USART_CR1_PCE    (1U << 10) // Parity control enable
#define USART_CR1_TXEIE  (1U << 7)  // TXE interrupt enable
#define USART_CR1_TCIE   (1U << 6)  // TC interrupt enable
#define USART_CR1_RXNEIE (1U << 5)  // RXNE interrupt enable
#define USART_CR1_TE     (1U << 3)  // Transmitter enable
#define USART_CR1_RE     (1U << 2)  // Receiver enable

/**
 * BRR (Baud Rate Register) - Calculate carefully!
 * ------------------------------------------------
 * Formula: Baud Rate = f_PCLK / (16 × BRR_value)
 * 
 * Therefore: BRR_value = f_PCLK / (16 × Baud Rate)
 * 
 * BRR format:
 * [15:4] = Mantissa (integer part)
 * [3:0]  = Fraction (fractional part in 1/16ths)
 * 
 * Example: USART2 on APB1 @ 42MHz, Baud = 115200
 * BRR = 42,000,000 / (16 × 115,200) = 22.786
 * Mantissa = 22 = 0x16
 * Fraction = 0.786 × 16 = 12.58 ≈ 13 = 0xD
 * BRR = 0x016D = (22 << 4) | 13
 */

// ═════════════════════════════════════════════════════════════════════════════
// NVIC (NESTED VECTORED INTERRUPT CONTROLLER)
// ═════════════════════════════════════════════════════════════════════════════
/**
 * NVIC manages all interrupts in ARM Cortex-M4.
 * 
 * INTERRUPT PRIORITIES:
 * - Lower number = higher priority
 * - STM32F4 uses 4 bits for priority (0-15)
 * - Priority 0 = highest, 15 = lowest
 * 
 * IMPORTANT INTERRUPT NUMBERS:
 * USART1: IRQ 37
 * USART2: IRQ 38
 * I2C1_EV: IRQ 31
 * SPI1: IRQ 35
 * 
 * Base address: 0xE000E100
 */

// NVIC Interrupt Set-Enable Registers
// Each register controls 32 interrupts
#define NVIC_ISER0 ((volatile uint32_t*)0xE000E100)  // IRQ 0-31
#define NVIC_ISER1 ((volatile uint32_t*)0xE000E104)  // IRQ 32-63
#define NVIC_ISER2 ((volatile uint32_t*)0xE000E108)  // IRQ 64-95

// NVIC Interrupt Clear-Enable Registers
#define NVIC_ICER0 ((volatile uint32_t*)0xE000E180)
#define NVIC_ICER1 ((volatile uint32_t*)0xE000E184)
#define NVIC_ICER2 ((volatile uint32_t*)0xE000E188)

// NVIC Interrupt Priority Registers (one byte per interrupt)
#define NVIC_IPR   ((volatile uint8_t*)0xE000E400)

/**
 * HOW TO ENABLE INTERRUPT:
 * 
 * Example: Enable USART2 (IRQ 38)
 * 1. Calculate register: 38 / 32 = 1 → Use ISER1
 * 2. Calculate bit: 38 % 32 = 6 → Bit 6
 * 3. Set bit: *NVIC_ISER1 |= (1 << 6);
 */

// ═════════════════════════════════════════════════════════════════════════════
// SYSTICK TIMER
// ═════════════════════════════════════════════════════════════════════════════
/**
 * SysTick is a 24-bit countdown timer in every ARM Cortex-M core.
 * Perfect for delays and timekeeping.
 * 
 * HOW IT WORKS:
 * 1. Write value to LOAD register
 * 2. Timer counts down: LOAD → LOAD-1 → ... → 1 → 0
 * 3. At zero: sets COUNTFLAG, reloads LOAD, continues
 * 4. Optionally generates interrupt
 * 
 * Base address: 0xE000E010
 */
struct SysTick_Registers {
    volatile uint32_t CTRL;     // 0x00: Control and status
    volatile uint32_t LOAD;     // 0x04: Reload value
    volatile uint32_t VAL;      // 0x08: Current value
    volatile uint32_t CALIB;    // 0x0C: Calibration value
};

#define SYSTICK ((SysTick_Registers*)0xE000E010)

#define SYSTICK_CTRL_ENABLE    (1U << 0)  // Counter enable
#define SYSTICK_CTRL_TICKINT   (1U << 1)  // Enable interrupt
#define SYSTICK_CTRL_CLKSOURCE (1U << 2)  // 1=processor clock, 0=external
#define SYSTICK_CTRL_COUNTFLAG (1U << 16) // Returns 1 if counted to 0

// ═════════════════════════════════════════════════════════════════════════════
// BIT MANIPULATION MACROS
// ═════════════════════════════════════════════════════════════════════════════

// Set bit (make it 1)
#define SET_BIT(REG, BIT)    ((REG) |= (BIT))

// Clear bit (make it 0)
#define CLEAR_BIT(REG, BIT)  ((REG) &= ~(BIT))

// Read bit (returns 0 or non-zero)
#define READ_BIT(REG, BIT)   ((REG) & (BIT))

// Toggle bit (flip it)
#define TOGGLE_BIT(REG, BIT) ((REG) ^= (BIT))

// Modify bits: clear MASK, then set VALUE
#define MODIFY_REG(REG, MASK, VALUE) ((REG) = ((REG) & ~(MASK)) | (VALUE))

#endif // STM32F4_REGS_HPP
