/**
 * @file main.cpp
 * @brief STM32F4 Bare Metal C++ Examples
 * 
 * WHAT IS BARE METAL?
 * ===================
 * This code runs directly on hardware without an operating system.
 * No FreeRTOS, no Linux, just YOU and the CPU.
 * 
 * Memory Layout:
 * --------------
 * 0x08000000: Flash (your code lives here)
 * 0x20000000: SRAM (variables, stack, heap)
 * 0x40000000: Peripherals (memory-mapped registers)
 * 
 * Startup Sequence:
 * -----------------
 * 1. CPU powers on, reads reset vector from 0x08000004
 * 2. Jumps to Reset_Handler (in startup_stm32f4xx.s)
 * 3. Reset_Handler copies .data from flash to RAM
 * 4. Reset_Handler zeros .bss section
 * 5. Reset_Handler calls SystemInit() then main()
 * 6. main() MUST NEVER RETURN! (infinite loop required)
 * 
 * Interrupt Vector Table:
 * -----------------------
 * Located at start of flash (0x08000000)
 * Array of function pointers:
 *   0: Initial stack pointer
 *   1: Reset_Handler
 *   2: NMI_Handler
 *   3: HardFault_Handler
 *   ...
 *   38: USART2_IRQHandler
 *   ...
 * 
 * When interrupt occurs, CPU reads vector table and jumps to handler.
 */

#include "stm32f4xx.h"
#include <cstdint>

// Our bare metal drivers
#include "BareMetalUart.hpp"
#include "HardwareTimer.hpp"
#include "AdcDma.hpp"
#include "I2cSensor.hpp"

// Global objects (must be accessible from ISRs)
static BareMetalUart* g_uart = nullptr;
static HardwareTimer* g_timer = nullptr;

// Volatile counters modified by interrupts
volatile uint32_t g_systick_ms = 0;
volatile uint32_t g_timer_ticks = 0;

/**
 * @brief System Clock Configuration
 * 
 * CLOCK TREE EXPLANATION:
 * =======================
 * 
 * STM32F407 has complex clock system:
 * 
 * HSE (8 MHz crystal)
 *  ↓
 * PLL (/M=8, *N=336, /P=2)
 *  ↓
 * SYSCLK = 168 MHz
 *  ↓
 * AHB (÷1) = 168 MHz ← CPU, DMA, memories
 *  ├→ APB1 (÷4) = 42 MHz ← TIM2-7, I2C, USART2-5
 *  │  └→ TIM2-7 CLK = 84 MHz (APB1 × 2)
 *  └→ APB2 (÷2) = 84 MHz ← TIM1,8-11, USART1, ADC
 *     └→ TIM1,8-11 CLK = 168 MHz (APB2 × 2)
 * 
 * Why timer clocks are 2×?
 * When APB prescaler ≠ 1, timer clocks are multiplied by 2.
 * This is automatic in hardware!
 */
void SystemClock_Config(void) {
    // Enable HSE (High-Speed External 8 MHz crystal)
    RCC->CR |= RCC_CR_HSEON;
    while (!(RCC->CR & RCC_CR_HSERDY));  // Wait for HSE ready
    
    // Configure Flash latency for 168 MHz
    // 5 wait states required for 168 MHz @ 3.3V
    FLASH->ACR = FLASH_ACR_LATENCY_5WS | 
                 FLASH_ACR_ICEN |  // Instruction cache enable
                 FLASH_ACR_DCEN |  // Data cache enable
                 FLASH_ACR_PRFTEN; // Prefetch enable
    
    // Configure PLL
    // PLL input = HSE = 8 MHz
    // VCO input = 8 MHz / M = 8 MHz / 8 = 1 MHz (must be 1-2 MHz)
    // VCO output = 1 MHz * N = 1 MHz * 336 = 336 MHz (must be 192-432 MHz)
    // SYSCLK = 336 MHz / P = 336 MHz / 2 = 168 MHz
    RCC->PLLCFGR = (8 << RCC_PLLCFGR_PLLM_Pos) |   // M = 8
                   (336 << RCC_PLLCFGR_PLLN_Pos) | // N = 336
                   (0 << RCC_PLLCFGR_PLLP_Pos) |   // P = 2 (00b)
                   RCC_PLLCFGR_PLLSRC_HSE;          // Source = HSE
    
    // Enable PLL
    RCC->CR |= RCC_CR_PLLON;
    while (!(RCC->CR & RCC_CR_PLLRDY));  // Wait for PLL ready
    
    // Configure bus prescalers BEFORE switching to PLL
    RCC->CFGR = RCC_CFGR_HPRE_DIV1 |   // AHB = SYSCLK / 1
                RCC_CFGR_PPRE1_DIV4 |  // APB1 = AHB / 4
                RCC_CFGR_PPRE2_DIV2;   // APB2 = AHB / 2
    
    // Switch system clock to PLL
    RCC->CFGR |= RCC_CFGR_SW_PLL;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_PLL);
    
    // Update SystemCoreClock variable
    SystemCoreClock = 168000000;
}

/**
 * @brief SysTick Timer Configuration
 * 
 * SYSTICK EXPLANATION:
 * ====================
 * SysTick is a simple 24-bit down counter in the Cortex-M4 core.
 * Used for creating millisecond time base.
 * 
 * Registers (at 0xE000E010):
 * - CTRL: Control and status
 * - LOAD: Reload value (counts from here to 0)
 * - VAL: Current value
 * - CALIB: Calibration value
 * 
 * To generate 1 ms interrupt at 168 MHz:
 * LOAD = 168000000 / 1000 - 1 = 167999
 */
void SysTick_Config_Ms(void) {
    // Configure for 1 ms interrupt
    SysTick->LOAD = 168000 - 1;  // 168 MHz / 1000 = 168000
    SysTick->VAL = 0;            // Clear current value
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |  // Use CPU clock
                    SysTick_CTRL_TICKINT_Msk |    // Enable interrupt
                    SysTick_CTRL_ENABLE_Msk;      // Enable counter
}

/**
 * @brief Simple delay in milliseconds
 * 
 * Uses SysTick counter for timing.
 * This is BLOCKING - CPU just waits.
 */
void delay_ms(uint32_t ms) {
    uint32_t start = g_systick_ms;
    while ((g_systick_ms - start) < ms);
}

/**
 * @brief Configure LED on PD12
 * 
 * GPIO CONFIGURATION:
 * ===================
 * Each GPIO pin has several configuration bits:
 * 
 * MODER (2 bits per pin): Input, Output, AF, Analog
 * OTYPER (1 bit per pin): Push-pull or Open-drain
 * OSPEEDR (2 bits per pin): Low, Medium, High, Very High speed
 * PUPDR (2 bits per pin): No pull, Pull-up, Pull-down
 * 
 * For LED output:
 * - Mode: Output
 * - Type: Push-pull (can drive high and low)
 * - Speed: Low (LED is slow)
 * - Pull: None (output drives it)
 */
void LED_Config(void) {
    // Enable GPIOD clock (bit 3 in AHB1ENR)
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIODEN;
    
    // Configure PD12 as output
    // MODER bits 24-25 = 01b (output mode)
    GPIOD->MODER &= ~GPIO_MODER_MODER12;
    GPIOD->MODER |= GPIO_MODER_MODER12_0;
    
    // Push-pull output (default, but explicit)
    GPIOD->OTYPER &= ~GPIO_OTYPER_OT_12;
    
    // Low speed
    GPIOD->OSPEEDR &= ~GPIO_OSPEEDER_OSPEEDR12;
    
    // No pull-up/pull-down
    GPIOD->PUPDR &= ~GPIO_PUPDR_PUPDR12;
}

void LED_On(void) {
    // Set bit 12 in ODR (Output Data Register)
    GPIOD->ODR |= GPIO_ODR_OD12;
    
    // Alternative: Use BSRR for atomic operation
    // GPIOD->BSRR = GPIO_BSRR_BS12;  // Set bit
}

void LED_Off(void) {
    GPIOD->ODR &= ~GPIO_ODR_OD12;
    
    // Alternative: Use BSRR
    // GPIOD->BSRR = GPIO_BSRR_BR12;  // Reset bit
}

void LED_Toggle(void) {
    GPIOD->ODR ^= GPIO_ODR_OD12;
}

/**
 * @brief Main function
 * 
 * IMPORTANT: main() must NEVER return!
 * There's nothing to return to - we're running on bare hardware.
 * If main() returns, CPU executes whatever garbage is after main().
 */
int main(void) {
    // Configure system clock first!
    SystemClock_Config();
    
    // Configure SysTick for 1 ms timing
    SysTick_Config_Ms();
    
    // Configure LED
    LED_Config();
    
    // ========================================
    // EXERCISE 1: UART Communication
    // ========================================
    
    // Create UART driver (auto-initializes hardware)
    static BareMetalUart uart(USART2, 42000000, 115200);
    g_uart = &uart;
    
    uart.transmitString("\r\n==============================\r\n");
    uart.transmitString("STM32F4 Bare Metal C++ Demo\r\n");
    uart.transmitString("==============================\r\n\r\n");
    
    // Enable UART RX interrupt
    uart.enableRxInterrupt();
    
    uart.transmitString("Exercise 1: UART Ready\r\n");
    uart.transmitString("Type characters to echo\r\n\r\n");
    
    // ========================================
    // EXERCISE 2: Hardware Timer with PWM
    // ========================================
    
    // Create timer for 1 Hz interrupt (1 second period)
    static HardwareTimer timer(TIM2);
    g_timer = &timer;
    
    // Uncomment to enable timer interrupt:
    // timer.initPeriodic(1);  // 1 Hz = 1 second period
    
    // Create PWM on PA5 (TIM2 CH1)
    // 1 kHz frequency, 50% duty cycle
    // timer.initPwm(1000, 50);
    
    uart.transmitString("Exercise 2: Timer configured\r\n\r\n");
    
    // ========================================
    // EXERCISE 3: ADC with DMA
    // ========================================
    
    // Create ADC with DMA for continuous sampling
    static AdcDma adc(100);  // 100 sample buffer
    
    // Uncomment to start continuous ADC:
    // adc.startContinuous();
    
    uart.transmitString("Exercise 3: ADC+DMA ready\r\n\r\n");
    
    // ========================================
    // EXERCISE 4: I2C Sensor
    // ========================================
    
    // Create I2C sensor (e.g., MPU6050 at 0x68)
    static I2cSensor sensor(I2C1, 0x68);
    
    // Try to read WHO_AM_I register
    uint8_t who_am_i = 0;
    if (sensor.readRegister(0x75, who_am_i)) {
        uart.transmitString("Exercise 4: I2C sensor detected: 0x");
        // Print hex value
        char hex[3];
        hex[0] = "0123456789ABCDEF"[who_am_i >> 4];
        hex[1] = "0123456789ABCDEF"[who_am_i & 0x0F];
        hex[2] = '\0';
        uart.transmitString(hex);
        uart.transmitString("\r\n\r\n");
    } else {
        uart.transmitString("Exercise 4: No I2C sensor found\r\n\r\n");
    }
    
    uart.transmitString("Entering main loop...\r\n\r\n");
    
    // ========================================
    // MAIN LOOP - RUNS FOREVER
    // ========================================
    
    uint32_t last_blink = 0;
    uint32_t last_adc_read = 0;
    
    while (1) {  // CRITICAL: Infinite loop required!
        
        // Blink LED every 500 ms
        if ((g_systick_ms - last_blink) >= 500) {
            last_blink = g_systick_ms;
            LED_Toggle();
        }
        
        // Check for UART data
        if (uart.rxAvailable()) {
            uint8_t data = uart.readByte();
            
            // Echo back
            uart.transmitByte(data);
            
            // Show hex value
            if (data >= 32 && data <= 126) {
                uart.transmitString(" [0x");
                char hex[3];
                hex[0] = "0123456789ABCDEF"[data >> 4];
                hex[1] = "0123456789ABCDEF"[data & 0x0F];
                hex[2] = '\0';
                uart.transmitString(hex);
                uart.transmitString("]\r\n");
            }
        }
        
        // Read ADC every 1 second
        if ((g_systick_ms - last_adc_read) >= 1000) {
            last_adc_read = g_systick_ms;
            
            // Get ADC sample
            uint16_t adc_value = adc.getSample(0);
            uint16_t voltage_mv = AdcDma::toMillivolts(adc_value);
            
            uart.transmitString("ADC: ");
            // Simple integer to string (voltage in mV)
            char buf[16];
            int idx = 0;
            uint16_t val = voltage_mv;
            do {
                buf[idx++] = '0' + (val % 10);
                val /= 10;
            } while (val);
            
            // Reverse string
            for (int i = 0; i < idx / 2; i++) {
                char temp = buf[i];
                buf[i] = buf[idx - 1 - i];
                buf[idx - 1 - i] = temp;
            }
            buf[idx] = '\0';
            
            uart.transmitString(buf);
            uart.transmitString(" mV\r\n");
        }
        
        // CPU can do other work here
        // Or enter sleep mode to save power:
        // __WFI();  // Wait For Interrupt
    }
    
    // NEVER REACHED!
    return 0;
}

// ============================================
// INTERRUPT SERVICE ROUTINES (ISRs)
// ============================================

/**
 * @brief SysTick ISR - Called every 1 ms
 * 
 * ISR RULES:
 * ==========
 * 1. Keep short and fast (<< 1ms execution time)
 * 2. Don't call blocking functions
 * 3. Don't do floating point (context save is slow)
 * 4. Use volatile for shared variables
 * 5. Clear interrupt flags
 * 
 * extern "C" required because ISR names are in vector table
 * and must have C linkage (no name mangling).
 */
extern "C" void SysTick_Handler(void) {
    // Increment millisecond counter
    // This is atomic (single instruction on Cortex-M4)
    g_systick_ms++;
    
    // No flag to clear - SysTick clears automatically
}

/**
 * @brief USART2 ISR - Called when byte received
 * 
 * UART INTERRUPT FLAGS:
 * =====================
 * RXNE: Receive data register not empty
 * TXE: Transmit data register empty
 * TC: Transmission complete
 * IDLE: Idle line detected
 * ORE: Overrun error
 * 
 * We only enable RXNE interrupt.
 */
extern "C" void USART2_IRQHandler(void) {
    // Check if RXNE flag set
    if (USART2->SR & USART_SR_RXNE) {
        // Call our UART driver's callback
        // This reads DR register, which clears RXNE flag
        if (g_uart != nullptr) {
            g_uart->rxCallback();
        }
    }
}

/**
 * @brief TIM2 ISR - Called on timer update event
 */
extern "C" void TIM2_IRQHandler(void) {
    // Check if update interrupt flag set
    if (TIM2->SR & TIM_SR_UIF) {
        // MUST clear flag!
        if (g_timer != nullptr) {
            g_timer->clearInterruptFlag();
        }
        
        // Do something periodic here
        g_timer_ticks++;
    }
}

/**
 * @brief Hard Fault Handler - Called on serious errors
 * 
 * Common causes:
 * - Null pointer dereference
 * - Stack overflow
 * - Invalid memory access
 * - Divide by zero (if enabled)
 * 
 * In production, log error and reset system.
 * During development, set breakpoint here to debug.
 */
extern "C" void HardFault_Handler(void) {
    // Blink LED fast to indicate error
    while (1) {
        LED_Toggle();
        for (volatile int i = 0; i < 1000000; i++);
    }
}
