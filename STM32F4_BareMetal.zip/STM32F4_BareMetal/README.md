# STM32F4 Bare Metal C++ Programming

**Complete Guide to Understanding Hardware-Level Embedded Programming**

## What is Bare Metal Programming?

Bare metal means your code runs **directly on the microcontroller** without an operating system. No Linux, no FreeRTOS - just you and the hardware.

### Why Learn Bare Metal?

1. **Understand how things REALLY work**
   - See exactly what happens at the register level
   - Understand interrupt mechanisms
   - Learn memory-mapped I/O

2. **Debug embedded systems effectively**
   - Know what to look for in registers
   - Understand clock configurations
   - Debug timing issues

3. **Write efficient code**
   - No OS overhead
   - Complete control of CPU cycles
   - Predictable timing

4. **Foundation for everything else**
   - RTOS makes more sense after bare metal
   - Better driver development
   - Understanding bootloaders

## Project Structure

```
STM32F4_BareMetal/
├── Application/
│   ├── Exercise1/
│   │   └── BareMetalUart.hpp    # UART with detailed register explanations
│   ├── Exercise2/
│   │   └── HardwareTimer.hpp    # Timer, PWM, clock math
│   ├── Exercise3/
│   │   └── AdcDma.hpp            # ADC + DMA, zero-CPU transfer
│   └── Exercise4/
│       └── I2cSensor.hpp        # I2C protocol explanation
├── Core/
│   └── Src/
│       └── main.cpp             # Complete working example
└── README.md
```

## Hardware Requirements

- **Board**: STM32F407VG Discovery (or any STM32F4)
- **Debugger**: ST-LINK (built into Discovery board)
- **Optional**: USB-to-Serial adapter for UART
- **Optional**: I2C sensor (e.g., MPU6050, BMP280)

## Key Concepts Explained

### 1. Memory-Mapped I/O

Peripherals are accessed like memory addresses:

```cpp
// GPIO Port D is at address 0x40020C00
GPIOD->ODR |= (1 << 12);  // Set bit 12 (turn on LED)

// This is actually:
*(volatile uint32_t*)0x40020C14 |= (1 << 12);
```

**Memory Map**:
- `0x08000000`: Flash (your code)
- `0x20000000`: SRAM (variables, stack)
- `0x40000000`: Peripherals (registers)
- `0xE0000000`: Cortex-M4 core (NVIC, SysTick, etc.)

### 2. Clock System

STM32F4 has a complex clock tree:

```
HSE (8 MHz) → PLL (×42) → SYSCLK (168 MHz)
                              ↓
                          AHB (168 MHz) → CPU, DMA
                              ↓
                   ┌──────────┴──────────┐
                   ↓                     ↓
               APB1 (42 MHz)        APB2 (84 MHz)
               TIM2-7, I2C          TIM1,8-11, ADC
```

**Important**: Timer clocks are 2× APB clock when APB prescaler ≠ 1!

### 3. Interrupts

Interrupts pause your code to handle events:

```cpp
// 1. Enable peripheral interrupt
USART2->CR1 |= USART_CR1_RXNEIE;

// 2. Enable in NVIC
NVIC_EnableIRQ(USART2_IRQn);

// 3. Write ISR
extern "C" void USART2_IRQHandler(void) {
    if (USART2->SR & USART_SR_RXNE) {
        uint8_t data = USART2->DR;  // Reading clears flag
        // Handle data
    }
}
```

**ISR Rules**:
- Keep SHORT (<100 μs if possible)
- Clear interrupt flags
- Use `volatile` for shared variables
- Minimal processing - defer to main loop

### 4. Volatile Keyword

`volatile` tells compiler: "This can change unexpectedly"

```cpp
// WRONG - Compiler optimizes away loop!
uint32_t flag = 0;
while (flag == 0);  // Infinite loop!

void ISR() { flag = 1; }  // Never seen by main code

// CORRECT - Compiler re-reads every iteration
volatile uint32_t flag = 0;
while (flag == 0);  // Works!
```

**Always use `volatile` for**:
- Hardware registers
- Variables modified in ISRs
- Variables shared between threads

### 5. Register Bit Manipulation

```cpp
// Set bit 5
REG |= (1 << 5);

// Clear bit 5
REG &= ~(1 << 5);

// Toggle bit 5
REG ^= (1 << 5);

// Check if bit 5 set
if (REG & (1 << 5)) { }

// Set bits 4-6 to 101b
REG &= ~(0x7 << 4);  // Clear bits 4-6
REG |= (0x5 << 4);   // Set to 101b
```

## Exercise Explanations

### Exercise 1: UART Communication

**What You Learn**:
- Memory-mapped register access
- Baud rate calculation
- GPIO alternate function configuration
- Interrupt-driven reception
- Circular buffers

**Key Concepts**:
```cpp
// Baud rate formula
BRR = APB_Clock / (16 × Baud_Rate)

// Example: 42 MHz / (16 × 115200) = 22.786
// Mantissa = 22, Fraction = 0.786 × 16 ≈ 12
// BRR = 0x016C
```

**Hardware Flow**:
1. Configure GPIO pins as UART alternate function
2. Calculate and set baud rate
3. Enable UART, TX, RX
4. Enable RX interrupt
5. ISR stores received bytes in circular buffer

### Exercise 2: Hardware Timer & PWM

**What You Learn**:
- Timer clock sources
- Prescaler and period calculations
- PWM generation
- Compare registers

**Timer Math**:
```
Timer_Frequency = Timer_CLK / ((PSC + 1) × (ARR + 1))

Example: 1 kHz from 84 MHz
84 MHz / (84 × 1000) = 1 kHz
PSC = 83, ARR = 999
```

**PWM Concept**:
```
Duty Cycle = CCR / ARR

Example: 25% duty
ARR = 1000, CCR = 250

Output: ▄▄▄▄▄╗          ▄▄▄▄▄╗
             ╚▄▄▄▄▄▄▄▄▄╝     ╚▄▄▄
        25%      75%
```

### Exercise 3: ADC with DMA

**What You Learn**:
- Analog-to-digital conversion
- DMA (Direct Memory Access)
- Zero-CPU data transfer
- Circular buffers

**Why DMA is Amazing**:

Traditional (CPU involved):
```
1. ADC converts
2. Interrupt fires
3. CPU reads ADC->DR
4. CPU stores in buffer
5. Repeat
```

With DMA:
```
1. ADC converts
2. DMA moves data to buffer
3. CPU continues other work!
```

**Voltage Calculation**:
```cpp
voltage_mV = (adc_value / 4095) × 3300
```

### Exercise 4: I2C Communication

**What You Learn**:
- I2C protocol (START, STOP, ACK, NACK)
- Multi-master bus
- Open-drain outputs
- Register-level I2C control

**I2C Transaction**:
```
S [ADDR+W] A [REG] A Sr [ADDR+R] A [DATA] NA P

S  = START (SDA falls while SCL high)
A  = ACK (slave pulls SDA low)
NA = NACK (master doesn't ACK)
P  = STOP (SDA rises while SCL high)
```

**Why Open-Drain**:
- Multiple devices share same wires
- Anyone can pull line LOW
- Pull-up resistor brings line HIGH
- Prevents short circuits

## Setup Instructions

### 1. Install Tools

- **STM32CubeIDE**: https://www.st.com/stm32cubeide
- Or use command line:
  - `arm-none-eabi-gcc`
  - `openocd` (for flashing/debugging)

### 2. Create Project

1. New STM32 Project
2. Select STM32F407VG
3. Name: `STM32F4_BareMetal`
4. **IMPORTANT**: Select "Empty" (no HAL/LL)

### 3. Add Files

Copy all files from this package to your project.

### 4. Compiler Settings

**C/C++ Build → Settings → MCU G++ Compiler:**

Miscellaneous flags:
```
-std=c++17
-fno-exceptions
-fno-rtti
```

Optimization:
```
-O2
```

Include paths: Add Application folders

### 5. Build and Flash

1. Build: `Ctrl+B`
2. Flash: `Run → Debug (F11)`
3. Serial terminal: 115200 baud, 8N1

## Testing Each Exercise

### Exercise 1: UART

```bash
# Connect serial terminal
minicom -D /dev/ttyUSB0 -b 115200

# Or
screen /dev/ttyUSB0 115200
```

Type characters - they should echo back with hex values.

### Exercise 2: Timer

Uncomment in `main.cpp`:
```cpp
timer.initPeriodic(1);  // 1 Hz interrupt
```

LED should blink at 1 second intervals.

For PWM:
```cpp
timer.initPwm(1000, 50);  // 1 kHz, 50% duty
```

Connect oscilloscope to PA5 to see PWM waveform.

### Exercise 3: ADC

Connect potentiometer:
- One end: GND
- Wiper: PA0
- Other end: 3.3V

Uncomment:
```cpp
adc.startContinuous();
```

Should see voltage readings every second on UART.

### Exercise 4: I2C

Connect I2C sensor:
- SCL → PB6
- SDA → PB7
- VCC → 3.3V
- GND → GND

Should detect sensor and show ID.

## Common Issues

### 1. "Undefined reference" Errors

**Problem**: Linker can't find startup file

**Solution**: 
- Use STM32CubeIDE's generated startup file
- Or download from ST: `startup_stm32f407xx.s`

### 2. Code Doesn't Start

**Problem**: Boot pins misconfigured

**Solution**: 
- Check BOOT0 = 0 (boot from flash)
- Verify code is actually in flash: `st-flash --reset read dump.bin 0x08000000 0x10000`

### 3. UART Not Working

**Problem**: Wrong baud rate or clock

**Solution**:
```cpp
// Check APB1 clock frequency
// Should be 42 MHz for default config
// Baud = 42000000 / (16 × BRR)
```

### 4. Interrupts Not Firing

**Problem**: Forgot to enable in NVIC

**Solution**:
```cpp
// Enable peripheral interrupt
USART2->CR1 |= USART_CR1_RXNEIE;

// ALSO enable in NVIC!
NVIC_EnableIRQ(USART2_IRQn);
```

### 5. Variables Not Updating in ISR

**Problem**: Missing `volatile`

**Solution**:
```cpp
volatile uint32_t counter = 0;  // Must be volatile!
```

## Debugging Tips

### Use Printf via UART

```cpp
void uart_printf(const char* format, ...) {
    char buffer[128];
    va_list args;
    va_start(args, format);
    vsnprintf(buffer, sizeof(buffer), format, args);
    va_end(args);
    uart.transmitString(buffer);
}

// Usage
uart_printf("Counter: %d\r\n", counter);
```

### Check Registers in Debugger

Set breakpoint and examine:
```
(gdb) print /x *GPIOD
$1 = {MODER = 0x40000000, ...}

(gdb) print /x USART2->SR
$2 = 0x00c0
```

### Use SWO (Serial Wire Output)

ITM printf - doesn't need UART pins:
```cpp
void ITM_SendChar(char ch) {
    while (ITM->PORT[0].u32 == 0);
    ITM->PORT[0].u8 = ch;
}
```

## Going Further

### Add More Features

1. **SPI Communication**: Read from SD card or external flash
2. **CAN Bus**: Automotive communication
3. **USB Device**: Virtual COM port or mass storage
4. **Ethernet**: lwIP TCP/IP stack
5. **Low Power Modes**: Sleep, stop, standby

### Optimization

1. **Use DMA everywhere**: ADC, UART, SPI
2. **Enable instruction/data caches**
3. **Use WFI**: Sleep when idle
4. **Inline small functions**: Use `inline` keyword

### Safety

1. **Watchdog timer**: Reset if code hangs
2. **Stack guard**: Detect overflow
3. **CRC checks**: Verify data integrity
4. **Brown-out reset**: Handle power glitches

## Reference Materials

### STM32F4 Documents

- **Reference Manual** (RM0090): All peripheral details
- **Datasheet** (DS8626): Electrical specifications
- **Programming Manual** (PM0214): Cortex-M4 core
- **Errata**: Known hardware bugs

### ARM Cortex-M4

- **ARM Architecture Reference Manual**
- **Cortex-M4 Technical Reference Manual**
- **Cortex-M4 Devices Generic User Guide**

### Online Resources

- ST Community Forums
- ARM Keil Knowledge Base
- GitHub: Search "stm32f4 bare metal"

## Why This Matters

Understanding bare metal programming gives you:

✅ **Deep hardware knowledge** - Know how everything works  
✅ **Better debugging skills** - Fix problems others can't  
✅ **Efficient code** - Write faster, smaller programs  
✅ **RTOS understanding** - Appreciate what OS does  
✅ **Interview confidence** - Answer tough technical questions  

## Next Steps

1. **Modify the examples**: Change baud rates, timer frequencies
2. **Add error handling**: Check return values, handle timeouts
3. **Combine exercises**: UART + ADC + Timer together
4. **Read datasheets**: Understand YOUR specific chip
5. **Port to FreeRTOS**: See how RTOS builds on bare metal

---

**Happy Bare Metal Coding!** 🚀

*Remember: Every high-level framework is built on bare metal. Understanding this layer makes you a better embedded engineer.*
