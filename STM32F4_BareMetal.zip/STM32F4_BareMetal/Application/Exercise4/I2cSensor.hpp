#ifndef I2C_SENSOR_HPP
#define I2C_SENSOR_HPP

#include "stm32f4xx.h"
#include <cstdint>

/**
 * @file I2cSensor.hpp
 * @brief Bare metal I2C driver with detailed protocol explanation
 * 
 * I2C PROTOCOL EXPLANATION:
 * =========================
 * 
 * I2C (Inter-Integrated Circuit) is a two-wire serial protocol.
 * 
 * Physical Layer:
 * ---------------
 * - SCL: Serial Clock (master generates clock)
 * - SDA: Serial Data (bidirectional data line)
 * - Both lines need pull-up resistors (typically 4.7kΩ)
 * - Open-drain outputs (can only pull LOW, released to HIGH by pull-up)
 * 
 * I2C Transaction Format:
 * -----------------------
 * 
 * START condition → Address + R/W → ACK → Data → ACK → STOP
 * 
 * Example: Read temperature from sensor at address 0x48
 * 
 *  S   0x48  W  A   0x00  A   Sr  0x48  R  A   DATA  NA  P
 *  │    │    │  │    │    │   │    │    │  │    │    │   │
 *  │    └────┴──┘    └────┘   │    └────┴──┘    └────┘   │
 *  │   7-bit addr + W  reg     │   7-bit addr + R  temp   │
 *  │                            │                          │
 *  START                  Repeated START               STOP
 * 
 * Legend:
 * S   = START condition (SDA falls while SCL high)
 * P   = STOP condition (SDA rises while SCL high)
 * Sr  = Repeated START
 * A   = ACK (slave pulls SDA low)
 * NA  = NACK (master doesn't ACK last byte)
 * W   = Write bit (0)
 * R   = Read bit (1)
 * 
 * Bit Timing:
 * -----------
 * Standard mode: 100 kHz
 * Fast mode: 400 kHz
 * Fast mode+: 1 MHz
 * 
 * Each byte transmitted MSB first.
 * After each byte, receiver sends ACK (9th clock pulse).
 * 
 * START Condition (SDA falls while SCL high):
 * 
 *   SCL ────┐               ┌────
 *           │               │
 *           └───────────────┘
 * 
 *   SDA ────────┐
 *               │
 *               └───────────────
 * 
 * STOP Condition (SDA rises while SCL high):
 * 
 *   SCL ────┐               ┌────
 *           │               │
 *           └───────────────┘
 * 
 *   SDA ────────┐           ┌────
 *               │           │
 *               └───────────┘
 * 
 * STM32 I2C Hardware:
 * -------------------
 * The I2C peripheral handles protocol automatically.
 * Software just:
 * 1. Writes address + R/W to DR register
 * 2. Waits for address sent (ADDR flag)
 * 3. Writes/reads data bytes
 * 4. Generates STOP condition
 * 
 * Key I2C Registers:
 * ------------------
 * CR1  - Control register (PE, START, STOP, ACK)
 * CR2  - Control register (frequency, interrupts)
 * OAR1 - Own address register (when slave)
 * DR   - Data register (read/write data)
 * SR1  - Status register 1 (SB, ADDR, TXE, RXNE, BTF, etc.)
 * SR2  - Status register 2 (MSL, BUSY, TRA)
 * CCR  - Clock control register (speed configuration)
 * TRISE - Rise time register
 */
class I2cSensor {
public:
    /**
     * @brief Constructor
     * @param i2c I2C peripheral (I2C1, I2C2, I2C3)
     * @param device_address 7-bit I2C address
     */
    explicit I2cSensor(I2C_TypeDef* i2c, uint8_t device_address)
        : i2c_(i2c)
        , device_address_(device_address << 1)  // Shift for R/W bit
    {
        initGpio();
        initI2c();
    }
    
    /**
     * @brief Write single byte to register
     * @param reg Register address
     * @param value Data to write
     * 
     * I2C TRANSACTION:
     * S → [ADDR+W] → [REG] → [DATA] → P
     * 
     * Step-by-step hardware process:
     * 1. Generate START condition
     * 2. Send address with write bit
     * 3. Wait for address ACK
     * 4. Send register address
     * 5. Wait for data transmitted
     * 6. Send data byte
     * 7. Wait for byte transmitted
     * 8. Generate STOP condition
     */
    bool writeRegister(uint8_t reg, uint8_t value) {
        // Wait until bus free
        if (!waitWhileBusy()) return false;
        
        // Generate START condition
        // SDA falls while SCL high
        i2c_->CR1 |= I2C_CR1_START;
        
        // Wait for START bit sent (SB flag in SR1)
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_SB)) return false;
        
        // Send device address with write bit (0)
        // This clears SB flag
        i2c_->DR = device_address_ & 0xFE;
        
        // Wait for address sent (ADDR flag)
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_ADDR)) return false;
        
        // Clear ADDR by reading SR1 then SR2
        (void)i2c_->SR1;
        (void)i2c_->SR2;
        
        // Wait for TXE (transmit buffer empty)
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_TXE)) return false;
        
        // Send register address
        i2c_->DR = reg;
        
        // Wait for byte transmitted
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_BTF)) return false;
        
        // Send data
        i2c_->DR = value;
        
        // Wait for byte transmitted
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_BTF)) return false;
        
        // Generate STOP condition
        // SDA rises while SCL high
        i2c_->CR1 |= I2C_CR1_STOP;
        
        return true;
    }
    
    /**
     * @brief Read single byte from register
     * @param reg Register address
     * @param value Output: data read
     * 
     * I2C TRANSACTION:
     * S → [ADDR+W] → [REG] → Sr → [ADDR+R] → [DATA] → NACK → P
     * 
     * Two-part transaction:
     * Part 1: Write register address
     * Part 2: Read data byte
     * 
     * Uses repeated START (Sr) to switch from write to read
     * without releasing bus.
     */
    bool readRegister(uint8_t reg, uint8_t& value) {
        // Wait until bus free
        if (!waitWhileBusy()) return false;
        
        // PART 1: Write register address
        // -------------------------------
        
        // Generate START
        i2c_->CR1 |= I2C_CR1_START;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_SB)) return false;
        
        // Send address with write bit
        i2c_->DR = device_address_ & 0xFE;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_ADDR)) return false;
        
        // Clear ADDR
        (void)i2c_->SR1;
        (void)i2c_->SR2;
        
        // Send register address
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_TXE)) return false;
        i2c_->DR = reg;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_BTF)) return false;
        
        // PART 2: Read data byte
        // -----------------------
        
        // Generate repeated START
        i2c_->CR1 |= I2C_CR1_START;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_SB)) return false;
        
        // Send address with read bit (1)
        i2c_->DR = device_address_ | 0x01;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_ADDR)) return false;
        
        // Disable ACK (we'll NACK the last byte)
        i2c_->CR1 &= ~I2C_CR1_ACK;
        
        // Clear ADDR
        (void)i2c_->SR1;
        (void)i2c_->SR2;
        
        // Generate STOP before reading (single byte read)
        i2c_->CR1 |= I2C_CR1_STOP;
        
        // Wait for RXNE (receive buffer not empty)
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_RXNE)) return false;
        
        // Read data
        value = i2c_->DR;
        
        // Re-enable ACK for next transaction
        i2c_->CR1 |= I2C_CR1_ACK;
        
        return true;
    }
    
    /**
     * @brief Read multiple bytes from register
     * @param reg Starting register address
     * @param data Output buffer
     * @param len Number of bytes to read
     * 
     * For multi-byte read, most sensors auto-increment register address.
     * Master must ACK all bytes except the last one.
     */
    bool readRegisters(uint8_t reg, uint8_t* data, uint8_t len) {
        if (len == 0) return false;
        
        // Write register address (same as single byte)
        if (!waitWhileBusy()) return false;
        
        i2c_->CR1 |= I2C_CR1_START;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_SB)) return false;
        
        i2c_->DR = device_address_ & 0xFE;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_ADDR)) return false;
        
        (void)i2c_->SR1;
        (void)i2c_->SR2;
        
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_TXE)) return false;
        i2c_->DR = reg;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_BTF)) return false;
        
        // Repeated START for read
        i2c_->CR1 |= I2C_CR1_START;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_SB)) return false;
        
        i2c_->DR = device_address_ | 0x01;
        if (!waitForFlag(&i2c_->SR1, I2C_SR1_ADDR)) return false;
        
        // Enable ACK
        i2c_->CR1 |= I2C_CR1_ACK;
        
        (void)i2c_->SR1;
        (void)i2c_->SR2;
        
        // Read all bytes
        for (uint8_t i = 0; i < len; i++) {
            if (i == len - 1) {
                // Last byte: NACK and STOP
                i2c_->CR1 &= ~I2C_CR1_ACK;
                i2c_->CR1 |= I2C_CR1_STOP;
            }
            
            if (!waitForFlag(&i2c_->SR1, I2C_SR1_RXNE)) return false;
            data[i] = i2c_->DR;
        }
        
        // Re-enable ACK
        i2c_->CR1 |= I2C_CR1_ACK;
        
        return true;
    }
    
private:
    I2C_TypeDef* i2c_;
    uint8_t device_address_;
    
    static constexpr uint32_t TIMEOUT = 100000;
    
    /**
     * @brief Initialize GPIO for I2C
     * 
     * I2C pins must be configured as:
     * - Alternate Function with open-drain output
     * - Pull-up enabled (or external 4.7kΩ resistors)
     * 
     * I2C1 pins:
     * PB6 = I2C1_SCL (AF4)
     * PB7 = I2C1_SDA (AF4)
     */
    void initGpio() {
        // Enable GPIOB clock
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
        
        // Configure PB6 and PB7 as alternate function
        GPIOB->MODER &= ~(GPIO_MODER_MODER6 | GPIO_MODER_MODER7);
        GPIOB->MODER |= (GPIO_MODER_MODER6_1 | GPIO_MODER_MODER7_1);
        
        // Select AF4 (I2C1)
        GPIOB->AFR[0] &= ~((0xF << 24) | (0xF << 28));
        GPIOB->AFR[0] |= ((4 << 24) | (4 << 28));
        
        // CRITICAL: Set output type to open-drain
        // I2C requires open-drain to allow bidirectional communication
        GPIOB->OTYPER |= (GPIO_OTYPER_OT_6 | GPIO_OTYPER_OT_7);
        
        // High speed
        GPIOB->OSPEEDR |= (GPIO_OSPEEDER_OSPEEDR6 | GPIO_OSPEEDER_OSPEEDR7);
        
        // Enable pull-ups (4.7kΩ external resistors preferred)
        GPIOB->PUPDR &= ~(GPIO_PUPDR_PUPDR6 | GPIO_PUPDR_PUPDR7);
        GPIOB->PUPDR |= (GPIO_PUPDR_PUPDR6_0 | GPIO_PUPDR_PUPDR7_0);
    }
    
    /**
     * @brief Initialize I2C peripheral
     * 
     * I2C CLOCK CONFIGURATION:
     * ------------------------
     * 
     * For standard mode (100 kHz):
     * CCR = T_high / T_i2c
     * Where T_i2c = 1 / (APB1_freq)
     * 
     * Example: APB1 = 42 MHz, want 100 kHz I2C
     * T_i2c = 1/42MHz = 23.8 ns
     * T_high = 5 μs (half of 10 μs period)
     * CCR = 5μs / 23.8ns = 210
     * 
     * TRISE = (max rise time / T_i2c) + 1
     * Max rise time for 100 kHz = 1000 ns
     * TRISE = (1000ns / 23.8ns) + 1 = 43
     */
    void initI2c() {
        // Enable I2C1 clock
        RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
        
        // Reset I2C
        i2c_->CR1 = I2C_CR1_SWRST;
        i2c_->CR1 = 0;
        
        // Configure frequency (APB1 clock in MHz)
        // APB1 typically 42 MHz
        i2c_->CR2 &= ~I2C_CR2_FREQ;
        i2c_->CR2 |= 42;  // 42 MHz
        
        // Configure clock control for 100 kHz
        // Standard mode (SM = 0)
        // CCR = APB1_freq / (2 * I2C_freq)
        // CCR = 42MHz / (2 * 100kHz) = 210
        i2c_->CCR &= ~I2C_CCR_FS;  // Standard mode
        i2c_->CCR &= ~I2C_CCR_CCR;
        i2c_->CCR |= 210;
        
        // Configure rise time
        // TRISE = (max_rise_time_ns / T_i2c_ns) + 1
        // Max rise time = 1000 ns for 100 kHz
        // T_i2c = 1/42MHz = 23.8 ns
        // TRISE = 43
        i2c_->TRISE = 43;
        
        // Enable I2C peripheral
        i2c_->CR1 |= I2C_CR1_PE;
        
        // Enable ACK
        i2c_->CR1 |= I2C_CR1_ACK;
    }
    
    /**
     * @brief Wait for flag with timeout
     */
    bool waitForFlag(volatile uint32_t* reg, uint32_t flag) {
        uint32_t timeout = TIMEOUT;
        while (!(*reg & flag)) {
            if (--timeout == 0) return false;
        }
        return true;
    }
    
    /**
     * @brief Wait while I2C bus busy
     */
    bool waitWhileBusy() {
        uint32_t timeout = TIMEOUT;
        while (i2c_->SR2 & I2C_SR2_BUSY) {
            if (--timeout == 0) return false;
        }
        return true;
    }
};

#endif // I2C_SENSOR_HPP
