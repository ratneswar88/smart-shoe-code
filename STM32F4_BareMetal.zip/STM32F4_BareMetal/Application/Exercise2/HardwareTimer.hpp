#ifndef HARDWARE_TIMER_HPP
#define HARDWARE_TIMER_HPP

#include "stm32f4xx.h"
#include <cstdint>

/**
 * @file HardwareTimer.hpp
 * @brief Bare metal timer driver with PWM support
 * 
 * TIMER HARDWARE EXPLANATION:
 * ===========================
 * 
 * STM32F4 has multiple timer types:
 * - Basic timers (TIM6, TIM7): Simple up counter
 * - General-purpose (TIM2-5, TIM9-14): PWM, input capture, etc.
 * - Advanced (TIM1, TIM8): Full-featured with complementary outputs
 * 
 * Timer Block Diagram:
 * --------------------
 * 
 *  Clock Source
 *       ↓
 *   Prescaler (PSC)  ← Divides clock by (PSC + 1)
 *       ↓
 *    Counter (CNT)   ← Counts 0 to ARR
 *       ↓
 * Auto-Reload (ARR) ← Counter resets when CNT == ARR
 *       ↓
 *   Compare (CCR)   ← Triggers event when CNT == CCR
 *       ↓
 *   PWM Output      ← Pin toggles based on counter
 * 
 * Key Registers:
 * --------------
 * CR1   - Control Register 1 (enable, direction, mode)
 * CR2   - Control Register 2
 * DIER  - DMA/Interrupt Enable Register
 * SR    - Status Register (flags)
 * CNT   - Counter Register (current count value)
 * PSC   - Prescaler Register
 * ARR   - Auto-Reload Register (period)
 * CCR1-4 - Capture/Compare Registers (duty cycle for PWM)
 * CCMR1-2 - Capture/Compare Mode Registers (configure channels)
 * CCER  - Capture/Compare Enable Register
 * 
 * PWM Mode:
 * ---------
 * PWM generates a square wave with variable duty cycle.
 * 
 * In PWM Mode 1:
 * - Output HIGH when CNT < CCR
 * - Output LOW when CNT >= CCR
 * 
 * Duty Cycle = (CCR / ARR) * 100%
 * 
 * Example: ARR = 1000, CCR = 250 → 25% duty cycle
 * 
 *     HIGH ▄▄▄▄▄▄▄▄▄▄▄╗         ▄▄▄▄▄▄▄▄▄▄▄╗
 *     LOW             ╚▄▄▄▄▄▄▄▄▄╝          ╚▄▄▄▄
 *         ├─── 25% ───┼─ 75% ──┤
 *         └──────── Period ─────┘
 * 
 * Timer Math:
 * -----------
 * Timer Input Clock = APB_CLK * multiplier
 *   - If APB prescaler = 1: multiplier = 1
 *   - If APB prescaler > 1: multiplier = 2
 * 
 * Timer Frequency = Timer_CLK / ((PSC + 1) * (ARR + 1))
 * 
 * Example: 1 kHz timer with 84 MHz clock
 * 84 MHz / ((84-1) * (1000-1)) = 1 kHz
 */
class HardwareTimer {
public:
    /**
     * @brief Constructor
     * @param timer Timer peripheral (TIM2, TIM3, etc.)
     */
    explicit HardwareTimer(TIM_TypeDef* timer)
        : timer_(timer)
    {
        enableClock();
    }
    
    /**
     * @brief Initialize timer for periodic interrupts
     * @param frequency_hz Desired frequency in Hz
     * 
     * EXAMPLE: 1 kHz timer (1 ms period)
     * ==================================
     * Clock = 84 MHz (TIM2 on APB1 with 2x multiplier)
     * 
     * We want 1 kHz = 1000 interrupts per second
     * 
     * Step 1: Choose prescaler
     * Let's use PSC = 84-1 = 83
     * Timer tick = 84 MHz / 84 = 1 MHz
     * 
     * Step 2: Calculate ARR
     * ARR = (1 MHz / 1 kHz) - 1 = 1000 - 1 = 999
     * 
     * Result: Timer counts 0-999 at 1 MHz = 1 ms period
     */
    void initPeriodic(uint32_t frequency_hz) {
        // Assume 84 MHz timer clock (typical for APB1/2 timers)
        const uint32_t timer_clk = 84000000;
        
        // Choose prescaler to get reasonable counter values
        // Using 84 gives us 1 MHz tick rate (1 μs resolution)
        uint32_t prescaler = 84 - 1;
        uint32_t tick_rate = timer_clk / (prescaler + 1);
        
        // Calculate period (ARR value)
        uint32_t period = (tick_rate / frequency_hz) - 1;
        
        // Disable timer during configuration
        timer_->CR1 &= ~TIM_CR1_CEN;
        
        // Set prescaler and period
        timer_->PSC = prescaler;
        timer_->ARR = period;
        
        // Generate update event to load registers
        timer_->EGR = TIM_EGR_UG;
        
        // Enable update interrupt
        timer_->DIER |= TIM_DIER_UIE;
        
        // Enable NVIC interrupt
        enableNvicInterrupt();
        
        // Start timer
        // CEN: Counter Enable
        timer_->CR1 |= TIM_CR1_CEN;
    }
    
    /**
     * @brief Initialize PWM on channel 1
     * @param frequency_hz PWM frequency
     * @param duty_percent Duty cycle (0-100)
     * 
     * PWM CONFIGURATION:
     * ==================
     * 
     * Mode 1: Output HIGH when CNT < CCR
     * 
     * Steps:
     * 1. Configure timer period (frequency)
     * 2. Set CCR for duty cycle
     * 3. Configure channel as PWM output
     * 4. Enable channel output
     * 5. Configure GPIO as alternate function
     * 
     * Example GPIO for TIM2 CH1:
     * PA5 = TIM2_CH1 (Alternate Function 1)
     */
    void initPwm(uint32_t frequency_hz, uint8_t duty_percent) {
        if (duty_percent > 100) duty_percent = 100;
        
        const uint32_t timer_clk = 84000000;
        
        // For PWM, we want higher resolution
        // Use smaller prescaler for finer duty cycle control
        uint32_t prescaler = 0;  // No prescaling
        uint32_t period = (timer_clk / frequency_hz) - 1;
        
        // If period too large, use prescaler
        while (period > 0xFFFF) {
            prescaler++;
            period = (timer_clk / ((prescaler + 1) * frequency_hz)) - 1;
        }
        
        // Calculate compare value for duty cycle
        uint32_t compare = (period * duty_percent) / 100;
        
        // Disable timer
        timer_->CR1 &= ~TIM_CR1_CEN;
        
        // Set prescaler and period
        timer_->PSC = prescaler;
        timer_->ARR = period;
        timer_->CCR1 = compare;
        
        // Configure Channel 1 as PWM Mode 1
        // CCMR1 register controls CH1 and CH2
        // OC1M (bits 4-6) = 110b (PWM mode 1)
        // OC1PE (bit 3) = 1 (preload enable)
        timer_->CCMR1 &= ~TIM_CCMR1_OC1M;
        timer_->CCMR1 |= (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2);
        timer_->CCMR1 |= TIM_CCMR1_OC1PE;
        
        // Enable Channel 1 output
        // CC1E (bit 0) = 1
        timer_->CCER |= TIM_CCER_CC1E;
        
        // Enable auto-reload preload
        timer_->CR1 |= TIM_CR1_ARPE;
        
        // Generate update to load registers
        timer_->EGR = TIM_EGR_UG;
        
        // Start timer
        timer_->CR1 |= TIM_CR1_CEN;
        
        // Configure GPIO (if TIM2, use PA5)
        if (timer_ == TIM2) {
            configureGpioForPwm();
        }
    }
    
    /**
     * @brief Set PWM duty cycle
     * @param duty_percent Duty cycle (0-100)
     * 
     * Changes CCR value to adjust duty cycle.
     * Thanks to preload, change takes effect at next update event.
     */
    void setPwmDuty(uint8_t duty_percent) {
        if (duty_percent > 100) duty_percent = 100;
        
        uint32_t period = timer_->ARR;
        uint32_t compare = (period * duty_percent) / 100;
        
        timer_->CCR1 = compare;
    }
    
    /**
     * @brief Clear interrupt flag
     * 
     * MUST be called in ISR to clear interrupt pending bit.
     * Otherwise, ISR will be called continuously!
     * 
     * extern "C" void TIM2_IRQHandler(void) {
     *     if (TIM2->SR & TIM_SR_UIF) {
     *         timer.clearInterruptFlag();
     *         // Your code here
     *     }
     * }
     */
    void clearInterruptFlag() {
        // Clear update interrupt flag
        timer_->SR &= ~TIM_SR_UIF;
    }
    
    /**
     * @brief Get current counter value
     * 
     * Useful for:
     * - Measuring time elapsed
     * - Synchronizing events
     * - Debugging
     */
    uint32_t getCount() const {
        return timer_->CNT;
    }
    
    /**
     * @brief Stop timer
     */
    void stop() {
        timer_->CR1 &= ~TIM_CR1_CEN;
    }
    
    /**
     * @brief Start timer
     */
    void start() {
        timer_->CR1 |= TIM_CR1_CEN;
    }
    
private:
    TIM_TypeDef* timer_;
    
    /**
     * @brief Enable timer peripheral clock
     * 
     * CLOCK TREE:
     * -----------
     * TIM2-7, TIM12-14 → APB1 (42 MHz typically)
     * TIM1, TIM8-11 → APB2 (84 MHz typically)
     * 
     * Important: If APB prescaler != 1, timer clock is 2x APB clock!
     * So TIM2-7 actually run at 84 MHz, not 42 MHz.
     */
    void enableClock() {
        if (timer_ == TIM2) {
            RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;
        } else if (timer_ == TIM3) {
            RCC->APB1ENR |= RCC_APB1ENR_TIM3EN;
        } else if (timer_ == TIM4) {
            RCC->APB1ENR |= RCC_APB1ENR_TIM4EN;
        } else if (timer_ == TIM5) {
            RCC->APB1ENR |= RCC_APB1ENR_TIM5EN;
        }
        // Add more as needed
    }
    
    /**
     * @brief Enable NVIC interrupt for timer
     */
    void enableNvicInterrupt() {
        if (timer_ == TIM2) {
            NVIC_EnableIRQ(TIM2_IRQn);
        } else if (timer_ == TIM3) {
            NVIC_EnableIRQ(TIM3_IRQn);
        } else if (timer_ == TIM4) {
            NVIC_EnableIRQ(TIM4_IRQn);
        } else if (timer_ == TIM5) {
            NVIC_EnableIRQ(TIM5_IRQn);
        }
    }
    
    /**
     * @brief Configure GPIO for PWM output
     * 
     * TIM2_CH1 can be mapped to PA5 (AF1)
     */
    void configureGpioForPwm() {
        // Enable GPIOA clock
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
        
        // Configure PA5 as alternate function
        GPIOA->MODER &= ~GPIO_MODER_MODER5;
        GPIOA->MODER |= GPIO_MODER_MODER5_1;  // 10b = AF
        
        // Select AF1 (TIM2) for PA5
        // AFR[0] for pins 0-7
        GPIOA->AFR[0] &= ~(0xF << 20);  // Clear bits 20-23
        GPIOA->AFR[0] |= (1 << 20);     // AF1
        
        // High speed output
        GPIOA->OSPEEDR |= GPIO_OSPEEDER_OSPEEDR5;
        
        // Push-pull
        GPIOA->OTYPER &= ~GPIO_OTYPER_OT_5;
    }
};

#endif // HARDWARE_TIMER_HPP
