#ifndef RAII_WRAPPERS_HPP
#define RAII_WRAPPERS_HPP

#include "stm32f4_regs.hpp"
#include <cstdint>

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * EXERCISE 2: RAII WRAPPERS (Bare Metal)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * LEARNING OBJECTIVES:
 * --------------------
 * 1. RAII (Resource Acquisition Is Initialization)
 * 2. Automatic resource cleanup
 * 3. Exception-safe code (even without exceptions enabled!)
 * 4. Interrupt management in bare metal
 * 5. Critical sections without RTOS
 * 
 * WHAT IS RAII?
 * -------------
 * RAII is a C++ idiom where resource lifetime is tied to object lifetime:
 * - Constructor acquires resource
 * - Destructor releases resource
 * - Compiler guarantees destructor runs when object goes out of scope
 * 
 * WHY RAII IS POWERFUL:
 * ---------------------
 * ✓ Can't forget to release resource
 * ✓ Works with early returns
 * ✓ Works with exceptions (if enabled)
 * ✓ Self-documenting code
 * ✓ No manual cleanup code
 * 
 * EXAMPLE WITHOUT RAII:
 * 
 *   void doWork() {
 *       __disable_irq();
 *       // Do critical work
 *       if (error) {
 *           __enable_irq();  // Must remember!
 *           return;
 *       }
 *       // More work
 *       __enable_irq();  // Must remember!
 *   }
 * 
 * EXAMPLE WITH RAII:
 * 
 *   void doWork() {
 *       CriticalSection cs;  // IRQs disabled
 *       // Do critical work
 *       if (error) {
 *           return;  // Destructor automatically enables IRQs!
 *       }
 *       // More work
 *   }  // Destructor automatically enables IRQs!
 * 
 * THREAD SAFETY IN BARE METAL:
 * -----------------------------
 * Without an RTOS, we don't have mutexes or semaphores.
 * Instead, we use:
 * - Disable interrupts (for very short critical sections)
 * - Atomic operations (single instruction, can't be interrupted)
 * - Careful design to avoid sharing data
 */

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * CRITICAL SECTION (Interrupt Disable)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * WHAT DOES IT DO?
 * ----------------
 * Disables ALL interrupts during critical section.
 * Useful for protecting shared variables accessed by ISRs and main code.
 * 
 * HOW IT WORKS:
 * -------------
 * ARM Cortex-M has special instructions:
 * - CPSID I: Disable interrupts (set PRIMASK register)
 * - CPSIE I: Enable interrupts (clear PRIMASK register)
 * 
 * These are exposed as intrinsics:
 * - __disable_irq()
 * - __enable_irq()
 * 
 * CRITICAL: Keep Critical Sections SHORT!
 * ----------------------------------------
 * While interrupts are disabled:
 * ✗ UART bytes can be lost
 * ✗ Timer interrupts missed
 * ✗ System becomes unresponsive
 * 
 * Rule of thumb: < 100 CPU cycles (< 1 microsecond @ 168 MHz)
 * 
 * NESTED CRITICAL SECTIONS:
 * --------------------------
 * Problem: If interrupt was already disabled, we shouldn't enable it!
 * 
 * Bad:
 *   void func1() {
 *       __disable_irq();
 *       func2();  // Calls __disable_irq() again
 *       __enable_irq();  // Enables too early!
 *   }
 * 
 * Solution: Save and restore previous state
 */

class CriticalSection {
public:
    /**
     * Constructor: Disable interrupts and save previous state
     * 
     * EXPLANATION OF INLINE ASSEMBLY:
     * --------------------------------
     * We use inline assembly to access PRIMASK register directly.
     * 
     * __asm__ volatile (
     *     "MRS %0, PRIMASK"  // Move PRIMASK to saved_state_
     *     "CPSID I"          // Disable interrupts
     *     : "=r"(saved_state_)  // Output: saved_state_
     *     :                     // No inputs
     *     : "memory"            // Clobber: prevents reordering
     * );
     * 
     * MRS: Move from special Register to general register
     * PRIMASK: Interrupt mask register (0 = enabled, 1 = disabled)
     * CPSID I: Change Processor State, Interrupt Disable
     * 
     * WHY VOLATILE?
     * Assembly marked volatile = don't optimize away or reorder
     * 
     * WHY "memory" CLOBBER?
     * Tells compiler: assume all memory changed
     * Prevents compiler from moving memory accesses across this barrier
     */
    CriticalSection() {
        // Read current PRIMASK value and disable interrupts atomically
        __asm__ volatile (
            "MRS %0, PRIMASK\n"  // Read PRIMASK into saved_state_
            "CPSID I\n"          // Disable interrupts
            : "=r"(saved_state_)
            :
            : "memory"
        );
    }
    
    /**
     * Destructor: Restore previous interrupt state
     * 
     * EXPLANATION:
     * ------------
     * We restore PRIMASK to its original value.
     * If interrupts were already disabled, they stay disabled.
     * If they were enabled, we re-enable them.
     * 
     * This correctly handles nested critical sections!
     */
    ~CriticalSection() {
        // Restore previous PRIMASK value
        __asm__ volatile (
            "MSR PRIMASK, %0\n"  // Write saved_state_ to PRIMASK
            :
            : "r"(saved_state_)
            : "memory"
        );
    }
    
    /**
     * Delete copy operations - this is a RAII resource!
     * 
     * WHY?
     * ----
     * Copying a CriticalSection makes no sense.
     * It's not a value - it's a control flow construct.
     * 
     * If we allowed copying:
     *   CriticalSection cs1;
     *   CriticalSection cs2 = cs1;  // Two objects, one resource!
     *   // Both destructors try to restore state
     *   // Wrong behavior!
     */
    CriticalSection(const CriticalSection&) = delete;
    CriticalSection& operator=(const CriticalSection&) = delete;
    
private:
    uint32_t saved_state_;  // Saved PRIMASK value
};

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * INTERRUPT GUARD (Specific Interrupt)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * WHAT'S THE PROBLEM WITH CriticalSection?
 * -----------------------------------------
 * It disables ALL interrupts. This can:
 * - Make system unresponsive
 * - Cause high-priority interrupts to be missed
 * - Reduce overall throughput
 * 
 * BETTER SOLUTION:
 * ----------------
 * Disable only the specific interrupt we need to protect against.
 * Other interrupts can still run!
 * 
 * Example: Protecting data shared between main code and USART2 ISR.
 * We only need to disable USART2 interrupt, not ALL interrupts.
 * 
 * HOW TO DISABLE SPECIFIC INTERRUPT:
 * -----------------------------------
 * NVIC has multiple registers:
 * - ISER: Interrupt Set-Enable (write 1 to enable)
 * - ICER: Interrupt Clear-Enable (write 1 to disable)
 * 
 * Each bit controls one interrupt.
 */

class InterruptGuard {
public:
    /**
     * Constructor: Disable specific interrupt
     * 
     * @param irq_number IRQ number (e.g., 38 for USART2)
     * 
     * EXPLANATION:
     * ------------
     * 1. Calculate which NVIC register (ICER0, ICER1, ICER2)
     * 2. Calculate bit position in that register
     * 3. Disable interrupt by writing 1 to ICER
     */
    explicit InterruptGuard(uint8_t irq_number)
        : irq_number_(irq_number)
    {
        // Calculate register index (0, 1, or 2)
        uint8_t reg_index = irq_number_ / 32;
        
        // Calculate bit position within register
        uint8_t bit_pos = irq_number_ % 32;
        
        // Disable interrupt
        volatile uint32_t* NVIC_ICER = (volatile uint32_t*)(0xE000E180 + reg_index * 4);
        *NVIC_ICER = (1U << bit_pos);
        
        /**
         * NOTE: We don't save previous state!
         * NVIC doesn't have a "read enable state" register.
         * 
         * Alternative: Read ISER to check if enabled, save that.
         * For simplicity, we just re-enable in destructor.
         */
    }
    
    /**
     * Destructor: Re-enable interrupt
     */
    ~InterruptGuard() {
        // Calculate register index
        uint8_t reg_index = irq_number_ / 32;
        
        // Calculate bit position
        uint8_t bit_pos = irq_number_ % 32;
        
        // Re-enable interrupt
        volatile uint32_t* NVIC_ISER = (volatile uint32_t*)(0xE000E100 + reg_index * 4);
        *NVIC_ISER = (1U << bit_pos);
    }
    
    InterruptGuard(const InterruptGuard&) = delete;
    InterruptGuard& operator=(const InterruptGuard&) = delete;
    
private:
    uint8_t irq_number_;
};

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * GPIO PIN GUARD
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * USE CASE:
 * ---------
 * Some devices need a control signal during operations.
 * Example: Chip Select (CS) for SPI, Reset (RST) for LCD
 * 
 * Pattern:
 * 1. Assert signal (set low or high)
 * 2. Do operation (send data, etc.)
 * 3. De-assert signal (set opposite)
 * 
 * With RAII, we can't forget step 3!
 * 
 * EXAMPLE: SPI Chip Select
 * -------------------------
 *   {
 *       GpioGuard cs(GPIOA, 4, false);  // Assert CS (active low)
 *       spi_send_byte(0x42);
 *       spi_send_byte(0x13);
 *   }  // CS automatically de-asserted!
 * 
 * Even if spi_send_byte() fails and returns early,
 * CS is still de-asserted correctly!
 */

class GpioGuard {
public:
    /**
     * Constructor: Set pin to specified state
     * 
     * @param port GPIO port (GPIOA, GPIOB, etc.)
     * @param pin Pin number (0-15)
     * @param active_high true = assert high, false = assert low
     * 
     * EXPLANATION:
     * ------------
     * We use BSRR register for atomic pin control.
     * BSRR layout:
     * [15:0]: Set bits (write 1 to set pin high)
     * [31:16]: Reset bits (write 1 to set pin low)
     */
    GpioGuard(GPIO_Registers* port, uint8_t pin, bool active_high)
        : port_(port)
        , pin_(pin)
        , active_high_(active_high)
    {
        // Assert pin
        if (active_high_) {
            port_->BSRR = (1U << pin_);  // Set high
        } else {
            port_->BSRR = (1U << (pin_ + 16));  // Set low
        }
    }
    
    /**
     * Destructor: Restore pin to opposite state
     */
    ~GpioGuard() {
        // De-assert pin (opposite of asserted state)
        if (active_high_) {
            port_->BSRR = (1U << (pin_ + 16));  // Set low
        } else {
            port_->BSRR = (1U << pin_);  // Set high
        }
    }
    
    GpioGuard(const GpioGuard&) = delete;
    GpioGuard& operator=(const GpioGuard&) = delete;
    
private:
    GPIO_Registers* port_;
    uint8_t pin_;
    bool active_high_;
};

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * ATOMIC FLAG
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * PROBLEM:
 * --------
 * Sharing a flag between ISR and main code needs protection.
 * 
 * Bad code:
 *   volatile bool flag = false;
 *   
 *   void ISR() {
 *       flag = true;  // Sets flag
 *   }
 *   
 *   void main() {
 *       if (flag) {
 *           flag = false;  // RACE CONDITION!
 *           // ISR could set it true between read and write!
 *       }
 *   }
 * 
 * SOLUTION:
 * ---------
 * Use atomic test-and-set operations.
 * ARM Cortex-M4 has LDREX/STREX instructions for this.
 * 
 * LDREX: Load Exclusive (marks memory location)
 * STREX: Store Exclusive (succeeds only if no intervening access)
 * 
 * This is lock-free synchronization!
 */

class AtomicFlag {
public:
    AtomicFlag() : flag_(0) {}
    
    /**
     * Set flag atomically
     */
    void set() {
        __asm__ volatile (
            "MOV r1, #1\n"           // r1 = 1
            "STR r1, [%0]\n"         // Store 1 to flag_
            :
            : "r"(&flag_)
            : "r1", "memory"
        );
    }
    
    /**
     * Clear flag atomically
     */
    void clear() {
        __asm__ volatile (
            "MOV r1, #0\n"           // r1 = 0
            "STR r1, [%0]\n"         // Store 0 to flag_
            :
            : "r"(&flag_)
            : "r1", "memory"
        );
    }
    
    /**
     * Test-and-clear: Returns true if flag was set, then clears it
     * 
     * This is the KEY operation for ISR-to-main signaling!
     * 
     * USAGE IN MAIN:
     *   if (myFlag.testAndClear()) {
     *       // Flag was set by ISR, process event
     *   }
     */
    bool testAndClear() {
        uint32_t result;
        uint32_t temp;
        
        __asm__ volatile (
            "1:\n"
            "LDREX %0, [%2]\n"       // Load exclusive
            "MOV %1, #0\n"           // temp = 0
            "STREX r3, %1, [%2]\n"   // Store exclusive
            "CMP r3, #0\n"           // Check if store succeeded
            "BNE 1b\n"               // Retry if failed
            : "=&r"(result), "=&r"(temp)
            : "r"(&flag_)
            : "r3", "cc", "memory"
        );
        
        return (result != 0);
    }
    
    /**
     * Test (read) flag without modifying
     */
    bool test() const {
        return (flag_ != 0);
    }
    
private:
    volatile uint32_t flag_;
};

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * USAGE EXAMPLES
 * ═════════════════════════════════════════════════════════════════════════════
 */

// Example 1: Protecting shared counter
volatile uint32_t shared_counter = 0;

void incrementCounter() {
    CriticalSection cs;  // Disable interrupts
    shared_counter++;
    // Interrupts automatically re-enabled when cs goes out of scope
}

// Example 2: Protecting UART TX buffer
uint8_t uart_tx_buffer[256];
volatile uint16_t uart_tx_head = 0;
volatile uint16_t uart_tx_tail = 0;

void sendByte(uint8_t data) {
    InterruptGuard guard(38);  // Disable USART2 interrupt only
    
    uint16_t next_head = (uart_tx_head + 1) % 256;
    if (next_head != uart_tx_tail) {
        uart_tx_buffer[uart_tx_head] = data;
        uart_tx_head = next_head;
    }
    // USART2 interrupt automatically re-enabled
}

// Example 3: SPI transaction with CS
void spiWrite(uint8_t data) {
    GpioGuard cs(GPIOA, 4, false);  // CS low (active low)
    
    // Send data via SPI
    // Even if SPI times out, CS is de-asserted correctly!
    
}  // CS automatically goes high

// Example 4: Event signaling from ISR to main
AtomicFlag dataReady;

extern "C" void ADC_IRQHandler() {
    // Read ADC value
    uint16_t value = readADC();
    
    // Signal main code
    dataReady.set();
}

void processData() {
    if (dataReady.testAndClear()) {
        // New ADC data available, process it
        // Flag is cleared atomically, no race condition!
    }
}

#endif // RAII_WRAPPERS_HPP
