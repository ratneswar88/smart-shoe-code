#ifndef ADC_DMA_HPP
#define ADC_DMA_HPP

#include "stm32f4xx.h"
#include <cstdint>

/**
 * @file AdcDma.hpp
 * @brief Bare metal ADC with DMA - Zero CPU overhead data transfer
 * 
 * ADC HARDWARE EXPLANATION:
 * =========================
 * 
 * The ADC (Analog-to-Digital Converter) converts analog voltage to digital value.
 * STM32F4 has 12-bit ADC (0-4095 for 0-3.3V).
 * 
 * ADC Conversion Process:
 * -----------------------
 * 1. Sample: Charge internal capacitor from analog pin
 * 2. Hold: Disconnect pin, hold voltage
 * 3. Convert: Compare voltage to reference in steps
 * 4. Store: Write digital value to data register
 * 
 * Conversion Time = Sampling Time + 12 ADC cycles
 * 
 * Example: 3 cycle sampling @ 21 MHz ADC clock
 * Total = 3 + 12 = 15 cycles = 0.71 μs
 * 
 * DMA (Direct Memory Access):
 * ---------------------------
 * DMA transfers data from peripheral to memory without CPU.
 * 
 * Traditional (without DMA):
 * 1. ADC converts → sets flag
 * 2. CPU interrupted
 * 3. ISR reads ADC data register
 * 4. ISR stores in array
 * 5. Return from interrupt
 * 
 * With DMA:
 * 1. ADC converts → triggers DMA request
 * 2. DMA controller reads ADC data register
 * 3. DMA writes to memory buffer
 * 4. CPU continues working undisturbed!
 * 
 * DMA Stream Configuration:
 * -------------------------
 * - Source: Peripheral data register (ADC->DR)
 * - Destination: Memory buffer (our array)
 * - Transfer size: Number of conversions
 * - Mode: Circular (auto-restart) or Normal (one-shot)
 * - Priority: Low, Medium, High, Very High
 * - Data size: Byte, Half-word, Word
 * 
 * Memory Map:
 * -----------
 * ADC1 base: 0x40012000
 * DMA2 base: 0x40026400
 * 
 * ADC1 uses DMA2 Stream 0 or 4, Channel 0
 */
class AdcDma {
public:
    /**
     * @brief Constructor
     * @param buffer_size Number of samples to collect
     */
    explicit AdcDma(uint16_t buffer_size = 100)
        : buffer_size_(buffer_size)
    {
        // Allocate buffer
        buffer_ = new uint16_t[buffer_size_];
        
        initGpio();
        initAdc();
        initDma();
    }
    
    ~AdcDma() {
        delete[] buffer_;
    }
    
    /**
     * @brief Start continuous ADC conversion
     * 
     * HARDWARE FLOW:
     * 1. Timer triggers ADC conversion
     * 2. ADC converts and generates DMA request
     * 3. DMA transfers result to buffer
     * 4. When buffer full, DMA restarts from beginning (circular mode)
     * 5. Optional: DMA interrupt on half-full or full
     */
    void startContinuous() {
        // Start ADC conversion
        // SWSTART: Software start (for demo, could use timer trigger)
        ADC1->CR2 |= ADC_CR2_SWSTART;
    }
    
    /**
     * @brief Stop ADC conversion
     */
    void stop() {
        // Stop ADC
        ADC1->CR2 &= ~ADC_CR2_ADON;
        
        // Disable DMA stream
        DMA2_Stream0->CR &= ~DMA_SxCR_EN;
    }
    
    /**
     * @brief Get buffer for reading samples
     */
    const uint16_t* getBuffer() const {
        return buffer_;
    }
    
    /**
     * @brief Get single sample from buffer
     */
    uint16_t getSample(uint16_t index) const {
        if (index < buffer_size_) {
            return buffer_[index];
        }
        return 0;
    }
    
    /**
     * @brief Convert ADC value to voltage
     * @param adc_value Raw ADC reading (0-4095)
     * @return Voltage in millivolts
     * 
     * Calculation:
     * V = (adc_value / 4095) * 3300 mV
     */
    static uint16_t toMillivolts(uint16_t adc_value) {
        return (adc_value * 3300) / 4095;
    }
    
private:
    uint16_t* buffer_;
    uint16_t buffer_size_;
    
    /**
     * @brief Initialize GPIO for ADC input
     * 
     * ADC channels are mapped to GPIO pins:
     * PA0 = ADC1_IN0
     * PA1 = ADC1_IN1
     * ...
     * 
     * GPIO must be configured as ANALOG mode (no pull-up/down).
     * This disconnects digital input buffer to reduce noise.
     */
    void initGpio() {
        // Enable GPIOA clock
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
        
        // Configure PA0 as analog input
        // MODER register: 11b = analog mode
        GPIOA->MODER |= GPIO_MODER_MODER0;
        
        // No pull-up/pull-down
        GPIOA->PUPDR &= ~GPIO_PUPDR_PUPDR0;
    }
    
    /**
     * @brief Initialize ADC peripheral
     * 
     * ADC CONFIGURATION:
     * ------------------
     * 
     * Common Control Register (CCR):
     * - ADCPRE: ADC prescaler (divide APB2 clock)
     * - DMA: DMA mode
     * - DDS: DMA disable selection
     * 
     * Control Register 1 (CR1):
     * - RES: Resolution (12-bit, 10-bit, 8-bit, 6-bit)
     * - SCAN: Scan mode (multi-channel)
     * 
     * Control Register 2 (CR2):
     * - ADON: ADC ON/OFF
     * - CONT: Continuous conversion
     * - DMA: Enable DMA
     * - DDS: DMA requests issued as long as data in DR
     * - EXTEN: External trigger enable
     * 
     * Sample Time Register (SMPR):
     * - SMP: Sampling time (3, 15, 28, 56, 84, 112, 144, 480 cycles)
     * 
     * Longer sampling = more accurate but slower
     */
    void initAdc() {
        // Enable ADC1 clock
        RCC->APB2ENR |= RCC_APB2ENR_ADC1EN;
        
        // Configure ADC prescaler: divide by 4
        // APB2 = 84 MHz → ADC clock = 21 MHz (max 36 MHz)
        ADC->CCR &= ~ADC_CCR_ADCPRE;
        ADC->CCR |= ADC_CCR_ADCPRE_0;  // 01b = /4
        
        // 12-bit resolution (default)
        ADC1->CR1 &= ~ADC_CR1_RES;
        
        // Enable DMA for ADC
        ADC1->CR2 |= ADC_CR2_DMA;
        
        // DMA requests issued as long as data available
        ADC1->CR2 |= ADC_CR2_DDS;
        
        // Continuous conversion mode
        ADC1->CR2 |= ADC_CR2_CONT;
        
        // Set sampling time for channel 0
        // SMP0 (bits 0-2) = 011b (56 cycles)
        // Total conversion time = 56 + 12 = 68 cycles
        // At 21 MHz: 68/21M = 3.2 μs per conversion
        ADC1->SMPR2 &= ~ADC_SMPR2_SMP0;
        ADC1->SMPR2 |= (3 << 0);
        
        // Select channel 0 in regular sequence
        // L (bits 20-23) = 0 (1 conversion)
        ADC1->SQR1 &= ~ADC_SQR1_L;
        
        // First conversion = channel 0
        // SQ1 (bits 0-4) of SQR3
        ADC1->SQR3 &= ~ADC_SQR3_SQ1;
        ADC1->SQR3 |= (0 << 0);
        
        // Power on ADC
        ADC1->CR2 |= ADC_CR2_ADON;
        
        // Wait for ADC to stabilize (tSTAB = 3 μs typical)
        for (volatile int i = 0; i < 1000; i++);
    }
    
    /**
     * @brief Initialize DMA for ADC
     * 
     * DMA STREAM CONFIGURATION:
     * -------------------------
     * 
     * DMA2 Stream 0, Channel 0 is connected to ADC1
     * 
     * CR (Control Register):
     * - CHSEL: Channel selection (0-7)
     * - PL: Priority level
     * - MSIZE/PSIZE: Memory/Peripheral data size
     * - MINC: Memory increment mode
     * - PINC: Peripheral increment mode
     * - CIRC: Circular mode
     * - DIR: Data transfer direction
     * - EN: Stream enable
     * 
     * NDTR (Number of Data Register):
     * - Number of data items to transfer
     * 
     * PAR (Peripheral Address Register):
     * - Address of peripheral data register
     * 
     * M0AR (Memory 0 Address Register):
     * - Address of memory buffer
     */
    void initDma() {
        // Enable DMA2 clock
        RCC->AHB1ENR |= RCC_AHB1ENR_DMA2EN;
        
        // Disable stream to configure
        DMA2_Stream0->CR &= ~DMA_SxCR_EN;
        while (DMA2_Stream0->CR & DMA_SxCR_EN);  // Wait until disabled
        
        // Clear all flags for stream 0
        DMA2->LIFCR = 0x3F;  // Bits 0-5 for stream 0
        
        // Configure stream
        uint32_t cr = 0;
        
        // Channel 0 (ADC1)
        cr &= ~DMA_SxCR_CHSEL;
        
        // Priority: High
        cr |= DMA_SxCR_PL_1;
        
        // Memory and peripheral data size: 16-bit (half-word)
        cr |= DMA_SxCR_MSIZE_0;  // 01b = 16-bit
        cr |= DMA_SxCR_PSIZE_0;  // 01b = 16-bit
        
        // Memory increment mode (move to next array element)
        cr |= DMA_SxCR_MINC;
        
        // Peripheral no increment (always read from ADC->DR)
        cr &= ~DMA_SxCR_PINC;
        
        // Circular mode (restart when complete)
        cr |= DMA_SxCR_CIRC;
        
        // Direction: Peripheral to Memory
        cr &= ~DMA_SxCR_DIR;
        
        DMA2_Stream0->CR = cr;
        
        // Set number of data items
        DMA2_Stream0->NDTR = buffer_size_;
        
        // Set peripheral address (ADC1 data register)
        DMA2_Stream0->PAR = (uint32_t)&(ADC1->DR);
        
        // Set memory address (our buffer)
        DMA2_Stream0->M0AR = (uint32_t)buffer_;
        
        // Enable DMA stream
        DMA2_Stream0->CR |= DMA_SxCR_EN;
    }
};

#endif // ADC_DMA_HPP
