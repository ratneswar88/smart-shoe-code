#ifndef BAREMETAL_UART_HPP
#define BAREMETAL_UART_HPP

#include "stm32f4xx.h"
#include <cstdint>

/**
 * @file BareMetalUart.hpp
 * @brief Bare metal UART driver - Direct register access
 * 
 * HARDWARE EXPLANATION:
 * ====================
 * 
 * The USART peripheral communicates serially (one bit at a time).
 * It connects to GPIO pins configured as "Alternate Function".
 * 
 * Memory Map:
 * -----------
 * USART2 base address: 0x40004400
 * Registers (offset from base):
 *   +0x00: SR  - Status Register (read flags)
 *   +0x04: DR  - Data Register (read RX, write TX)
 *   +0x08: BRR - Baud Rate Register (clock divider)
 *   +0x0C: CR1 - Control Register 1 (enable, config)
 *   +0x10: CR2 - Control Register 2
 *   +0x14: CR3 - Control Register 3
 * 
 * How UART Works:
 * ---------------
 * 1. Baud Rate: Bits per second (e.g., 115200 bps)
 * 2. Frame: START bit + 8 data bits + STOP bit(s)
 * 3. TX: Shift register outputs bits at baud rate
 * 4. RX: Shift register samples bits at baud rate
 * 
 * Clock Calculation:
 * ------------------
 * USART2 is on APB1 bus (typically 42 MHz on STM32F407)
 * Baud Rate Register = APB1_CLK / (16 * desired_baud)
 * 
 * Example: 115200 baud with 42 MHz APB1
 * BRR = 42,000,000 / (16 * 115200) = 22.786
 * In fixed point: 22 + (0.786 * 16) = 0x016C
 */
class BareMetalUart {
public:
    /**
     * @brief Constructor
     * @param uart USART peripheral (USART1, USART2, etc.)
     * @param apb_clock APB clock frequency in Hz
     * @param baud_rate Desired baud rate
     */
    explicit BareMetalUart(USART_TypeDef* uart, 
                          uint32_t apb_clock = 42000000,
                          uint32_t baud_rate = 115200)
        : uart_(uart)
        , rx_head_(0)
        , rx_tail_(0)
    {
        initGpio();
        initUart(apb_clock, baud_rate);
    }
    
    /**
     * @brief Transmit single byte (blocking)
     * 
     * HARDWARE DETAILS:
     * - Waits for TXE flag (Transmit Data Register Empty)
     * - Writes to DR register
     * - Hardware automatically:
     *   1. Clears TXE flag
     *   2. Loads byte into shift register
     *   3. Serializes bits at baud rate
     *   4. Sets TXE when ready for next byte
     */
    void transmitByte(uint8_t byte) {
        // Wait for TX buffer empty
        // SR bit 7 (TXE) = 1 when ready
        while (!(uart_->SR & USART_SR_TXE)) {
            // Busy wait - could add timeout
        }
        
        // Writing to DR:
        // - Clears TXE flag automatically
        // - Triggers hardware transmission
        uart_->DR = byte;
    }
    
    /**
     * @brief Transmit string (blocking)
     */
    void transmitString(const char* str) {
        while (*str) {
            transmitByte(*str++);
        }
    }
    
    /**
     * @brief Check if RX data available
     * 
     * HARDWARE DETAILS:
     * - Reads RXNE flag (Receive Data Not Empty)
     * - SR bit 5 = 1 when byte received
     * - Cleared by reading DR register
     */
    bool rxAvailable() const {
        // Check circular buffer
        return (rx_head_ != rx_tail_);
    }
    
    /**
     * @brief Read received byte
     * 
     * Returns byte from circular buffer filled by interrupt.
     */
    uint8_t readByte() {
        if (!rxAvailable()) {
            return 0;
        }
        
        uint8_t data = rx_buffer_[rx_tail_];
        rx_tail_ = (rx_tail_ + 1) % RX_BUFFER_SIZE;
        return data;
    }
    
    /**
     * @brief Enable RX interrupt
     * 
     * HARDWARE DETAILS:
     * - Sets RXNEIE bit in CR1
     * - CPU jumps to ISR when RXNE flag set
     * - Must also enable in NVIC
     */
    void enableRxInterrupt() {
        // Enable RXNE interrupt in UART
        uart_->CR1 |= USART_CR1_RXNEIE;
        
        // Enable interrupt in NVIC (Nested Vectored Interrupt Controller)
        if (uart_ == USART2) {
            NVIC_EnableIRQ(USART2_IRQn);
        }
    }
    
    /**
     * @brief ISR callback - call from interrupt handler
     * 
     * This is called from the actual ISR:
     * extern "C" void USART2_IRQHandler(void) {
     *     if (USART2->SR & USART_SR_RXNE) {
     *         uart.rxCallback();
     *     }
     * }
     */
    void rxCallback() {
        // Reading DR automatically clears RXNE flag
        uint8_t data = uart_->DR & 0xFF;
        
        // Store in circular buffer
        uint16_t next_head = (rx_head_ + 1) % RX_BUFFER_SIZE;
        if (next_head != rx_tail_) {
            rx_buffer_[rx_head_] = data;
            rx_head_ = next_head;
        }
        // else: buffer overflow, drop data
    }
    
private:
    USART_TypeDef* uart_;
    
    static constexpr uint16_t RX_BUFFER_SIZE = 256;
    uint8_t rx_buffer_[RX_BUFFER_SIZE];
    volatile uint16_t rx_head_;
    volatile uint16_t rx_tail_;
    
    /**
     * @brief Initialize GPIO pins for UART
     * 
     * HARDWARE DETAILS:
     * ----------------
     * GPIO pins have multiple functions (GPIO, UART, SPI, etc.)
     * Selected via "Alternate Function" mode.
     * 
     * For USART2:
     * - PA2 = TX (Alternate Function 7)
     * - PA3 = RX (Alternate Function 7)
     * 
     * GPIO Registers:
     * - MODER: Set pin mode (00=input, 01=output, 10=AF, 11=analog)
     * - AFR[0/1]: Select which alternate function (0-15)
     * - OTYPER: Output type (push-pull or open-drain)
     * - OSPEEDR: Output speed
     * - PUPDR: Pull-up/pull-down resistors
     */
    void initGpio() {
        // Enable GPIOA clock (bit 0 in AHB1ENR)
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
        
        // Configure PA2 (TX) and PA3 (RX) as Alternate Function
        // MODER register: 2 bits per pin
        // Pin 2: bits 4-5 = 10b (Alternate Function)
        // Pin 3: bits 6-7 = 10b (Alternate Function)
        GPIOA->MODER &= ~(GPIO_MODER_MODER2 | GPIO_MODER_MODER3);
        GPIOA->MODER |= (GPIO_MODER_MODER2_1 | GPIO_MODER_MODER3_1);
        
        // Select AF7 for USART2
        // AFR[0] is for pins 0-7 (4 bits per pin)
        // PA2: bits 8-11 = 0111b (AF7)
        // PA3: bits 12-15 = 0111b (AF7)
        GPIOA->AFR[0] &= ~((0xF << 8) | (0xF << 12));
        GPIOA->AFR[0] |= ((7 << 8) | (7 << 12));
        
        // Set high speed
        GPIOA->OSPEEDR |= (GPIO_OSPEEDER_OSPEEDR2 | GPIO_OSPEEDER_OSPEEDR3);
        
        // Push-pull output (default, but explicit)
        GPIOA->OTYPER &= ~(GPIO_OTYPER_OT_2 | GPIO_OTYPER_OT_3);
        
        // Pull-up on RX to prevent floating input
        GPIOA->PUPDR &= ~GPIO_PUPDR_PUPDR3;
        GPIOA->PUPDR |= GPIO_PUPDR_PUPDR3_0;  // 01b = pull-up
    }
    
    /**
     * @brief Initialize UART peripheral
     * 
     * HARDWARE DETAILS:
     * ----------------
     * 1. Enable peripheral clock
     * 2. Calculate baud rate divisor
     * 3. Configure word length, stop bits, parity
     * 4. Enable transmitter and receiver
     * 
     * Baud Rate Calculation:
     * ----------------------
     * USART_DIV = fck / (16 * baud_rate)
     * 
     * BRR register format (for 16x oversampling):
     * - Mantissa: USART_DIV integer part (bits 4-15)
     * - Fraction: USART_DIV fractional part * 16 (bits 0-3)
     * 
     * Example: 42 MHz / (16 * 115200) = 22.786458
     * Mantissa = 22 = 0x16
     * Fraction = 0.786458 * 16 = 12.58 ≈ 12 = 0xC
     * BRR = 0x016C
     */
    void initUart(uint32_t apb_clock, uint32_t baud_rate) {
        // Enable USART2 clock (bit 17 in APB1ENR)
        RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
        
        // Disable UART during configuration
        uart_->CR1 &= ~USART_CR1_UE;
        
        // Calculate baud rate
        // Using integer math to avoid floating point
        uint32_t usart_div = (apb_clock + (baud_rate / 2)) / baud_rate;
        uint32_t mantissa = usart_div / 16;
        uint32_t fraction = usart_div % 16;
        uart_->BRR = (mantissa << 4) | fraction;
        
        // Configure: 8 data bits, 1 stop bit, no parity (default)
        uart_->CR2 = 0;  // 1 stop bit
        uart_->CR3 = 0;  // No flow control
        
        // Enable UART, TX, and RX
        // UE: USART Enable
        // TE: Transmitter Enable
        // RE: Receiver Enable
        uart_->CR1 = USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
    }
};

#endif // BAREMETAL_UART_HPP
