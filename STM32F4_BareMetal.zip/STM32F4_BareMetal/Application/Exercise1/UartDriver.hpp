#ifndef UART_DRIVER_HPP
#define UART_DRIVER_HPP

#include "stm32f4_regs.hpp"
#include <cstring>

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * EXERCISE 1: C++ CLASS FOR UART (Bare Metal)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * LEARNING OBJECTIVES:
 * --------------------
 * 1. How to wrap hardware registers in a C++ class
 * 2. RAII (Resource Acquisition Is Initialization)
 * 3. Encapsulation of hardware details
 * 4. Interrupt-driven I/O with circular buffer
 * 5. Const correctness for hardware access
 * 
 * WHY USE A CLASS FOR HARDWARE?
 * ------------------------------
 * ✓ Encapsulation: Hide register details from users
 * ✓ Type Safety: Can't accidentally use wrong UART
 * ✓ RAII: Automatic initialization and cleanup
 * ✓ Reusability: Easy to create multiple UART instances
 * ✓ Clean API: uart.write('A') vs USART2->DR = 'A'
 * 
 * HARDWARE ABSTRACTION:
 * ---------------------
 * Old C way:
 *   RCC->APB1ENR |= RCC_APB1ENR_USART2EN;
 *   USART2->BRR = calculate_brr(42000000, 115200);
 *   USART2->CR1 |= USART_CR1_UE | USART_CR1_TE | USART_CR1_RE;
 *   while (!(USART2->SR & USART_SR_TXE));
 *   USART2->DR = 'A';
 * 
 * C++ way:
 *   UartDriver uart(USART2, 115200);
 *   uart.init();
 *   uart.write('A');
 * 
 * Much cleaner! All complexity hidden inside the class.
 */

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * CIRCULAR BUFFER (Ring Buffer)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * WHAT IS IT?
 * -----------
 * A fixed-size buffer where data wraps around when reaching the end.
 * Perfect for UART reception because:
 * ✓ No dynamic allocation (safe for embedded)
 * ✓ Constant time operations (O(1))
 * ✓ Never "fills up" - just overwrites old data
 * ✓ Interrupt-safe with proper design
 * 
 * HOW IT WORKS:
 * -------------
 *    ┌─────┬─────┬─────┬─────┬─────┬─────┬─────┬─────┐
 *    │  A  │  B  │  C  │     │     │     │     │     │  Buffer
 *    └─────┴─────┴─────┴─────┴─────┴─────┴─────┴─────┘
 *       ↑                 ↑
 *      tail             head
 * 
 * - head: Index where ISR writes next byte
 * - tail: Index where main code reads next byte
 * - Empty: head == tail
 * - Full: (head + 1) % SIZE == tail
 * 
 * THREAD SAFETY:
 * --------------
 * - Only ISR modifies head (write pointer)
 * - Only main code modifies tail (read pointer)
 * - No mutex needed - single producer, single consumer!
 * 
 * WHY VOLATILE?
 * -------------
 * head is modified by ISR, tail by main code.
 * Compiler must not cache these values!
 */

class UartDriver {
public:
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * CONSTRUCTOR
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * EXPLANATION OF EACH PART:
     * 
     * explicit UartDriver(...)
     *   ^^^^^^^^
     *   "explicit" prevents implicit conversions.
     *   Without it: UartDriver uart = USART2;  // Compiles!
     *   With it: UartDriver uart = USART2;     // Error!
     *   Must use: UartDriver uart(USART2);    // Correct
     * 
     * USART_Registers* uart
     *   ^^^^^^^^^^^^^^^^
     *   Pointer to hardware registers (USART1, USART2, etc.)
     *   Using pointer (not reference) allows nullptr checks
     * 
     * uint32_t baudrate = 115200
     *                   ^^^^^^^^^
     *   Default argument - can write UartDriver(USART2)
     *   and it defaults to 115200 baud
     * 
     * : uart_(uart), baudrate_(baudrate), rx_head_(0), rx_tail_(0)
     *   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
     *   Member initializer list - more efficient than assignment
     *   Initializes members BEFORE constructor body runs
     * 
     * WHY SAVE PARAMETERS?
     * --------------------
     * Constructor doesn't initialize hardware yet!
     * Just saves config. Hardware init happens in init() method.
     * This allows:
     * - Global UART objects (created before main())
     * - Control when hardware is actually configured
     * - Error checking in init() (can return bool)
     */
    explicit UartDriver(USART_Registers* uart, uint32_t baudrate = 115200)
        : uart_(uart)
        , baudrate_(baudrate)
        , rx_head_(0)
        , rx_tail_(0)
    {
        // Zero out receive buffer
        std::memset(rx_buffer_, 0, RX_BUFFER_SIZE);
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * DESTRUCTOR
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * RAII: Resource Acquisition Is Initialization
     * 
     * The destructor cleans up automatically when object goes out of scope.
     * For hardware, this means:
     * - Disable peripheral
     * - Disable interrupts
     * - Reset pins to safe state
     * 
     * Example of RAII benefit:
     * 
     * void someFunction() {
     *     UartDriver uart(USART2);
     *     uart.init();
     *     uart.write("Hello");
     *     if (error) {
     *         return;  // Early return!
     *     }
     *     // More code...
     * }  // Destructor called HERE automatically!
     *    // UART disabled, no resource leak
     * 
     * Without RAII, you'd need:
     *     if (error) {
     *         uart_cleanup();  // Easy to forget!
     *         return;
     *     }
     */
    ~UartDriver() {
        if (uart_ != nullptr) {
            // Disable UART
            uart_->CR1 &= ~USART_CR1_UE;
            
            // Disable interrupts in NVIC
            if (uart_ == USART2) {
                *NVIC_ICER1 |= (1 << 6);  // Disable USART2 IRQ
            }
        }
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * DELETE COPY OPERATIONS
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * WHY DELETE COPY?
     * ----------------
     * This class controls a hardware resource (UART peripheral).
     * There's only ONE USART2 in the chip!
     * 
     * If we allowed copying:
     *   UartDriver uart1(USART2);
     *   UartDriver uart2 = uart1;  // Two objects, one hardware!
     *   // Both destructors try to disable same UART
     *   // Both try to handle same interrupt
     *   // DISASTER!
     * 
     * By deleting copy constructor and copy assignment:
     *   UartDriver uart2 = uart1;  // Compiler error!
     *   uart2 = uart1;             // Compiler error!
     * 
     * This is called "non-copyable" or "move-only" resource.
     * 
     * = delete is C++11 feature that explicitly deletes functions.
     * Better than private + undefined (old way).
     */
    UartDriver(const UartDriver&) = delete;
    UartDriver& operator=(const UartDriver&) = delete;
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * INITIALIZATION
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * STEPS TO INITIALIZE UART (order is important!):
     * 1. Enable peripheral clocks (UART and GPIO)
     * 2. Configure GPIO pins for UART alternate function
     * 3. Calculate and set baud rate
     * 4. Configure UART parameters (8N1)
     * 5. Enable transmitter and receiver
     * 6. Enable UART peripheral
     * 7. Enable receive interrupt
     */
    void init() {
        // =====================================================================
        // STEP 1: Enable Clocks
        // =====================================================================
        /**
         * WHY ENABLE CLOCKS FIRST?
         * -------------------------
         * All peripherals are clock-gated by default to save power.
         * Accessing peripheral registers without clock causes HARD FAULT!
         * 
         * Clock domains:
         * - GPIOA: AHB1 bus (bit 0 in RCC_AHB1ENR)
         * - USART2: APB1 bus (bit 17 in RCC_APB1ENR)
         */
        
        RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;   // Enable GPIOA clock
        RCC->APB1ENR |= RCC_APB1ENR_USART2EN;  // Enable USART2 clock
        
        // Read-back to ensure write completed (sync)
        volatile uint32_t dummy = RCC->APB1ENR;
        (void)dummy;  // Suppress "unused variable" warning
        
        // =====================================================================
        // STEP 2: Configure GPIO Pins for UART
        // =====================================================================
        /**
         * USART2 PINS (STM32F407):
         * PA2: USART2_TX (Alternate Function 7)
         * PA3: USART2_RX (Alternate Function 7)
         * 
         * For each pin, configure:
         * 1. MODER: Set to alternate function mode (0b10)
         * 2. OSPEEDR: Set output speed (medium is fine)
         * 3. PUPDR: Pull-up for RX (keeps line high when idle)
         * 4. AFR: Select alternate function 7 (USART2)
         */
        
        // PA2 and PA3 to Alternate Function mode
        // MODER uses 2 bits per pin
        // Pin 2: bits [5:4], Pin 3: bits [7:6]
        GPIOA->MODER &= ~((0b11 << (2*2)) | (0b11 << (3*2)));  // Clear
        GPIOA->MODER |=  ((0b10 << (2*2)) | (0b10 << (3*2)));  // Set AF mode
        
        // Set medium speed (25 MHz)
        GPIOA->OSPEEDR &= ~((0b11 << (2*2)) | (0b11 << (3*2)));
        GPIOA->OSPEEDR |=  ((0b01 << (2*2)) | (0b01 << (3*2)));
        
        // Pull-up on RX pin (PA3) to keep line high
        GPIOA->PUPDR &= ~((0b11 << (3*2)));
        GPIOA->PUPDR |=  ((0b01 << (3*2)));
        
        // Set alternate function 7 (USART2)
        // AFR[0] controls pins 0-7, 4 bits per pin
        // Pin 2: bits [11:8], Pin 3: bits [15:12]
        GPIOA->AFR[0] &= ~((0xF << (2*4)) | (0xF << (3*4)));  // Clear
        GPIOA->AFR[0] |=  ((7 << (2*4)) | (7 << (3*4)));      // Set AF7
        
        // =====================================================================
        // STEP 3: Calculate Baud Rate
        // =====================================================================
        /**
         * BAUD RATE FORMULA:
         * 
         * BRR = f_PCLK / (16 × Baud Rate)
         * 
         * Why 16? UART uses 16x oversampling:
         * - Samples each bit 16 times
         * - Takes majority vote for noise immunity
         * 
         * BRR REGISTER FORMAT:
         * [15:4]: Mantissa (integer part)
         * [3:0]:  Fraction (1/16ths)
         * 
         * Example: USART2 on APB1 @ 42 MHz, Baud = 115200
         * BRR = 42,000,000 / (16 × 115,200) = 22.786
         * 
         * Split into integer and fractional parts:
         * Integer: 22 = 0x16
         * Fraction: 0.786 × 16 = 12.58 ≈ 13 = 0xD
         * 
         * BRR = (22 << 4) | 13 = 0x016D = 365 decimal
         * 
         * ACTUAL BAUD: 42,000,000 / (16 × 365) = 115,068 bps
         * Error: (115,068 - 115,200) / 115,200 = -0.11%
         * (< 2% error is acceptable for UART)
         */
        
        // APB1 clock frequency (adjust for your system)
        constexpr uint32_t APB1_CLOCK = 42000000;
        
        // Calculate BRR with rounding
        uint32_t brr_value = (APB1_CLOCK + (baudrate_ / 2)) / baudrate_;
        uart_->BRR = brr_value;
        
        // =====================================================================
        // STEP 4: Configure UART Format (8N1)
        // =====================================================================
        /**
         * CR1 (Control Register 1):
         * 
         * Bit 13 (UE): USART Enable
         * Bit 12 (M): Word length (0 = 8 bits, 1 = 9 bits)
         * Bit 10 (PCE): Parity control enable
         * Bit 5 (RXNEIE): RXNE interrupt enable
         * Bit 3 (TE): Transmitter enable
         * Bit 2 (RE): Receiver enable
         * 
         * We want:
         * - 8 data bits (M = 0)
         * - No parity (PCE = 0)
         * - TX enabled (TE = 1)
         * - RX enabled (RE = 1)
         * - RX interrupt enabled (RXNEIE = 1)
         * - UART enabled (UE = 1)
         */
        
        uart_->CR1 = 0;  // Clear all bits
        uart_->CR1 |= USART_CR1_TE;      // Enable transmitter
        uart_->CR1 |= USART_CR1_RE;      // Enable receiver
        uart_->CR1 |= USART_CR1_RXNEIE;  // Enable RX interrupt
        
        /**
         * CR2 (Control Register 2):
         * Bits [13:12]: Stop bits
         *   00 = 1 stop bit (most common)
         *   01 = 0.5 stop bits
         *   10 = 2 stop bits
         *   11 = 1.5 stop bits
         */
        uart_->CR2 = 0;  // 1 stop bit (default)
        
        /**
         * CR3 (Control Register 3):
         * Hardware flow control (CTS/RTS)
         * We don't use it
         */
        uart_->CR3 = 0;
        
        // Enable UART
        uart_->CR1 |= USART_CR1_UE;
        
        // =====================================================================
        // STEP 5: Enable Interrupt in NVIC
        // =====================================================================
        /**
         * NVIC (Nested Vectored Interrupt Controller):
         * Manages all interrupts in Cortex-M4
         * 
         * USART2 interrupt:
         * - IRQ number: 38
         * - Register: NVIC_ISER1 (for IRQs 32-63)
         * - Bit: 38 - 32 = 6
         */
        
        if (uart_ == USART2) {
            *NVIC_ISER1 |= (1 << 6);  // Enable USART2 interrupt
        }
        // Add other USART support here if needed
        
        // Store instance pointer for ISR
        instance_ = this;
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * TRANSMIT (Blocking)
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * EXPLANATION:
     * -----------
     * 1. Wait for TXE (Transmit Data Register Empty) flag
     * 2. Write byte to DR (Data Register)
     * 3. Hardware automatically:
     *    - Clears TXE
     *    - Shifts out bits (start, data[7:0], stop)
     *    - Sets TXE when done
     * 
     * WHY WAIT FOR TXE?
     * -----------------
     * DR is only one byte! If we write before TXE is set,
     * we overwrite data that hasn't been sent yet.
     * 
     * BLOCKING vs NON-BLOCKING:
     * -------------------------
     * This is blocking - CPU waits doing nothing.
     * For production, use:
     * - DMA (hardware copies data, no CPU involvement)
     * - TX interrupt (ISR sends next byte)
     * - Timeout (prevent infinite wait)
     * 
     * const QUALIFIER:
     * ----------------
     * "const" at end means: this method doesn't modify class members.
     * Only modifies hardware (uart_->DR), not class state.
     * Allows calling on const UartDriver objects.
     */
    void write(uint8_t data) const {
        // Wait for transmit data register to be empty
        // TXE = 1 means ready for new data
        while (!(uart_->SR & USART_SR_TXE)) {
            // Busy-wait loop
            // TODO: Add timeout for production code!
        }
        
        // Write data to data register
        // Hardware clears TXE and starts transmission
        uart_->DR = data;
        
        /**
         * WHAT HAPPENS IN HARDWARE:
         * 
         * 1. TXE flag cleared automatically
         * 2. Shift register loaded with data
         * 3. Start bit (0) sent on TX pin
         * 4. 8 data bits sent LSB first
         * 5. Stop bit (1) sent
         * 6. TXE flag set (ready for next byte)
         * 7. TC (Transmission Complete) set when all done
         */
    }
    
    /**
     * Transmit a null-terminated string
     */
    void writeString(const char* str) const {
        while (*str) {
            write(*str++);
        }
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * CHECK DATA AVAILABLE
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * Returns true if there's data in the circular buffer.
     * 
     * THREAD SAFETY:
     * --------------
     * This is safe without critical section because:
     * - ISR only modifies rx_head_
     * - Main only modifies rx_tail_
     * - Comparison is atomic on Cortex-M4 (32-bit aligned reads)
     */
    bool available() const {
        return (rx_head_ != rx_tail_);
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * READ BYTE FROM BUFFER
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * Removes and returns one byte from circular buffer.
     * 
     * IMPORTANT: This is NOT const because it modifies rx_tail_!
     * 
     * EDGE CASE:
     * ----------
     * If buffer is empty, returns 0.
     * In production, distinguish between:
     * - No data available (return false)
     * - Received byte is actually 0
     * 
     * Better interface:
     *   bool read(uint8_t& data) {
     *       if (!available()) return false;
     *       data = rx_buffer_[rx_tail_];
     *       ...
     *       return true;
     *   }
     */
    uint8_t read() {
        if (!available()) {
            return 0;  // No data
        }
        
        // Read byte from buffer
        uint8_t data = rx_buffer_[rx_tail_];
        
        // Advance tail pointer (wrap around)
        rx_tail_ = (rx_tail_ + 1) % RX_BUFFER_SIZE;
        
        return data;
    }
    
    /**
     * ═════════════════════════════════════════════════════════════════════════
     * INTERRUPT HANDLER (called by ISR)
     * ═════════════════════════════════════════════════════════════════════════
     * 
     * WHEN IS THIS CALLED?
     * --------------------
     * Hardware sets RXNE flag when byte received.
     * If RXNEIE interrupt enabled, CPU jumps to USART2_IRQHandler.
     * That ISR calls this method.
     * 
     * CRITICAL: Keep ISRs SHORT!
     * ---------------------------
     * - No blocking operations
     * - No complex processing
     * - No printf/malloc/etc
     * - Just read data and store
     * 
     * WHY VOLATILE?
     * -------------
     * rx_head_ is volatile because:
     * - Modified by ISR
     * - Read by main code
     * - Compiler must not optimize away reads/writes
     */
    void rxInterruptHandler() {
        /**
         * STEP 1: Read Data Register
         * ---------------------------
         * Reading DR clears RXNE flag automatically.
         * Must read DR even if buffer is full, or interrupt keeps firing!
         */
        uint8_t data = uart_->DR & 0xFF;  // Mask to 8 bits
        
        /**
         * STEP 2: Calculate Next Head Position
         * -------------------------------------
         * Use modulo to wrap around at buffer end
         */
        uint16_t next_head = (rx_head_ + 1) % RX_BUFFER_SIZE;
        
        /**
         * STEP 3: Check If Buffer Is Full
         * --------------------------------
         * Buffer full when (head + 1) == tail
         * 
         * If full, we have two choices:
         * 1. Drop new data (what we do here)
         * 2. Overwrite oldest data (move tail forward)
         * 
         * Choice depends on application:
         * - Drop new: Keep old data (logging)
         * - Overwrite: Keep recent data (sensor readings)
         */
        if (next_head != rx_tail_) {
            // Buffer has space
            rx_buffer_[rx_head_] = data;
            rx_head_ = next_head;
        }
        // else: Buffer full, drop byte (or implement error handling)
    }
    
    /**
     * Static instance pointer for ISR access
     * 
     * WHY STATIC?
     * -----------
     * The actual interrupt handler (USART2_IRQHandler) is a C function.
     * C functions can't access class members directly.
     * By making this static, it's shared across all instances.
     * 
     * LIMITATION:
     * -----------
     * Only one UartDriver per USART peripheral!
     * For multiple UARTs, use array: static UartDriver* instances_[3];
     */
    static UartDriver* instance_;
    
private:
    USART_Registers* uart_;           // Pointer to UART registers
    uint32_t baudrate_;               // Configured baud rate
    
    // Circular buffer for reception
    static constexpr uint16_t RX_BUFFER_SIZE = 256;
    uint8_t rx_buffer_[RX_BUFFER_SIZE];
    volatile uint16_t rx_head_;       // Write pointer (ISR)
    volatile uint16_t rx_tail_;       // Read pointer (main)
};

// Initialize static member
UartDriver* UartDriver::instance_ = nullptr;

/**
 * ═════════════════════════════════════════════════════════════════════════════
 * INTERRUPT SERVICE ROUTINE (ISR)
 * ═════════════════════════════════════════════════════════════════════════════
 * 
 * FUNCTION NAME IS CRITICAL!
 * --------------------------
 * Must match name in vector table (startup code).
 * STM32F407: USART2_IRQHandler
 * 
 * extern "C" REQUIRED!
 * --------------------
 * C++ mangles function names for overloading.
 * extern "C" tells compiler: use C naming convention.
 * 
 * WHAT HAPPENS:
 * -------------
 * 1. Byte arrives on RX pin
 * 2. UART hardware sets RXNE flag
 * 3. NVIC sees interrupt is enabled
 * 4. CPU saves context (registers on stack)
 * 5. CPU jumps to this function
 * 6. Function calls class method
 * 7. Return from interrupt
 * 8. CPU restores context
 * 9. Execution continues where it left off
 * 
 * INTERRUPT LATENCY:
 * ------------------
 * Time from hardware event to ISR execution:
 * - STM32F4 @ 168 MHz: typically 12-20 CPU cycles
 * - About 70-120 nanoseconds
 * 
 * CRITICAL: Keep ISRs SHORT!
 * ---------------------------
 * Long ISRs delay other interrupts and main code.
 * Rule of thumb: < 10 microseconds in ISR
 */
extern "C" void USART2_IRQHandler() {
    if (UartDriver::instance_ != nullptr) {
        UartDriver::instance_->rxInterruptHandler();
    }
}

#endif // UART_DRIVER_HPP
